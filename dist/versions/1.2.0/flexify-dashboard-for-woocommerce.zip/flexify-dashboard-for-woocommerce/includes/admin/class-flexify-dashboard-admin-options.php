<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use MeuMouse\Flexify_Dashboard_Analytics\Google\Service\Exception as GoogleServiceException;

/**
 * Admin plugin options class
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Admin_Options extends Flexify_Dashboard_Init {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        parent::__construct();
        
        add_action( 'admin_menu', array( $this, 'flexify_dashboard_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'flexify_dashboard_admin_scripts' ) );
        add_action( 'wp_ajax_flexify_dashboard_ajax_save_options', array( $this, 'flexify_dashboard_ajax_save_options_callback' ) );
    }


    /**
     * Function for create submenu in settings
     * 
     * @since 1.0.0
     * @access public
     * @return array
     */
    public function flexify_dashboard_admin_menu() {
        // add submenu on WooCommerce if Flexify theme is not active
        if ( ! class_exists('Flexify') ) {
            add_submenu_page(
                'woocommerce', // parent page slug
                esc_html__( 'Flexify Dashboard para WooCommercee', 'flexify-dashboard-for-woocommerce'), // page title
                esc_html__( 'Flexify Dashboard', 'flexify-dashboard-for-woocommerce'), // submenu title
                'manage_woocommerce', // user capabilities
                'flexify-dashboard-for-woocommerce', // page slug
                array( $this, 'flexify_dashboard_settings_page' ) // public function for print content page
            );
        }
    }


    /**
     * Plugin general setting page and save options
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/settings.php';
    }


    /**
     * Enqueue admin scripts in page settings only
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_admin_scripts() {
        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        
        if ( false !== strpos( $url, 'admin.php?page=flexify-dashboard-for-woocommerce' ) ) {
            wp_enqueue_style( 'flexify-dashboard-admin-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-admin.css', array(), FLEXIFY_DASHBOARD_VERSION );
            wp_enqueue_script( 'flexify-dashboard-admin-scripts', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-admin-scripts.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
            wp_enqueue_media();

            wp_localize_script( 'flexify-dashboard-admin-scripts', 'flexify_dashboard_admin_params', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'sidebar_logo_title' => esc_html( 'Escolher logo da barra lateral', 'flexify-dashboard-for-woocommerce' ),
                'use_this_image' => esc_html( 'Usar esta imagem', 'flexify-dashboard-for-woocommerce' ),
                'admin_login_title' => esc_html( 'Escolher imagem para área administrativa', 'flexify-dashboard-for-woocommerce' ),
            ) );
        }
    }


    /**
     * Save options in AJAX
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_ajax_save_options_callback() {
        if ( isset( $_POST['form_data'] ) ) {
            // Convert serialized data into an array
            parse_str( $_POST['form_data'], $form_data );

            $options = get_option('flexify_dashboard_data_options', array());
            $options = maybe_unserialize( $options );

            $options['enable_ga_integration'] = isset( $form_data['enable_ga_integration'] ) ? 'yes' : 'no';
            $options['enable_meta_pixel_integration'] = isset( $form_data['enable_meta_pixel_integration'] ) ? 'yes' : 'no';
            $options['enable_apexcharts_toolbar'] = isset( $form_data['enable_apexcharts_toolbar'] ) ? 'yes' : 'no';
            $options['enable_admin_search_posts'] = isset( $form_data['enable_admin_search_posts'] ) ? 'yes' : 'no';
            $options['enable_dark_mode'] = isset( $form_data['enable_dark_mode'] ) ? 'yes' : 'no';
            $options['enable_product_cost_info'] = isset( $form_data['enable_product_cost_info'] ) ? 'yes' : 'no';
            $options['enable_total_users_widget'] = isset( $form_data['enable_total_users_widget'] ) ? 'yes' : 'no';
            $options['enable_anual_billing_widget'] = isset( $form_data['enable_anual_billing_widget'] ) ? 'yes' : 'no';
            $options['enable_average_ticket_widget'] = isset( $form_data['enable_average_ticket_widget'] ) ? 'yes' : 'no';
            $options['enable_orders_number_widget'] = isset( $form_data['enable_orders_number_widget'] ) ? 'yes' : 'no';
            $options['enable_products_registered_widget'] = isset( $form_data['enable_products_registered_widget'] ) ? 'yes' : 'no';
            $options['enable_recaptcha_admin_login'] = isset( $form_data['enable_recaptcha_admin_login'] ) ? 'yes' : 'no';
            $options['enable_admin_bar'] = isset( $form_data['enable_admin_bar'] ) ? 'yes' : 'no';

            // Merge the form data with the default options
            $updated_options = wp_parse_args( $form_data, $options );

            // Save the updated options
            update_option( 'flexify_dashboard_data_options', maybe_serialize( $updated_options ) );

            // Obter opções existentes de flexify_dashboard_analytics_options
            $ga_options = get_option('flexify_dashboard_analytics_options', array());
            $ga_options = json_decode( $ga_options );

            if ( isset( $form_data['ga_client_id'] ) ) {
                $ga_options->client_id = $form_data['ga_client_id'];
            }

            if ( isset( $form_data['ga_client_secret'] ) ) {
                $ga_options->client_secret = $form_data['ga_client_secret'];
            }

            if ( isset( $form_data['ga_map_target_country'] ) ) {
                $ga_options->ga_target_geomap = $form_data['ga_map_target_country'];
            }

            if ( isset( $form_data['ga_google_maps_api_key'] ) ) {
                $ga_options->maps_api_key = $form_data['ga_google_maps_api_key'];
            }

            if ( isset( $form_data['options']['webstream_jail'] ) ) {
                $ga_options->webstream_jail = $form_data['options']['webstream_jail'];
            }

            // Salvar as atualizações em flexify_dashboard_analytics_options
            update_option( 'flexify_dashboard_analytics_options', json_encode( $ga_options ) );

            $response = array(
                'status' => 'success',
                'options' => $updated_options,
            );

            echo wp_json_encode( $response ); // Send JSON response
        }

        wp_die();
    }
}

new Flexify_Dashboard_Admin_Options();