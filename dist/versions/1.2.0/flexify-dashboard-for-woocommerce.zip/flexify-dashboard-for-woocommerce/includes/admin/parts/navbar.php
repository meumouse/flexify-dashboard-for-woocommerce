<?php

/**
 * Navbar template for Flexify Dashboard
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="flexify-dashboard-navbar" class="shadow-sm d-flex align-items-center px-4 py-3 <?php echo ( Flexify_Dashboard_Init::get_setting('enable_admin_search_posts') === 'yes' ) ? 'justify-content-between' : 'justify-content-end'; ?>">
    <div class="d-lg-none">
        <button id="display-sidebar" class="btn btn-icon fs-3 lh-1">
            <i class="bx bx-menu"></i>
        </button>
    </div>

    <?php
    if ( Flexify_Dashboard_Init::get_setting('enable_admin_search_posts') === 'yes' ) {
        ?>
        <div class="d-flex align-items-center w-50">
            <div class="search-container d-flex align-items-center justify-content-between w-50">
                <i class="bx bx-search me-2 fs-4 text-body-secondary"></i>
                <input class="form-control d-sm-none" name="flexify_dashboard_search" placeholder="<?php echo esc_html( 'Digite para pesquisar...', 'flexify-dashboard-for-woocommerce' ); ?>"/>
                <div>
                    <span id="search-loader" class="d-none spinner-border spinner-border-sm"></span>
                </div>
            </div>
            <div class="flexify-dashboard-search-results-container">
                <div id="flexify-dashboard-search-results"></div>
            </div>
        </div>
        <?php
    }
    ?>

    <div class="d-flex align-items-center">
        <?php
        if ( Flexify_Dashboard_Init::get_setting('enable_dark_mode') === 'yes' ) {
            ?>
            <div class="form-check form-switch mode-switch me-3">
                <?php $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true ); ?>
                <input type="checkbox" class="toggle-switch" id="theme-mode" name="flexify_dashboard_theme_mode" <?php checked( $theme_mode_state === 'yes' ); ?>/>
            </div>
            <?php
        }
        ?>
        <div id="flexify-dashboard-screen-widgets" class="me-3">
            <button class="screen-options">
                <i class="bx bx-customize"></i>
            </button>
            <div class="screen-options-container">
                <?php
                global $pagenow;
                $screen = get_current_screen();

                if ( $pagenow === 'index.php' || in_array( $screen->id, array('product') ) ) {
                    ?>
                    <div class="enable-reorder-widgets p-3">
                        <h6><?php echo esc_html('Reposicionamento de elementos da tela', 'flexify-dashboard-for-woocommerce'); ?></h6>
                        <p class="text-muted"><?php echo esc_html('Ative esta função para reposicionar os elementos da tela conforme sua necessidade.', 'flexify-dashboard-for-woocommerce'); ?></p>
                        <div class="form-check form-switch">
                            <input type="checkbox" class="toggle-switch" id="reorder-widgets"/>
                        </div>
                    </div>
                    <?php
                }

                // Check if there are widgets for the current screen
                $current_screen = get_current_screen();

                // Checks if the screen supports widgets
                if ( method_exists( $current_screen, 'add_option' ) ) {
                    // Adds the option that allows widgets to be displayed
                    $current_screen->add_option('layout_columns', array('layout_columns' => 1));

                    // display available widgets
                    $current_screen->render_screen_options();
                } else {
                    // If the screen does not support widgets, displays a message
                    ?>
                    <span class="d-flex align-items-center p-3 fs-6 text-muted">
                        <i class="bx bx-info-circle me-2 fs-lg"></i>
                        <?php echo esc_html('Esta tela não suporta widgets.', 'flexify-dashboard-for-woocommerce'); ?>
                    </span>
                    <?php
                }
                ?>
            </div>
        </div>
        <div class="dropdown user-logged">
            <?php
                $user_id = get_current_user_id();
                $user_data = get_userdata( $user_id );

                // check if user data exists
                if ( $user_data ) {
                    $first_name = $user_data->first_name;
                    $last_name = $user_data->last_name;
                    $user_roles = $user_data->roles;

                    $role_labels = array(
                        'subscriber' => __( 'Assinante', 'flexify-dashboard-for-woocommerce' ),
                        'editor' => __( 'Editor', 'flexify-dashboard-for-woocommerce' ),
                        'author' => __( 'Autor', 'flexify-dashboard-for-woocommerce' ),
                        'contributor' => __( 'Colaborador', 'flexify-dashboard-for-woocommerce' ),
                        'administrator' => __( 'Administrador', 'flexify-dashboard-for-woocommerce' ),
                        'customer' => __( 'Cliente', 'flexify-dashboard-for-woocommerce' ),
                        'shop_manager' => __( 'Gerente de loja', 'flexify-dashboard-for-woocommerce' ),
                    );

                    $role_label = isset( $role_labels[$user_roles[0]] ) ? $role_labels[$user_roles[0]] : $user_roles[0];
                }
            ?>
            <button class="dropdown-toggle bg-transparent border-0 d-flex align-items-center" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="d-flex flex-column align-items-end me-3">
                    <span class="d-flex fs-6 user-name">
                        <span class="me-2"><?php echo esc_html( $first_name ); ?></span>
                        <span><?php echo esc_html( $last_name ); ?></span>
                    </span>
                    <span class="fs-md text-body-secondary"><?php echo esc_html( $role_label ); ?></span>
                </div>
                <img class="navbar-avatar" src="<?php echo esc_url( get_avatar_url( $user_id ) ); ?>"/>
            </button>
            <ul class="dropdown-menu user-profile">
                <li>
                    <a class="dropdown-item px-3 py-2 fs-lg" href="<?php echo esc_url( get_edit_profile_url() ) ?>">
                        <i class="bx bx-user"></i>
                        <?php echo esc_html( 'Meu perfil', 'flexify-dashboard-for-woocommerce' ); ?>
                    </a>
                </li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li>
                    <a class="dropdown-item px-3 py-2 fs-lg" href="<?php echo esc_url( wp_logout_url() ) ?>">
                        <i class="bx bx-log-out"></i>
                        <?php echo esc_html( 'Sair', 'flexify-dashboard-for-woocommerce' ); ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div id="flexify_dashboard_analytics-window-1" class="d-none"></div>