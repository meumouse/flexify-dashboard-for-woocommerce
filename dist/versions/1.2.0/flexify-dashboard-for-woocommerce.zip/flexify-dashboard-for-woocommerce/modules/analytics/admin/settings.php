<?php


// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use MeuMouse\Flexify_Dashboard_Analytics\Google\Service\Exception as GoogleServiceException;

class Flexify_Dashboard_Analytics_Settings {

	public static function update_options( $who ) {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		$network_settings = false;
		$options = $flexify_dashboard_analytics->config->options; // Get current options
		
		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) && isset( $_REQUEST['options'] ) && ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) && 'Reset' != $who ) {
			$new_options = $flexify_dashboard_analytics->config->validate_data( $_REQUEST['options'] );

			if ( 'tracking' == $who ) {
				$options['ga_anonymize_ip'] = 0;
				$options['ga_optout'] = 0;
				$options['ga_dnt_optout'] = 0;
				$options['ga_event_tracking'] = 0;
				$options['ga_enhanced_links'] = 0;
				$options['ga_event_precision'] = 0;
				$options['ga_event_bouncerate'] = 0;
				$options['ga_crossdomain_tracking'] = 0;
				$options['ga_aff_tracking'] = 0;
				$options['ga_hash_tracking'] = 0;
				$options['ga_formsubmit_tracking'] = 0;
				$options['ga_force_ssl'] = 0;
				$options['ga_pagescrolldepth_tracking'] = 0;
				$options['tm_pagescrolldepth_tracking'] = 0;
				$options['tm_optout'] = 0;
				$options['tm_dnt_optout'] = 0;
				$options['amp_tracking_analytics'] = 0;
				$options['amp_tracking_clientidapi'] = 0;
				$options['amp_tracking_tagmanager'] = 0;
				$options['optimize_pagehiding'] = 0;
				$options['optimize_tracking'] = 0;
				$options['trackingcode_infooter'] = 0;
				$options['trackingevents_infooter'] = 0;

				if ( isset( $_REQUEST['options']['ga_tracking_code'] ) ) {
					$new_options['ga_tracking_code'] = trim( $new_options['ga_tracking_code'], "\t" );
				}
				if ( empty( $new_options['track_exclude'] ) ) {
					$new_options['track_exclude'] = array();
				}
			} elseif ( 'backend' == $who ) {
				$options['switch_profile'] = 0;
				$options['backend_item_reports'] = 0;
				$options['dashboard_widget'] = 0;
				
				if ( empty( $new_options['access_back'] ) ) {
					$new_options['access_back'][] = 'administrator';
				}
			} elseif ( 'frontend' == $who ) {
				$options['frontend_item_reports'] = 0;
				
				if ( empty( $new_options['access_front'] ) ) {
					$new_options['access_front'][] = 'administrator';
				}
			} elseif ( 'general' == $who ) {
				$options['user_api'] = 0;
			} elseif ( 'network' == $who ) {
				$options['user_api'] = 0;
				$options['network_mode'] = 0;
				$options['superadmin_tracking'] = 0;
				$network_settings = true;
			}

			$options = array_merge( $options, $new_options );
			$flexify_dashboard_analytics->config->options = $options;
			$flexify_dashboard_analytics->config->set_plugin_options( $network_settings );
		}
		
		return $options;
	}

	private static function navigation_tabs( $tabs ) {
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $tab => $name ) {
			echo "<a class='nav-tab' id='tab-".esc_attr( $tab )."' href='#top#flexify_dashboard_analytics-".esc_attr( $tab )."'>". esc_html( $name ) ."</a>";
		}
		echo '</h2>';
	}

	private static function html_form_begin( $text, $action, $message ) {
		?>
<form name="flexify_dashboard_analytics_form" method="post" action="<?php echo esc_url( $action ); ?>">
	<div class="wrap">
			<?php echo "<h2>" . esc_html( $text ) . "</h2>"; ?>
	  <?php if (isset($message)) echo wp_kses( $message, array( 'div' => array( 'class' => array(), 'id' => array() ), 'p' => array(), 'a' => array( 'href' => array() ) ) ); ?>
	  <hr>
	</div>
	<div id="poststuff" class="flexify_dashboard_analytics">
		<div id="post-body" class="metabox-holder columns-2">
			<div id="post-body-content">
				<div class="settings-wrapper">
					<div class="inside">
						<input type="hidden" name="options[flexify_dashboard_analytics_hidden]" value="Y">
						<?php wp_nonce_field('flexify_dashboard_analytics_form','flexify_dashboard_analytics_security'); ?>
	<?php
}

	private static function html_form_end() {
		?>


</form>
<?php
	}

	private static function html_switch_button( $option_name, $option_value, $option_id, $checked, $option_text, $disabled = false, $onchange = false ) {
		if ( $disabled ){
			return;
		}
		?>
<tr>
	<td colspan="2" class="flexify_dashboard_analytics-settings-title">
		<div class="button-primary flexify_dashboard_analytics-settings-switchoo">
			<input type="checkbox" name="<?php echo esc_attr( $option_name ); ?>" value="<?php echo esc_attr( $option_value ); ?>" class="flexify_dashboard_analytics-settings-switchoo-checkbox" id="<?php echo esc_attr( $option_id ); ?>" <?php checked( $checked, 1 ); ?> <?php disabled( $disabled, true );?> <?php if ($onchange) {echo ' onchange="this.form.submit()"'; } ?>>
			<label class="flexify_dashboard_analytics-settings-switchoo-label" for="<?php echo esc_attr( $option_id ); ?>">
				<div class="flexify_dashboard_analytics-settings-switchoo-inner"></div>
				<div class="flexify_dashboard_analytics-settings-switchoo-switch"></div>
			</label>
		</div>
		<div class="switch-desc"><?php echo " " . esc_html( $option_text );?></div>
	</td>
</tr>
<?php
	}

	private static function html_section_delimiter( $title = false, $withhr = true, $withspan = true, $disabled = false ) {
		?>
<tr>
	<td <?php if ( $withspan ) echo 'colspan="2"'; ?>>
			<?php if ( $withhr ) echo "<hr>";	if ( $title ) echo "<h2>" . esc_html( $title ) . "</h2>";?>
	</td>
</tr>
<?php
	}

	public static function frontend_settings() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$options = self::update_options( 'frontend' );
		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) ) {
			$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Settings saved.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			if ( ! ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) ) {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		?>
<?php self::html_form_begin(__( "Google Analytics Frontend Settings", 'flexify-dashboard-for-woocommerce' ), $_SERVER['REQUEST_URI'], $message)?>
<table class="flexify_dashboard_analytics-settings-options">
	<?php self::html_section_delimiter(__( "Permissions", 'flexify-dashboard-for-woocommerce' ), false); ?>
	<tr>
		<td class="roles flexify_dashboard_analytics-settings-title">
			<label for="access_front"><?php _e("Show stats to:", 'flexify-dashboard-for-woocommerce' ); ?></label>
		</td>
		<td class="flexify_dashboard_analytics-settings-roles">
			<table>
				<tr>
				<?php if ( ! isset( $wp_roles ) ) : $wp_roles = new WP_Roles(); endif; ?>
				<?php $i = 0; ?>
				<?php foreach ( $wp_roles->role_names as $role => $name ) : ?>
				<?php if ( 'subscriber' != $role ) : ?>
				<?php $i++; ?>
					<td>
						<label>
							<input type="checkbox" name="options[access_front][]" value="<?php echo esc_attr( $role ); ?>" <?php if ( in_array($role,$options['access_front']) || 'administrator' == $role ) echo 'checked="checked"'; if ( 'administrator' == $role ) echo 'disabled="disabled"';?> /><?php echo esc_attr( $name ); ?></label>
					</td>
					<?php endif; ?>
					<?php if ( 0 == $i % 4 ) : ?>
			 </tr>
				<tr>
				<?php endif; ?>
				<?php endforeach; ?>


			</table>
		</td>
	</tr>
	<?php self::html_switch_button('options[frontend_item_reports]', 1, 'frontend_item_reports', $options['frontend_item_reports'], __("enable web page reports on frontend", 'flexify-dashboard-for-woocommerce') ); ?>
	<?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2" class="submit">
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Changes', 'flexify-dashboard-for-woocommerce' ) ?>" />
		</td>
	</tr>
</table>
<?php self::html_form_end(); ?>
<?php	Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}

	public static function backend_settings() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$options = self::update_options( 'backend' );
		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) ) {
			$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Settings saved.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			if ( ! ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) ) {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		?>
<?php self::html_form_begin(__( "Google Analytics Backend Settings", 'flexify-dashboard-for-woocommerce' ), $_SERVER['REQUEST_URI'], $message)?>
<table class="flexify_dashboard_analytics-settings-options">
	<?php self::html_section_delimiter(__( "Permissions", 'flexify-dashboard-for-woocommerce' ), false); ?>
	<tr>
		<td class="roles flexify_dashboard_analytics-settings-title">
			<label for="access_back"><?php _e("Show stats to:", 'flexify-dashboard-for-woocommerce' ); ?></label>
		</td>
		<td class="flexify_dashboard_analytics-settings-roles">
			<table>
				<tr>
				<?php if ( ! isset( $wp_roles ) ) : ?>
				<?php $wp_roles = new WP_Roles(); ?>
				<?php endif; ?>
				<?php $i = 0; ?>
				<?php foreach ( $wp_roles->role_names as $role => $name ) : ?>
				<?php if ( 'subscriber' != $role ) : ?>
				<?php $i++; ?>
					<td>
						<label>
							<input type="checkbox" name="options[access_back][]" value="<?php echo esc_attr( $role ); ?>" <?php if ( in_array($role,$options['access_back']) || 'administrator' == $role ) echo 'checked="checked"'; if ( 'administrator' == $role ) echo 'disabled="disabled"';?> /> <?php echo esc_attr( $name ); ?></label>
					</td>
					<?php endif; ?>
					<?php if ( 0 == $i % 4 ) : ?>
				</tr>
				<tr>
				<?php endif; ?>
				<?php endforeach; ?>


			</table>
		</td>
	</tr>
 <?php self::html_switch_button('options[switch_profile]', 1, 'switch_profile', $options['switch_profile'], __( "enable Switch Property functionality", 'flexify-dashboard-for-woocommerce') ); ?>
 <?php self::html_switch_button('options[backend_item_reports]', 1, 'backend_item_reports', $options['backend_item_reports'], __( "enable reports on Posts List and Pages List", 'flexify-dashboard-for-woocommerce') ); ?>
 <?php self::html_switch_button('options[dashboard_widget]', 1, 'dashboard_widget', $options['dashboard_widget'], __( "enable the main Dashboard Widget", 'flexify-dashboard-for-woocommerce') ); ?>
 <?php self::html_section_delimiter(__( "Real-Time Settings", 'flexify-dashboard-for-woocommerce' )); ?>
 <tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-title"> <?php _e("Maximum number of pages to display on real-time tab:", 'flexify-dashboard-for-woocommerce'); ?>
									<input type="number" name="options[ga_realtime_pages]" id="ga_realtime_pages" value="<?php echo (int)$options['ga_realtime_pages']; ?>" size="3">
		</td>
	</tr>
			<?php self::html_section_delimiter(__( "Location Settings", 'flexify-dashboard-for-woocommerce' )); ?>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="ga_target_geomap"><?php _e("Target Map Country:", 'flexify-dashboard-for-woocommerce' ); ?></label>
		</td>
		<td>
			<select id="ga_target_geomap" name="options[ga_target_geomap]">
			<?php $country_codes = Flexify_Dashboard_Analytics_Tools::get_countrycodes(); ?>
			<?php foreach ( $country_codes as $key => $value ) : ?>
			<?php if ( $value ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $value, $options['ga_target_geomap'] ); ?> >
	  		<?php echo esc_html( $value ) ?>
				</option>
			<?php endif; ?>
			<?php endforeach; ?>
			</select>
		</td>
	</tr>
	</tr>
			<?php self::html_section_delimiter(__( "Google Maps Settings", 'flexify-dashboard-for-woocommerce' )); ?>
	<tr>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-title">
				<?php echo __("API Key:", 'flexify-dashboard-for-woocommerce'); ?>
				<input type="text" style="text-align: center;" name="options[maps_api_key]" value="<?php echo esc_attr($options['maps_api_key']); ?>" size="50">
		</td>
	</tr>
	<?php self::html_section_delimiter(__( "404 Errors Report", 'flexify-dashboard-for-woocommerce' )); ?>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-title">
	 	<?php echo __("404 Page Title contains:", 'flexify-dashboard-for-woocommerce'); ?>
			<input type="text" style="text-align: center;" name="options[pagetitle_404]" value="<?php echo esc_attr($options['pagetitle_404']); ?>" size="20">
		</td>
	</tr>
 <?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2" class="submit">
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Changes', 'flexify-dashboard-for-woocommerce' ) ?>" />
		</td>
	</tr>
</table>
<?php self::html_form_end(); ?>
<?php
		Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}

	public static function tracking_settings() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$options = self::update_options( 'tracking' );
		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) ) {
			$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Settings saved.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			if ( ! ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) ) {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		if ( 'ga4tracking' == $options['tracking_type'] ) {
			$tabs = array( 'basic' => __( "Basic Settings", 'flexify-dashboard-for-woocommerce' ), 'events' => __( "Events Tracking", 'flexify-dashboard-for-woocommerce' ), 'custom' => __( "Custom Definitions", 'flexify-dashboard-for-woocommerce' ), 'exclude' => __( "Exclude Tracking", 'flexify-dashboard-for-woocommerce' ), 'advanced' => __( "Advanced Settings", 'flexify-dashboard-for-woocommerce' ), 'integration' => __( "Integration", 'flexify-dashboard-for-woocommerce' ) );
		} else if ( 'tagmanager' == $options['tracking_type'] ) {
			$tabs = array( 'basic' => __( "Basic Settings", 'flexify-dashboard-for-woocommerce' ), 'tmdatalayervars' => __( "DataLayer Variables", 'flexify-dashboard-for-woocommerce' ), 'exclude' => __( "Exclude Tracking", 'flexify-dashboard-for-woocommerce' ), 'tmadvanced' => __( "Advanced Settings", 'flexify-dashboard-for-woocommerce' ), 'tmintegration' => __( "Integration", 'flexify-dashboard-for-woocommerce' ) );
		} else {
			$tabs = array( 'basic' => __( "Basic Settings", 'flexify-dashboard-for-woocommerce' ) );
		}
		?>
<?php self::html_form_begin(__( "Google Analytics Tracking Code", 'flexify-dashboard-for-woocommerce' ), '', $message)?>
<?php self::navigation_tabs( $tabs ); ?>
<div id="flexify_dashboard_analytics-basic">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Tracking Settings", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tracking_type"><?php _e("Tracking Type:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tracking_type" name="options[tracking_type]" onchange="this.form.submit()">
					<?php if ( $flexify_dashboard_analytics->config->options['webstream_jail'] ) : ?>
					 <option value="ga4tracking" <?php selected( $options['tracking_type'], 'ga4tracking' ); ?>><?php _e("Google Analytics 4", 'flexify-dashboard-for-woocommerce');?></option>
					<?php endif; ?>
					<option value="tagmanager" <?php selected( $options['tracking_type'], 'tagmanager' ); ?>><?php _e("Tag Manager", 'flexify-dashboard-for-woocommerce');?></option>
					<option value="disabled" <?php selected( $options['tracking_type'], 'disabled' ); ?>><?php _e("Disabled", 'flexify-dashboard-for-woocommerce');?></option>
				</select>
			</td>
		</tr>
	 <?php if ( 'ga4tracking' == $options['tracking_type'] ) : ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title"></td>
			<td>
			<?php if ( 'ga4tracking' == $options['tracking_type'] && $flexify_dashboard_analytics->config->options['webstream_jail'] ) : ?>
				<?php $webstream_info = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $flexify_dashboard_analytics->config->options['webstream_jail'] ); ?>
				<?php $webstream_info[5] = isset( $webstream_info[5] ) ? $webstream_info[5] : '' ?>
				<pre><?php echo __( "Stream Name:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[0] ) . "<br />" . __( "Stream ID:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[1] ) . "<br />" . __( "Stream URL:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[2] ) . "<br />" . __( "Measurement ID:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[3] ) . "<br />" . __( "Time Zone:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[5] );?></pre>
				<?php endif; ?>
			</td>
		</tr>
			<?php elseif ( 'tagmanager' == $options['tracking_type'] ) : ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tracking_type"><?php _e("Web Container ID:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<input type="text" name="options[web_containerid]" value="<?php echo esc_attr($options['web_containerid']); ?>" size="15">
			</td>
		</tr>
			<?php endif; ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="trackingcode_infooter"><?php _e("Code Placement:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="trackingcode_infooter" name="options[trackingcode_infooter]">
					<option value="0" <?php selected( $options['trackingcode_infooter'], 0 ); ?>><?php _e("HTML Head", 'flexify-dashboard-for-woocommerce');?></option>
					<option value="1" <?php selected( $options['trackingcode_infooter'], 1 ); ?>><?php _e("HTML Body", 'flexify-dashboard-for-woocommerce');?></option>
				</select>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-events">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Events Tracking", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[ga_event_tracking]', 1, 'ga_event_tracking', $options['ga_event_tracking'], __( "track downloads, mailto, telephone and outbound links", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_aff_tracking]', 1, 'ga_aff_tracking', $options['ga_aff_tracking'], __( "track affiliate links", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_hash_tracking]', 1, 'ga_hash_tracking', $options['ga_hash_tracking'], __( "track fragment identifiers, hashmarks (#) in URI links", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_formsubmit_tracking]', 1, 'ga_formsubmit_tracking', $options['ga_formsubmit_tracking'], __( "track form submit actions", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_pagescrolldepth_tracking]', 1, 'ga_pagescrolldepth_tracking', $options['ga_pagescrolldepth_tracking'], __( "track page scrolling depth", 'flexify-dashboard-for-woocommerce') ); ?>
	 <tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_event_downloads"><?php _e("Downloads Regex:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_event_downloads" name="options[ga_event_downloads]" value="<?php echo esc_attr($options['ga_event_downloads']); ?>" size="50">
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_event_affiliates"><?php _e("Affiliates Regex:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_event_affiliates" name="options[ga_event_affiliates]" value="<?php echo esc_attr($options['ga_event_affiliates']); ?>" size="50">
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="trackingevents_infooter"><?php _e("Code Placement:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="trackingevents_infooter" name="options[trackingevents_infooter]">
					<option value="0" <?php selected( $options['trackingevents_infooter'], 0 ); ?>><?php _e("HTML Head", 'flexify-dashboard-for-woocommerce');?></option>
					<option value="1" <?php selected( $options['trackingevents_infooter'], 1 ); ?>><?php _e("HTML Body", 'flexify-dashboard-for-woocommerce');?></option>
				</select>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-custom">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Custom Dimensions", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php $dimprefix = 'ga4tracking' == $options['tracking_type'] ? 'flexify_dashboard_analytics_dim_' : 'dimension' ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_author_dimindex"><?php _e("Authors:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_author_dimindex" name="options[ga_author_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
											<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_author_dimindex'], $i ); ?>><?php echo 0 == $i ?'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
			 </select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_pubyear_dimindex"><?php _e("Publication Year:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_pubyear_dimindex" name="options[ga_pubyear_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
											<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_pubyear_dimindex'], $i ); ?>><?php echo 0 == $i ?'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_pubyearmonth_dimindex"><?php _e("Publication Month:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_pubyearmonth_dimindex" name="options[ga_pubyearmonth_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
											<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_pubyearmonth_dimindex'], $i ); ?>><?php echo 0 == $i ?'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_category_dimindex"><?php _e("Categories:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_category_dimindex" name="options[ga_category_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
											<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_category_dimindex'], $i ); ?>><?php echo 0 == $i ? 'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_user_dimindex"><?php _e("User Type:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_user_dimindex" name="options[ga_user_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
											<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_user_dimindex'], $i ); ?>><?php echo 0 == $i ? 'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_tag_dimindex"><?php _e("Tags:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="ga_tag_dimindex" name="options[ga_tag_dimindex]">
										<?php for ($i=0;$i<21;$i++) : ?>
										<option value="<?php echo (int) $i;?>" <?php selected( $options['ga_tag_dimindex'], $i ); ?>><?php echo 0 == $i ? 'Disabled':$dimprefix . ' ' .(int) $i; ?></option>
										<?php endfor; ?>
				</select>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-tmdatalayervars">
	<table class="flexify_dashboard_analytics-settings-options">
							 <?php self::html_section_delimiter(__( "Main Variables", 'flexify-dashboard-for-woocommerce' ), false); ?>
	 <tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_author_var"><?php _e("Authors:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_author_var" name="options[tm_author_var]">
					<option value="1" <?php selected( $options['tm_author_var'], 1 ); ?>>flexify_dashboard_analyticsAuthor</option>
					<option value="0" <?php selected( $options['tm_author_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_pubyear_var"><?php _e("Publication Year:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_pubyear_var" name="options[tm_pubyear_var]">
					<option value="1" <?php selected( $options['tm_pubyear_var'], 1 ); ?>>flexify_dashboard_analyticsPublicationYear</option>
					<option value="0" <?php selected( $options['tm_pubyear_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_pubyearmonth_var"><?php _e("Publication Month:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_pubyearmonth_var" name="options[tm_pubyearmonth_var]">
					<option value="1" <?php selected( $options['tm_pubyearmonth_var'], 1 ); ?>>flexify_dashboard_analyticsPublicationYearMonth</option>
					<option value="0" <?php selected( $options['tm_pubyearmonth_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_category_var"><?php _e("Categories:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_category_var" name="options[tm_category_var]">
					<option value="1" <?php selected( $options['tm_category_var'], 1 ); ?>>flexify_dashboard_analyticsCategory</option>
					<option value="0" <?php selected( $options['tm_category_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_user_var"><?php _e("User Type:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_user_var" name="options[tm_user_var]">
					<option value="1" <?php selected( $options['tm_user_var'], 1 ); ?>>flexify_dashboard_analyticsUser</option>
					<option value="0" <?php selected( $options['tm_user_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tm_tag_var"><?php _e("Tags:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<select id="tm_tag_var" name="options[tm_tag_var]">
					<option value="1" <?php selected( $options['tm_tag_var'], 1 ); ?>>flexify_dashboard_analyticsTag</option>
					<option value="0" <?php selected( $options['tm_tag_var'], 0 ); ?>><?php _e( "Disabled", 'flexify-dashboard-for-woocommerce' ); ?></option>
				</select>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-advanced">
	<table class="flexify_dashboard_analytics-settings-options">
			<?php self::html_section_delimiter(__( "Advanced Tracking", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_user_samplerate"><?php _e("User Sample Rate:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="number" id="ga_user_samplerate" name="options[ga_user_samplerate]" value="<?php echo (int)($options['ga_user_samplerate']); ?>" max="100" min="1">
				%
			</td>
		</tr>
		<?php self::html_switch_button('options[ga_anonymize_ip]', 1, 'ga_anonymize_ip', $options['ga_anonymize_ip'], __( "anonymize IPs while tracking", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_event_bouncerate]', 1, 'ga_event_bouncerate', $options['ga_event_bouncerate'], __( "exclude events from bounce-rate and time on page calculation", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_enhanced_links]', 1, 'ga_enhanced_links', $options['ga_enhanced_links'], __( "enable enhanced link attribution", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[ga_event_precision]', 1, 'ga_event_precision', $options['ga_event_precision'], __( "use hitCallback to increase event tracking accuracy", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_section_delimiter(__( "Cross-domain Tracking", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[ga_crossdomain_tracking]', 1, 'ga_crossdomain_tracking', $options['ga_crossdomain_tracking'], __( "enable cross domain tracking", 'flexify-dashboard-for-woocommerce') ); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_crossdomain_list"><?php _e("Cross Domains:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_crossdomain_list" name="options[ga_crossdomain_list]" value="<?php echo esc_attr($options['ga_crossdomain_list']); ?>" size="50">
			</td>
		</tr>
		<?php self::html_section_delimiter(__( "Cookie Customization", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_cookiedomain"><?php _e("Cookie Domain:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_cookiedomain" name="options[ga_cookiedomain]" value="<?php echo esc_attr($options['ga_cookiedomain']); ?>" size="50">
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_cookiename"><?php _e("Cookie Name:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_cookiename" name="options[ga_cookiename]" value="<?php echo esc_attr($options['ga_cookiename']); ?>" size="50">
			</td>
		</tr>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="ga_cookieexpires"><?php _e("Cookie Expires:", 'flexify-dashboard-for-woocommerce'); ?></label>
			</td>
			<td>
				<input type="text" id="ga_cookieexpires" name="options[ga_cookieexpires]" value="<?php echo esc_attr($options['ga_cookieexpires']); ?>" size="10">
										<?php _e("seconds", 'flexify-dashboard-for-woocommerce' ); ?>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-integration">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Accelerated Mobile Pages (AMP)", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[amp_tracking_analytics]', 1, 'amp_tracking_analytics', $options['amp_tracking_analytics'], __( "enable tracking for Accelerated Mobile Pages (AMP)", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_section_delimiter(__( "Optimize", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[optimize_tracking]', 1, 'optimize_tracking', $options['optimize_tracking'], __( "enable Optimize tracking", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[optimize_pagehiding]', 1, 'optimize_pagehiding', $options['optimize_pagehiding'], __( "enable Page Hiding support", 'flexify-dashboard-for-woocommerce') ); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tracking_type"><?php _e("Container ID:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<input type="text" name="options[optimize_containerid]" value="<?php echo esc_attr($options['optimize_containerid']); ?>" size="15">
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-tmadvanced">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Advanced Tracking", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[tm_optout]', 1, 'tm_optout', $options['tm_optout'], __( "enable support for user opt-out", 'flexify-dashboard-for-woocommerce') ); ?>
		<?php self::html_switch_button('options[tm_dnt_optout]', 1, 'tm_dnt_optout', $options['tm_dnt_optout'], __( "exclude tracking for users sending Do Not Track header", 'flexify-dashboard-for-woocommerce') ); ?>
	</table>
</div>
<div id="flexify_dashboard_analytics-tmintegration">
	<table class="flexify_dashboard_analytics-settings-options">
 	<?php self::html_section_delimiter(__( "Accelerated Mobile Pages (AMP)", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<?php self::html_switch_button('options[amp_tracking_tagmanager]', 1, 'amp_tracking_tagmanager', $options['amp_tracking_tagmanager'], __( "enable tracking for Accelerated Mobile Pages (AMP)", 'flexify-dashboard-for-woocommerce') ); ?>
		<tr>
			<td class="flexify_dashboard_analytics-settings-title">
				<label for="tracking_type"><?php _e("AMP Container ID:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td>
				<input type="text" name="options[amp_containerid]" value="<?php echo esc_attr($options['amp_containerid']); ?>" size="15">
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-exclude">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Exclude Tracking", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<tr>
			<td class="roles flexify_dashboard_analytics-settings-title">
				<label for="track_exclude"><?php _e("Exclude tracking for:", 'flexify-dashboard-for-woocommerce' ); ?></label>
			</td>
			<td class="flexify_dashboard_analytics-settings-roles">
				<table>
					<tr>
						<?php if ( ! isset( $wp_roles ) ) : ?>
							<?php $wp_roles = new WP_Roles(); ?>
						<?php endif; ?>
						<?php $i = 0; ?>
						<?php foreach ( $wp_roles->role_names as $role => $name ) : ?>
							<?php if ( 'subscriber' != $role ) : ?>
    				<?php $i++; ?>
						<td>
							<label>
								<input type="checkbox" name="options[track_exclude][]" value="<?php echo esc_attr( $role ); ?>" <?php if (in_array($role,$options['track_exclude'])) echo 'checked="checked"'; ?> /> <?php echo esc_attr( $name ); ?></label>
						</td>
						<?php endif; ?>
						<?php if ( 0 == $i % 4 ) : ?>
			 	</tr>
					<tr>
							<?php endif; ?>
					<?php endforeach; ?>


				</table>
			</td>
		</tr>
	</table>
</div>
<table class="flexify_dashboard_analytics-settings-options">
	<?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2" class="submit">
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Changes', 'flexify-dashboard-for-woocommerce' ) ?>" />
		</td>
	</tr>
</table>
<?php self::html_form_end(); ?>
<?php
		Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}

	public static function errors_debugging() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$anonim = Flexify_Dashboard_Analytics_Tools::anonymize_options( $flexify_dashboard_analytics->config->options );
		$options = self::update_options( 'frontend' );
		?>
<?php self::html_form_begin(__( "Google Analytics Errors & Debugging", 'flexify-dashboard-for-woocommerce' ), $_SERVER['REQUEST_URI'], $message)?>
<?php $tabs = array( 'errors' => __( "Errors & Details", 'flexify-dashboard-for-woocommerce' ), 'config' => __( "Plugin Settings", 'flexify-dashboard-for-woocommerce' ), 'sysinfo' => __( "System", 'flexify-dashboard-for-woocommerce' ) ); ?>
<?php self::navigation_tabs( $tabs ); ?>
<div id="flexify_dashboard_analytics-errors">
	<table class="flexify_dashboard_analytics-settings-logdata">
		<?php self::html_section_delimiter(__( "Detected Errors", 'flexify-dashboard-for-woocommerce' ), false, false); ?>
		<tr>
			<td>
				<?php $errors_count = Flexify_Dashboard_Analytics_Tools::get_cache( 'errors_count' ); ?>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo '<span>' . __("Count: ", 'flexify-dashboard-for-woocommerce') . '</span>' . (int)$errors_count;?></pre>
				<?php $error = Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ) ?>
				<?php $ajax_error = Flexify_Dashboard_Analytics_Tools::get_cache( 'ajax_errors' ) ?>
				<?php $error_code = isset( $error[0] ) ? $error[0] : 'None' ?>
				<?php $error_reason = ( isset( $error[1] ) && !empty($error[1]) ) ? print_r( $error[1], true) : 'None' ?>
				<?php $error_ajax = $ajax_error ? print_r( $ajax_error , true) : 'None' ?>
				<?php $error_details = isset( $error[2] ) ? print_r( $error[2], true) : 'None' ?>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo '<span>' . __("Ajax Error Code: ", 'flexify-dashboard-for-woocommerce') . '</span>' . esc_html( $error_ajax );?></pre>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo '<span>' . __("API Error Code: ", 'flexify-dashboard-for-woocommerce') . '</span>' . esc_html( $error_code );?></pre>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo '<span>' . __("API Error Reason: ", 'flexify-dashboard-for-woocommerce') . '</span>' . "\n" . esc_html( $error_reason );?></pre>
				<?php $error_details = str_replace( 'Deconf_', 'Google_', $error_details); ?>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo '<span>' . __("API Error Details: ", 'flexify-dashboard-for-woocommerce') . '</span>' . "\n" . esc_html( $error_details );?></pre>
				<br />
				<hr>
			</td>
		</tr>
		<?php self::html_section_delimiter(__( "Sampled Data", 'flexify-dashboard-for-woocommerce' ), false, false); ?>
		<tr>
			<td>
				<?php $sampling = Flexify_Dashboard_Analytics_TOOLS::get_cache( 'sampleddata' ); ?>
				<?php if ( $sampling ) :?>
					<?php printf( __( "Last Detected on %s.", 'flexify-dashboard-for-woocommerce' ), '<strong>'. esc_html( $sampling['date'] ) . '</strong>' );?><br />
					<?php printf( __( "The report was based on %s of sessions.", 'flexify-dashboard-for-woocommerce' ), '<strong>'. esc_html( $sampling['percent'] ) . '</strong>' );?><br />
					<?php printf( __( "Sessions ratio: %s.", 'flexify-dashboard-for-woocommerce' ), '<strong>'. esc_html( $sampling['sessions'] ) . '</strong>' ); ?>
				<?php else :?>
					<?php _e( "None", 'flexify-dashboard-for-woocommerce' ); ?>
			 <?php endif;?>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-config">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "Plugin Configuration", 'flexify-dashboard-for-woocommerce' ), false, false); ?>
		<tr>
			<td>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo esc_html( print_r( $anonim, true ) );?></pre>
				<br />
				<hr>
			</td>
		</tr>
	</table>
</div>
<div id="flexify_dashboard_analytics-sysinfo">
	<table class="flexify_dashboard_analytics-settings-options">
		<?php self::html_section_delimiter(__( "System Information", 'flexify-dashboard-for-woocommerce' ), false, false); ?>
		<tr>
			<td>
				<pre class="flexify_dashboard_analytics-settings-logdata"><?php echo esc_html( Flexify_Dashboard_Analytics_Tools::system_info() );?></pre>
				<br />
				<hr>
			</td>
		</tr>
	</table>
</div>
<?php self::html_form_end(); ?>
<?php
		Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}

	public static function general_settings() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$options = self::update_options( 'general' );
		printf( '<div id="gapi-warning" class="updated"><p>%1$s <a href="https://deconf.com/analytics-insights-google-analytics-dashboard-wordpress/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=general_screen&utm_campaign=flexify_dashboard_analytics">%2$s</a></p></div>', __( 'Loading the required libraries. If this results in a blank screen or a fatal error, try this solution:', 'flexify-dashboard-for-woocommerce' ), __( 'Library conflicts between WordPress plugins', 'flexify-dashboard-for-woocommerce' ) );
		
		if ( null === $flexify_dashboard_analytics->gapi_controller ) {
			$flexify_dashboard_analytics->gapi_controller = new Flexify_Dashboard_Analytics_GAPI_Controller();
		}

		echo '<script type="text/javascript">jQuery("#gapi-warning").hide()</script>';

		if ( isset( $_REQUEST['flexify_dashboard_analytics_access_code'] ) || isset( $_REQUEST['code'] ) ) {

			if ( isset( $_REQUEST['state'] ) && wp_verify_nonce( $_REQUEST['state'], 'flexify_dashboard_analytics_state' ) ) {
				if ( isset( $_REQUEST['code'] ) ){
					$flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['code'] );
				} else {
					$flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['flexify_dashboard_analytics_access_code'] );
				}

				Flexify_Dashboard_Analytics_Tools::delete_cache( 'api_errors' );
				Flexify_Dashboard_Analytics_Tools::delete_cache( 'ajax_errors' );

				$token = $flexify_dashboard_analytics->gapi_controller->authenticate( $flexify_dashboard_analytics_access_code );
				$flexify_dashboard_analytics->config->options['token'] = $token;
				$flexify_dashboard_analytics->config->set_plugin_options();
				$options = self::update_options( 'general' );
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Plugin authorization succeeded.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				
				if ( $flexify_dashboard_analytics->config->options['token'] ) {

					$webstreams = $flexify_dashboard_analytics->gapi_controller->refresh_profiles_ga4();
					
					if ( is_array( $webstreams ) && ! empty( $webstreams ) ) {
							$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = $webstreams;
							
							if ( ! $flexify_dashboard_analytics->config->options['webstream_jail'] ) {
								$property = Flexify_Dashboard_Analytics_Tools::guess_default_domain( $webstreams, 2 );
								$flexify_dashboard_analytics->config->options['webstream_jail'] = $property;
							}

							$flexify_dashboard_analytics->config->set_plugin_options();
							$options = self::update_options( 'general' );
					}

				}
			}
		}

		if ( isset( $_REQUEST['Clear'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				Flexify_Dashboard_Analytics_Tools::clear_cache();
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Cleared Cache.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}

		if ( isset( $_REQUEST['Reset'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				$flexify_dashboard_analytics->gapi_controller->reset_token( true, true );
				Flexify_Dashboard_Analytics_Tools::clear_cache();
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Token Reseted and Revoked.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				$options = self::update_options( 'Reset' );
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}

		if ( isset( $_REQUEST['Reset_Err'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				Flexify_Dashboard_Analytics_Tools::delete_cache( 'api_errors' );
				Flexify_Dashboard_Analytics_Tools::delete_cache( 'ajax_errors' );
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "All errors reseted.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}

		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) && ! isset( $_REQUEST['Clear'] ) && ! isset( $_REQUEST['Reset'] ) && ! isset( $_REQUEST['Reset_Err'] ) ) {
			$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Settings saved.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			if ( ! ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) ) {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}

		if ( isset( $_REQUEST['Hide'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				$message = "<div class='updated' id='flexify_dashboard_analytics-action'><p>" . __( "All other domains/properties were removed.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				$lock_property = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $flexify_dashboard_analytics->config->options['webstream_jail'] );
				
				if ( empty( $lock_property ) ) {
					$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = '';
				} else {
					$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = array( $lock_property );
				}

				$options = self::update_options( 'general' );
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		?>
<?php self::html_form_begin(__( "Google Analytics Settings", 'flexify-dashboard-for-woocommerce' ), admin_url( 'admin.php?page=flexify_dashboard_analytics_settings' ), $message)?>
<table class="flexify_dashboard_analytics-settings-options">
	<?php self::html_section_delimiter(__( "Plugin Authorization", 'flexify-dashboard-for-woocommerce' ), false); 
	
	var_dump( get_option('flexify_dashboard_analytics_options') );
	?>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-info">
			<?php printf(__('You need to create a %1$s and follow this %2$s before proceeding to authorization.', 'flexify-dashboard-for-woocommerce'), sprintf('<a href="%1$s" target="_blank">%2$s</a>', 'https://deconf.com/creating-a-google-analytics-account/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=top_tutorial&utm_campaign=flexify_dashboard_analytics', __("free analytics account", 'flexify-dashboard-for-woocommerce')), sprintf('<a href="%1$s" target="_blank">%2$s</a>', 'https://deconf.com/analytics-insights-google-analytics-dashboard-wordpress/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=top_tutorial&utm_campaign=flexify_dashboard_analytics', __("step-by-step tutorial", 'flexify-dashboard-for-woocommerce')));?>
		</td>
	</tr>
	 <?php if (! $options['token'] || ($options['user_api']  && ! $options['network_mode'])) : ?>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-info">
			<input name="options[user_api]" type="checkbox" id="user_api" value="1" <?php checked( $options['user_api'], 1 ); ?> onchange="this.form.submit()" <?php echo ($options['network_mode'])?'disabled="disabled"':''; ?> /><?php echo " ".__("developer mode (requires advanced API knowledge)", 'flexify-dashboard-for-woocommerce' );?>
		</td>
	</tr>
	 <?php endif; ?>
	 <?php if ($options['user_api']  && ! $options['network_mode']) : ?>
		<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="options[client_id]"><?php _e("Client ID:", 'flexify-dashboard-for-woocommerce'); ?></label>
		</td>
		<td>
			<input type="text" name="options[client_id]" value="<?php echo esc_attr( $options['client_id'] ); ?>" size="40" required="required">
		</td>
	</tr>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="options[client_secret]"><?php _e("Client Secret:", 'flexify-dashboard-for-woocommerce'); ?></label>
		</td>
		<td>
			<input type="text" name="options[client_secret]" value="<?php echo esc_attr( $options['client_secret'] ); ?>" size="40" required="required">
	 	<?php if ( !$options['token'] ) : ?>
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Credentials', 'flexify-dashboard-for-woocommerce' ) ?>" />
			<?php endif; ?>
		</td>
	</tr>
	<?php endif; ?>
	<?php if ( $options['token'] ) : ?>
	<tr>
		<td colspan="2">
			<button type="submit" name="Reset" class="button button-secondary" <?php echo $options['network_mode']?'disabled="disabled"':''; ?>><?php _e( "Clear Authorization", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Clear" class="button button-secondary"><?php _e( "Clear Cache", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Reset_Err" class="button button-secondary"><?php _e( "Reset Errors", 'flexify-dashboard-for-woocommerce' ); ?></button>
		</td>
	</tr>
	<?php self::html_section_delimiter(); ?>
	<?php self::html_section_delimiter(__( "General Settings", 'flexify-dashboard-for-woocommerce' ), false); ?>
		<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="webstream_jail"><?php _e("Google Analaytics 4:", 'flexify-dashboard-for-woocommerce' ); ?></label>
		</td>
		<td>
			<select id="webstream_jail" <?php disabled(empty($options['ga4_webstreams_list']) || 1 == count($options['ga4_webstreams_list']), true); ?> name="options[webstream_jail]">
			<?php if ( ! empty( $options['ga4_webstreams_list'] ) ) : ?>
			<?php foreach ( $options['ga4_webstreams_list'] as $items ) : ?>
			<?php if ( $items[2] ) : ?>
				<option value="<?php echo esc_attr( $items[1] ); ?>" <?php selected( $items[1], $options['webstream_jail'] ); ?> title="<?php _e( "Stream Name:", 'flexify-dashboard-for-woocommerce' ); ?> <?php echo esc_attr( $items[0] ); ?>">
	  		<?php echo esc_html( Flexify_Dashboard_Analytics_Tools::strip_protocol( $items[2] ) )?> &#8658; <?php echo esc_attr( $items[0] ); ?>
				</option>
			<?php endif; ?>
			<?php endforeach; ?>
			<?php endif; ?>
			</select>
		</td>
	</tr>
	<?php if ( $options['webstream_jail'] && !empty( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'] ) ) :	?>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title"></td>
		<td>
			<?php $webstream_info = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $flexify_dashboard_analytics->config->options['webstream_jail'] ); ?>
			<?php $webstream_info[5] = isset( $webstream_info[5] ) ? $webstream_info[5] : '' ?>
			<pre><?php echo __( "Stream Name:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[0] ) . "<br />" . __( "Stream ID:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[1] ) . "<br />" . __( "Stream URL:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[2] ) . "<br />" . __( "Measurement ID:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[3] ) . "<br />" . __( "Time Zone:", 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[5] );?></pre>
		</td>
	</tr>
	<?php endif; ?>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="theme_color"><?php _e("Theme Color:", 'flexify-dashboard-for-woocommerce' ); ?></label>
		</td>
		<td>
			<input type="text" id="theme_color" class="theme_color" name="options[theme_color]" value="<?php echo esc_attr( $options['theme_color'] ); ?>" size="10">
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" class="submit">
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Changes', 'flexify-dashboard-for-woocommerce' ) ?>" />
			<?php if ( ( is_array( $options['ga4_webstreams_list'] ) && count( $options['ga4_webstreams_list'] ) > 1 ) ): ?>
				<input type="submit" name="Hide" class="button button-secondary" " value="<?php _e( "Lock Selection", 'flexify-dashboard-for-woocommerce' ); ?>" />
			<?php endif; ?>
		</td>
	</tr>
	<?php else : ?>
	<?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2">
	  <?php $auth = $flexify_dashboard_analytics->gapi_controller->createAuthUrl();?>
			<button type="submit" class="button button-secondary" formaction="<?php echo esc_url_raw( $auth ); ?>" <?php echo $options['network_mode']?'disabled="disabled"':''; ?>><?php _e( "Authorize Plugin", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Clear" class="button button-secondary"><?php _e( "Clear Cache", 'flexify-dashboard-for-woocommerce' ); ?></button>
		</td>
	</tr>
	<?php self::html_section_delimiter(); ?>
</table>
<?php self::html_form_end(); ?>
<?php Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() ); ?>
<?php return; ?>
<?php endif; ?>
</table>
<?php
		Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}

	// Network Settings
	public static function general_settings_network() {
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		$message = '';
		if ( ! current_user_can( 'manage_network_options' ) ) {
			return;
		}
		$options = self::update_options( 'network' );
		/*
		 * Include GAPI
		 */
		echo '<div id="gapi-warning" class="updated"><p>' . __( 'Loading the required libraries. If this results in a blank screen or a fatal error, try this solution:', 'flexify-dashboard-for-woocommerce' ) . ' <a href="https://deconf.com/analytics-insights-google-analytics-dashboard-wordpress/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=general_screen&utm_campaign=flexify_dashboard_analytics">Library conflicts between WordPress plugins</a></p></div>';
		if ( null === $flexify_dashboard_analytics->gapi_controller ) {
			$flexify_dashboard_analytics->gapi_controller = new Flexify_Dashboard_Analytics_GAPI_Controller();
		}
		echo '<script type="text/javascript">jQuery("#gapi-warning").hide()</script>';
		if ( isset( $_REQUEST['flexify_dashboard_analytics_access_code'] ) || isset( $_REQUEST['code'] ) ){

			if ( isset( $_REQUEST['state'] ) && wp_verify_nonce( $_REQUEST['state'], 'flexify_dashboard_analytics_state' ) ) {

				if ( isset( $_REQUEST['code'] ) ){
					$flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['code'] );
				} else {
					$flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['flexify_dashboard_analytics_access_code'] );
				}

					$flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['flexify_dashboard_analytics_access_code'] );

					$token = $flexify_dashboard_analytics->gapi_controller->authenticate( $flexify_dashboard_analytics_access_code );
					$flexify_dashboard_analytics->config->options['token'] = $token;
					$flexify_dashboard_analytics->config->set_plugin_options( true );
					$options = self::update_options( 'network' );
					$message = "<div class='updated' id='flexify_dashboard_analytics-action'><p>" . __( "Plugin authorization succeeded.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
					if ( is_multisite() ) { // Cleanup errors on the entire network
						foreach ( Flexify_Dashboard_Analytics_Tools::get_sites( array( 'number' => apply_filters( 'flexify_dashboard_analytics_sites_limit', 100 ) ) ) as $blog ) {
							switch_to_blog( $blog['blog_id'] );
							Flexify_Dashboard_Analytics_Tools::delete_cache( 'api_errors' );
							Flexify_Dashboard_Analytics_Tools::delete_cache( 'ajax_errors' );
							restore_current_blog();
						}
					} else {
						Flexify_Dashboard_Analytics_Tools::delete_cache( 'api_errors' );
						Flexify_Dashboard_Analytics_Tools::delete_cache( 'ajax_errors' );
					}
					if ( $flexify_dashboard_analytics->config->options['token'] ) {
						$webstreams = $flexify_dashboard_analytics->gapi_controller->refresh_profiles_ga4();
						if ( is_array( $webstreams ) && ! empty( $webstreams ) ) {
							$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = $webstreams;
							if ( isset( $flexify_dashboard_analytics->config->options['webstream_jail'] ) && ! $flexify_dashboard_analytics->config->options['webstream_jail'] ) {
								// $property = Flexify_Dashboard_Analytics_Tools::guess_default_domain( $webstreams, 2 );
								// $flexify_dashboard_analytics->config->options['webstream_jail'] = $property;
							}
							$flexify_dashboard_analytics->config->set_plugin_options( true );
							$options = self::update_options( 'network' );
						}
					}
			}
		}
		if ( isset( $_REQUEST['Refresh'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = array();
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Properties refreshed.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				$options = self::update_options( 'network' );
				if ( $flexify_dashboard_analytics->config->options['token'] ) {
					if ( ! empty( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'] ) ) {
						$webstreams = $flexify_dashboard_analytics->config->options['ga4_webstreams_list'];
					} else {
						$webstreams = $flexify_dashboard_analytics->gapi_controller->refresh_profiles_ga4();
					}
					if ( $webstreams ) {
						$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = $webstreams;
						if ( isset( $flexify_dashboard_analytics->config->options['webstream_jail'] ) && ! $flexify_dashboard_analytics->config->options['webstream_jail'] ) {
							// $property = Flexify_Dashboard_Analytics_Tools::guess_default_domain( $webstreams, 2 );
							// $flexify_dashboard_analytics->config->options['webstream_jail'] = $property;
						}
						$flexify_dashboard_analytics->config->set_plugin_options( true );
						$options = self::update_options( 'network' );
					}
				}
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		if ( isset( $_REQUEST['Clear'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				Flexify_Dashboard_Analytics_Tools::clear_cache();
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Cleared Cache.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		if ( isset( $_REQUEST['Reset'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				$flexify_dashboard_analytics->gapi_controller->reset_token( true, true );
				Flexify_Dashboard_Analytics_Tools::clear_cache();
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Token Reseted and Revoked.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				$options = self::update_options( 'Reset' );
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		if ( isset( $_REQUEST['options']['flexify_dashboard_analytics_hidden'] ) && ! isset( $_REQUEST['Clear'] ) && ! isset( $_REQUEST['Reset'] ) && ! isset( $_REQUEST['Refresh'] ) ) {
			$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "Settings saved.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			if ( ! ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) ) {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		if ( isset( $_REQUEST['Hide'] ) ) {
			if ( isset( $_REQUEST['flexify_dashboard_analytics_security'] ) && wp_verify_nonce( $_REQUEST['flexify_dashboard_analytics_security'], 'flexify_dashboard_analytics_form' ) ) {
				$message = "<div class='updated' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "All other domains/properties were removed.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
				$lock_property = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $flexify_dashboard_analytics->config->options['webstream_jail'] );
				if ( empty( $lock_property ) ) {
					$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = array();
				} else {
					$flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = array( $lock_property );
				}
				$options = self::update_options( 'network' );
			} else {
				$message = "<div class='error' id='flexify_dashboard_analytics-autodismiss'><p>" . __( "You do not have sufficient permissions to access this page.", 'flexify-dashboard-for-woocommerce' ) . "</p></div>";
			}
		}
		?>
<?php self::html_form_begin(__( "Google Analytics Settings", 'flexify-dashboard-for-woocommerce' ), network_admin_url( 'admin.php?page=flexify_dashboard_analytics_settings' ), $message)?>
<table class="flexify_dashboard_analytics-settings-options">
 <?php self::html_section_delimiter(__( "Network Setup", 'flexify-dashboard-for-woocommerce' ), false); ?>
	<?php self::html_switch_button('options[network_mode]', 1, 'network_mode', $options['network_mode'], __( "use a single Google Analytics account for the entire network", 'flexify-dashboard-for-woocommerce'), false, true ); ?>
	<?php if ( $options['network_mode'] ) : ?>
	<?php self::html_section_delimiter(); ?>
	<?php self::html_section_delimiter(__( "Plugin Authorization", 'flexify-dashboard-for-woocommerce' ), false); ?>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-info">
			<?php printf(__('You need to create a %1$s and follow this %2$s before proceeding to authorization.', 'flexify-dashboard-for-woocommerce'), sprintf('<a href="%1$s" target="_blank">%2$s</a>', 'https://deconf.com/creating-a-google-analytics-account/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=top_tutorial&utm_campaign=flexify_dashboard_analytics', __("free analytics account", 'flexify-dashboard-for-woocommerce')), sprintf('<a href="%1$s" target="_blank">%2$s</a>', 'https://deconf.com/analytics-insights-google-analytics-dashboard-wordpress/?utm_source=flexify_dashboard_analytics_config&utm_medium=link&utm_content=top_tutorial&utm_campaign=flexify_dashboard_analytics', __("step-by-step tutorial", 'flexify-dashboard-for-woocommerce')));?>
		</td>
	</tr>
	<?php if ( ! $options['token'] || $options['user_api'] ) : ?>
	<tr>
		<td colspan="2" class="flexify_dashboard_analytics-settings-info">
			<input name="options[user_api]" type="checkbox" id="user_api" value="1" <?php checked( $options['user_api'], 1 ); ?> onchange="this.form.submit()" /><?php echo " ".__("developer mode (requires advanced API knowledge)", 'flexify-dashboard-for-woocommerce' );?>
		</td>
	</tr>
	<?php endif; ?>
	<?php if ( $options['user_api'] ) : ?>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="options[client_id]"><?php _e("Client ID:", 'flexify-dashboard-for-woocommerce'); ?></label>
		</td>
		<td>
			<input type="text" name="options[client_id]" value="<?php echo esc_attr( $options['client_id'] ); ?>" size="40" required="required">
		</td>
	</tr>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title">
			<label for="options[client_secret]"><?php _e("Client Secret:", 'flexify-dashboard-for-woocommerce'); ?></label>
		</td>
		<td>
			<input type="text" name="options[client_secret]" value="<?php echo esc_attr( $options['client_secret'] ); ?>" size="40" required="required">
			<input type="hidden" name="options[flexify_dashboard_analytics_hidden]" value="Y">
			<?php if ( !$options['token'] ) : ?>
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Credentials', 'flexify-dashboard-for-woocommerce' ) ?>" />
			<?php endif; ?>
			<?php wp_nonce_field('flexify_dashboard_analytics_form','flexify_dashboard_analytics_security'); ?>
		</td>
	</tr>
	<?php endif; ?>
	<?php if ( $options['token'] ) : ?>
	<tr>
		<td colspan="2">
			<button type="submit" name="Reset" class="button button-secondary"><?php _e( "Clear Authorization", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Clear" class="button button-secondary"><?php _e( "Clear Cache", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Refresh" class="button button-secondary"><?php _e( "Refresh Properties", 'flexify-dashboard-for-woocommerce' ); ?></button>
		</td>
	</tr>
	<?php self::html_section_delimiter() ?>
	<?php self::html_section_delimiter(__( "Properties/Views Settings", 'flexify-dashboard-for-woocommerce' ), false) ?>
	<?php if ( isset( $options['network_webstream'] ) ) : ?>
	<?php $options['network_webstream'] = json_decode( json_encode( $options['network_webstream'] ), false ); ?>
	<?php endif; ?>
	<?php foreach ( Flexify_Dashboard_Analytics_Tools::get_sites( array( 'number' => apply_filters( 'flexify_dashboard_analytics_sites_limit', 100 ) ) ) as $blog ) : ?>
	<tr>
		<td class="flexify_dashboard_analytics-settings-title-s">
			<label for="network_webstream"><?php echo '<strong>'. esc_html( $blog['domain'] ) . esc_url( $blog['path'] ) .'</strong>: ';?></label>
		</td>
		<td>
			<select id="network_webstreams-<?php echo $blog['blog_id'] ?>" class="network_webstreams" <?php disabled(empty($options['ga4_webstreams_list']) || 1 == count($options['ga4_webstreams_list']), true); ?> name="options[network_webstream][<?php echo esc_attr( $blog['blog_id'] );?>]">
			<?php if ( ! empty( $options['ga4_webstreams_list'] ) ) : ?>
			<?php $temp_id = $blog['blog_id']; ?>
			<?php foreach ( $options['ga4_webstreams_list'] as $items ) : ?>
			<?php if ( $items[2] ) : ?>
				<option value="<?php echo esc_attr( $items[1] ); ?>" <?php selected( $items[1], isset( $options['network_webstream']->$temp_id ) ? $options['network_webstream']->$temp_id : '');?> title="<?php _e( "Stream Name:", 'flexify-dashboard-for-woocommerce' ); ?> <?php echo esc_attr( $items[0] ); ?>">
	  		<?php echo esc_html( Flexify_Dashboard_Analytics_Tools::strip_protocol( $items[2] ) )?> &#8658; <?php echo esc_attr( $items[0] ); ?>
				</option>
			<?php endif; ?>
			<?php endforeach; ?>
			<?php endif; ?>
			</select>
		</td>
	</tr>
	<?php endforeach; ?>
	<?php self::html_section_delimiter(); ?>
	<?php self::html_switch_button('options[superadmin_tracking]', 1, 'superadmin_tracking', $options['superadmin_tracking'], __( "exclude Super Admin tracking for the entire network", 'flexify-dashboard-for-woocommerce'), false, false ); ?>
	<?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2" class="submit">
			<input type="submit" name="Submit" class="button button-primary" value="<?php _e('Save Changes', 'flexify-dashboard-for-woocommerce' ) ?>" />
		</td>
	</tr>
	<?php else : ?>
	<?php self::html_section_delimiter(); ?>
	<tr>
		<td colspan="2">
	  <?php $auth = $flexify_dashboard_analytics->gapi_controller->createAuthUrl();?>
			<button type="submit" class="button button-secondary" formaction="<?php echo esc_url_raw( $auth ); ?>"><?php _e( "Authorize Plugin", 'flexify-dashboard-for-woocommerce' ); ?></button>
			<button type="submit" name="Clear" class="button button-secondary"><?php _e( "Clear Cache", 'flexify-dashboard-for-woocommerce' ); ?></button>
		</td>
	</tr>
	<?php endif; ?>
	<?php self::html_section_delimiter(); ?>
</table>
<?php self::html_form_end(); ?>
<?php Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() ); ?>
<?php return; ?>
<?php endif;?>
</table>
<?php self::html_form_end(); ?>
<?php
		Flexify_Dashboard_Analytics_Tools::load_view( 'admin/views/settings-sidebar.php', array() );
	}
}
