<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Frontend_Item_Reports' ) ) {

	final class Flexify_Dashboard_Analytics_Frontend_Item_Reports {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			
			add_action( 'admin_bar_menu', array( $this, 'custom_adminbar_node' ), 999 );
		}

		function custom_adminbar_node( $wp_admin_bar ) {
			if ( Flexify_Dashboard_Analytics_Tools::is_amp() ){
				return;
			}
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_front'] ) && $this->flexify_dashboard_analytics->config->options['frontend_item_reports'] ) {
				
				$args = array( 	'id' => 'flexify_dashboard_analytics-1',
								'title' => '<span class="ab-icon"></span><span class="">' . __( "Analytics", 'flexify-dashboard-for-woocommerce' ) . '</span>',
								'href' => '#1',
								);
				/* @formatter:on */
				$wp_admin_bar->add_node( $args );
			}
		}
	}
}
