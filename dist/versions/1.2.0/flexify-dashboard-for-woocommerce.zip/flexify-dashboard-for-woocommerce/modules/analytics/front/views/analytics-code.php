<!-- BEGIN Analytics Insights by Flexify Dashboard v<?php echo FLEXIFY_DASHBOARD_VERSION; ?> -->
<script async src="<?php echo esc_url( $data['tracking_script_path'] )?>?id=<?php echo esc_js( $data['gaid'] )?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
<?php
do_action('flexify_dashboard_analytics_gtag_output_before');
echo wp_kses( $data['trackingcode'], array() );
do_action('flexify_dashboard_analytics_gtag_output_after');
?>
  if (window.performance) {
    var timeSincePageLoad = Math.round(performance.now());
    gtag('event', 'timing_complete', {
      'name': 'load',
      'value': timeSincePageLoad,
      'event_category': 'JS Dependencies'
    });
  }
</script>
<!-- END Analytics Insights -->