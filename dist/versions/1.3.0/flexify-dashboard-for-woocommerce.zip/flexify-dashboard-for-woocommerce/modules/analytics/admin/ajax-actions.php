<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Backend_Ajax' ) ) {

	final class Flexify_Dashboard_Analytics_Backend_Ajax {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) && ( ( 1 == $this->flexify_dashboard_analytics->config->options['backend_item_reports'] ) || ( 1 == $this->flexify_dashboard_analytics->config->options['dashboard_widget'] ) ) ) {
				// Items action
				add_action( 'wp_ajax_flexify_dashboard_analytics_backend_item_reports', array( $this, 'ajax_item_reports' ) );
			}
			
			if ( current_user_can( 'manage_options' ) ) {
				// Admin Widget action
				add_action( 'wp_ajax_flexify_dashboard_analytics_dismiss_notices', array( $this, 'ajax_dismiss_notices' ) );
			}
		}

		/**
		 * Ajax handler for Item Reports
		 *
		 * @return mixed|int
		 */
		public function ajax_item_reports() {
			if ( ! isset( $_POST['flexify_dashboard_analytics_security_backend_item_reports'] ) || ! wp_verify_nonce( $_POST['flexify_dashboard_analytics_security_backend_item_reports'], 'flexify_dashboard_analytics_backend_item_reports' ) ) {
				wp_die( 630 );
			}

			if ( isset( $_POST['projectId'] ) && $this->flexify_dashboard_analytics->config->options['switch_profile'] && 'false' !== $_POST['projectId'] ) {
				$projectId = sanitize_text_field( $_POST['projectId'] );
			} else {
				$projectId = false;
			}

			$from = sanitize_text_field( $_POST['from'] );
			$to = sanitize_text_field( $_POST['to'] );
			$query = sanitize_text_field( $_POST['query'] );

			if ( isset( $_POST['filter'] ) ) {
				$filter_id = sanitize_text_field( $_POST['filter'] );
			} else {
				$filter_id = false;
			}

			if ( isset( $_POST['metric'] ) ) {
				$metric = sanitize_text_field( $_POST['metric'] );
			} else {
				$metric = 'sessions';
			}

			if ( $filter_id && $metric == 'sessions' ) { // Sessions metric is not available for item reports
				$metric = 'pageviews';
			}

			if ( ob_get_length() ) {
				ob_clean();
			}

			if ( ! ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) && ( ( 1 == $this->flexify_dashboard_analytics->config->options['backend_item_reports'] ) || ( 1 == $this->flexify_dashboard_analytics->config->options['dashboard_widget'] ) ) ) ) {
				wp_die( 631 );
			}

			if ( $this->flexify_dashboard_analytics->config->options['token'] && $this->flexify_dashboard_analytics->config->options['webstream_jail'] && $from && $to ) {
				if ( null === $this->flexify_dashboard_analytics->gapi_controller ) {
					$this->flexify_dashboard_analytics->gapi_controller = new Flexify_Dashboard_Analytics_GAPI_Controller();
				}
			} else {
				wp_die( 624 );
			}

			if ( false == $projectId ) {
				$projectId = $this->flexify_dashboard_analytics->config->options['webstream_jail'];
			}

			$profile_info = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $this->flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $projectId );
			
			if ( isset( $profile_info[4] ) ) {
				$this->flexify_dashboard_analytics->gapi_controller->timeshift = $profile_info[4];
			} else {
				$this->flexify_dashboard_analytics->gapi_controller->timeshift = (int) current_time( 'timestamp' ) - time();
			}

			if ( $filter_id ) {
				$uri_parts = explode( '/', get_permalink( $filter_id ), 4 );
				
				if ( isset( $uri_parts[3] ) ) {
					$uri = '/' . $uri_parts[3];
				} else {
					wp_die( 625 );
				}

				// allow URL correction before sending an API request
				$filter = apply_filters( 'flexify_dashboard_analytics_backenditem_uri', $uri, $filter_id );
				$lastchar = substr( $filter, - 1 );
				
				if ( isset( $profile_info[6] ) && $profile_info[6] && '/' == $lastchar ) {
					$filter = $filter . $profile_info[6];
				}
				// Encode URL
				//$filter = rawurlencode( rawurldecode( $filter ) );
			} else {
				$filter = false;
			}

			$queries = explode( ',', $query );
			$results = array();
			
			foreach ( $queries as $value ) {
				$results[] = $this->flexify_dashboard_analytics->gapi_controller->get( $projectId, $value, $from, $to, $filter, $metric );
			}

			update_option('flexify_dashboard_get_response_analytics', $results);

			wp_send_json( $results );
		}

		/**
		 * Ajax handler for dismissing Admin notices
		 *
		 * @return json|int
		 */
		public function ajax_dismiss_notices() {
			if ( ! isset( $_POST['flexify_dashboard_analytics_security_dismiss_notices'] ) || ! wp_verify_nonce( $_POST['flexify_dashboard_analytics_security_dismiss_notices'], 'flexify_dashboard_analytics_dismiss_notices' ) ) {
				wp_die( 630 );
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 631 );
			}

			wp_die();
		}
	}
}