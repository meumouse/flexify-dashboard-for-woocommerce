<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="styles" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html( 'Logo da barra lateral', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar como logo da barra lateral, ou deixe em branco para não exibir. Tamanho recomendado: 300 x 140 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="dashboard_logo" class="form-control" value="<?php echo self::get_setting( 'dashboard_logo' ) ?>"/>
               <button id="flexify_dashboard_logo_sidebar" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html( 'Imagem da página de login administrativo', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar na área lateral da página de login administrativo, ou deixe em branco para não exibir. Tamanho recomendado: 2200 x 2160 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="admin_login_image" class="form-control" value="<?php echo self::get_setting( 'admin_login_image' ) ?>"/>
               <button id="flexify_dashboard_admin_login_image" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html( 'Logo da página de login administrativo', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar como logo da página de login administrativo, ou deixe em branco para não exibir. Tamanho recomendado: 512 x 512 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="admin_login_logo" class="form-control" value="<?php echo self::get_setting( 'admin_login_logo' ) ?>"/>
               <button id="search_admin_login_logo" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>

      <tr class="container-separator"></tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Cor primária', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_primary_color" class="form-control-color" value="<?php echo self::get_setting('set_primary_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_primary_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#008aff" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor primária ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_primary_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_primary_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_primary_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#0078ed" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor sucesso', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de confirmação.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_success_color" class="form-control-color" value="<?php echo self::get_setting('set_success_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_success_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#22c55e" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor sucesso ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de confirmação ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_success_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_success_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_success_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#1ca44e" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor aviso', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de avisos.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_warning_color" class="form-control-color" value="<?php echo self::get_setting('set_warning_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_warning_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#ffc42d" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor aviso ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de avisos ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_warning_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_warning_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_warning_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#e1a200" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor perigo', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de erros.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_danger_color" class="form-control-color" value="<?php echo self::get_setting('set_danger_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_danger_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#ef4444" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor perigo ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações de erros ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_danger_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_danger_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_danger_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#ec2121" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor informação', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações secundárias.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_info_color" class="form-control-color" value="<?php echo self::get_setting('set_info_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_info_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#4c82f7" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor informação ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações secundárias ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_info_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_info_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_info_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#2768f5" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor escuro', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações escuras.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_dark_color" class="form-control-color" value="<?php echo self::get_setting('set_dark_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_dark_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#1a222c" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor escuro ao passar o mouse', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Define a cor dos elementos com ações e ou informações escuras ao passar o mouse.' ) ?></span>
         </th>
         <td>
            <div class="color-container input-group">
               <input type="color" name="set_dark_hover_color" class="form-control-color" value="<?php echo self::get_setting('set_dark_hover_color') ?>"/>
               <input type="text" class="get-color-selected form-control input-control-wd-10" value="<?php echo self::get_setting('set_dark_hover_color') ?>"/>
               <button type="button" class="btn btn-outline-secondary btn-icon reset-color tooltip" data-color="#24303f" data-text="<?php echo esc_html__( 'Redefinir para cor padrão', 'flexify-dashboard-for-woocommerce' ) ?>">
                  <i class="bx bx-reset fs-xg"></i>
               </button>
            </div>
         </td>
      </tr>
   </table>
</div>