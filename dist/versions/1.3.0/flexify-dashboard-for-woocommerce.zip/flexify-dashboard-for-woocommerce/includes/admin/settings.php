<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div class="flexify-dashboard-admin-tile-container">
    <svg id="flexify_dashboard_logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 901.23 848.15"><defs><style>.cls-1{fill:#141d26;}.cls-2{fill:#fff;}.cls-3{fill:none;stroke:#141d26;stroke-linecap:round;stroke-linejoin:round;stroke-width:15px;}</style></defs><path class="cls-1" d="M514,116.38c-234.22,0-424.08,189.87-424.08,424.07S279.74,964.53,514,964.53,938,774.67,938,540.45,748.17,116.38,514,116.38Zm171.38,426.1c-141.76.37-257.11,117.69-257.4,259.45H339.72c0-191.79,153.83-347.42,345.62-347.42Zm0-176.64c-141.76.19-266.84,69.9-346,176.13V410.6C431,328.12,551.92,277.5,685.34,277.5Z" transform="translate(-89.88 -116.38)"/><circle class="cls-2" cx="780.25" cy="121.6" r="120.99"/><g id="SVGRepo_iconCarrier" data-name="SVGRepo iconCarrier"><path class="cls-3" d="M847.71,222H823.08a13.62,13.62,0,0,0-13.73,13.51v51.14a13.61,13.61,0,0,0,13.73,13.5h24.63a13.62,13.62,0,0,0,13.74-13.51V235.54A13.62,13.62,0,0,0,847.71,222Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M847.71,169.93H823.08a13.36,13.36,0,0,0-13.73,13v8.81a13.36,13.36,0,0,0,13.73,13h24.63a13.37,13.37,0,0,0,13.74-13v-8.81A13.38,13.38,0,0,0,847.71,169.93Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M892.55,248.08h24.62a13.62,13.62,0,0,0,13.74-13.51V183.44a13.62,13.62,0,0,0-13.73-13.51H892.55a13.62,13.62,0,0,0-13.74,13.51v51.13a13.62,13.62,0,0,0,13.74,13.51Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M892.55,300.18h24.62a13.37,13.37,0,0,0,13.74-13v-8.81a13.36,13.36,0,0,0-13.73-13H892.55a13.37,13.37,0,0,0-13.74,13v8.8A13.37,13.37,0,0,0,892.55,300.18Z" transform="translate(-89.88 -116.38)"/></g></svg>
    <h1 class="flexify-dashboard-admin-section-tile"><?php echo get_admin_page_title() ?></h1>
</div>
<div class="flexify-dashboard-admin-title-description">
    <p><?php echo esc_html__( 'Extensão que adiciona uma nova interface de usuário moderna e de simples uso. Se precisar de ajuda para configurar, acesse nossa', 'flexify-dashboard-for-woocommerce' ) ?>
        <a class="fancy-link" href="<?php echo FLEXIFY_DASHBOARD_DOCS_LINK ?>" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'flexify-dashboard-for-woocommerce' ) ?></a>
    </p>
</div>

<div class="toast toast-success update-notice-flexify-dashboard">
    <div class="toast-header bg-success text-white">
        <i class="bx bx-check-circle fs-lg me-2"></i>
        <span class="me-auto"><?php _e( 'Salvo com sucesso', 'flexify-dashboard-for-woocommerce' ); ?></span>
        <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'flexify-dashboard-for-woocommerce' ); ?></div>
</div>

<?php 

if ( $this->activate_license && isset( $_POST['flexify_dashboard_active_license'] ) || $this->activate_license && isset( $_POST['action'] ) ) {
    echo '<div class="toast toast-success show">
        <div class="toast-header bg-success text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'Licença ativada com sucesso!', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( 'Todos os recursos agora estão ativados!', 'flexify-dashboard-for-woocommerce' ) .'</div>
    </div>';
}
    
if ( $this->deactivate_license ) {
    echo '<div class="toast toast-warning show">
        <div class="toast-header bg-warning text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'A licença foi desativada', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( 'Todos os recursos agora estão desativados!', 'flexify-dashboard-for-woocommerce' ) .'</div>
    </div>';
}

if ( $this->clear_cache ) {
    ?>
    <div class="toast toast-success show">
        <div class="toast-header bg-success text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto"><?php echo esc_html__( 'Cache de ativação limpo', 'flexify-dashboard-for-woocommerce' ); ?></span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
        </div>
        <div class="toast-body"><?php echo esc_html__( 'O cache de ativação foi limpo com sucesso!', 'flexify-dashboard-for-woocommerce' ); ?></div>
    </div>
    <?php
}

if ( $this->site_not_allowed && isset( $_POST['action'] ) ) {
    ?>
    <div class="toast toast-danger show">
        <div class="toast-header bg-danger text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto"><?php echo esc_html__( 'Ops! Ocorreu um erro.', 'flexify-dashboard-for-woocommerce' ) ?></span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
        </div>
        <div class="toast-body"><?php echo esc_html__( 'O domínio de ativação não é permitido.', 'flexify-dashboard-for-woocommerce' ) ?></div>
    </div>
    <?php
}

if ( $this->product_not_allowed && isset( $_POST['action'] ) ) {
    ?>
    <div class="toast toast-danger show">
        <div class="toast-header bg-danger text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto"><?php echo esc_html__( 'Ops! Ocorreu um erro.', 'flexify-dashboard-for-woocommerce' ) ?></span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
        </div>
        <div class="toast-body"><?php echo esc_html__( 'A licença não é permitida para este produto.', 'flexify-dashboard-for-woocommerce' ) ?></div>
    </div>
    <?php
}

if (  $this->show_message && !empty( $this->licenseMessage ) ) {
    echo '<div class="toast toast-danger show">
        <div class="toast-header bg-danger text-white">
            <i class="bx bx-info-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'Ops! Ocorreu um erro.', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( $this->licenseMessage ) .'</div>
    </div>';
}

settings_errors();

if ( self::license_valid() ) {
    ?>
    <div class="flexify-dashboard-wrapper">
        <div class="nav-tab-wrapper flexify-dashboard-tab-wrapper">
            <a href="#general" class="nav-tab ">
                <i class="bx bx-slider-alt fs-xg me-2"></i>
                <?php echo esc_html( 'Geral', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#integrations" class="nav-tab ">
                <i class="bx bx-plug fs-xg me-2"></i>
                <?php echo esc_html( 'Integrações', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#widgets" class="nav-tab ">
                <i class="bx bx-extension fs-xg me-2"></i>
                <?php echo esc_html( 'Widgets', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#styles" class="nav-tab ">
                <i class="bx bx-palette fs-xg me-2"></i>
                <?php echo esc_html( 'Estilos', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#about" class="nav-tab ">
                <i class="bx bx-info-circle fs-xg me-2"></i>
                <?php echo esc_html( 'Sobre', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
        </div>

        <form method="post" action="" class="flexify-dashboard-form" name="flexify-dashboard">
            <input type="hidden" name="flexify-dashboard" value="1"/>

            <?php
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/options.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/integrations.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/widgets.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/design.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/about.php'; ?>
        </form>
    </div>
    <?php
} else {
    if ( get_option('flexify_dashboard_alternative_license_activation') === 'yes' ) {
        ?>
        <div class="flexify-dashboard-wrapper">
            <form method="post" action="" class="flexify-dashboard-form-license" name="flexify-dashboard-form-license">
                <table class="flexify-dashboard-form-license">
                    <tr>
                        <td>
                            <span class="h4 d-block"><?php echo esc_html__( 'Notamos que teve problemas de conexão ao tentar ativar sua licença', 'flexify-dashboard-for-woocommerce' ); ?></span>
                            <span class="d-block text-muted"><?php echo esc_html__( 'Você pode fazer upload do arquivo .key da licença para fazer sua ativação manual.', 'flexify-dashboard-for-woocommerce' ); ?></span>
                            <a class="fancy-link mt-2 mb-3" href="https://meumouse.com/minha-conta/licenses/?domain=<?php echo urlencode( Flexify_Dashboard_Api::get_domain() ); ?>&license_key=<?php echo urlencode( get_option('flexify_dashboard_temp_license_key') ); ?>&app_version=<?php echo urlencode( FLEXIFY_DASHBOARD_VERSION ); ?>&product_id=6&settings_page=<?php echo urlencode( Flexify_Dashboard_Api::get_domain() . '/wp-admin/admin.php?page=flexify-dashboard-for-woocommerce' ); ?>" target="_blank"><?php echo esc_html__( 'Clique aqui para gerar seu arquivo de licença', 'flexify-dashboard-for-woocommerce' ) ?></a>

                            <div class="drop-file-license-key">
                                <div class="dropzone-license mt-4" id="license_key_zone">
                                    <div class="drag-text">
                                        <svg class="drag-and-drop-file-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.937 8.68c-.011-.032-.02-.063-.033-.094a.997.997 0 0 0-.196-.293l-6-6a.997.997 0 0 0-.293-.196c-.03-.014-.062-.022-.094-.033a.991.991 0 0 0-.259-.051C13.04 2.011 13.021 2 13 2H6c-1.103 0-2 .897-2 2v16c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2V9c0-.021-.011-.04-.013-.062a.99.99 0 0 0-.05-.258zM16.586 8H14V5.414L16.586 8zM6 20V4h6v5a1 1 0 0 0 1 1h5l.002 10H6z"></path></svg>
                                        <?php echo esc_html( 'Arraste e solte o arquivo .key aqui', 'flexify-dashboard-for-woocommerce' ); ?>
                                    </div>
                                    <div class="file-list"></div>
                                    <form enctype="multipart/form-data" action="upload.php" class="upload-license-key" method="POST">
                                        <div class="drag-and-drop-file">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="upload_license_key" name="upload_license_key" hidden>
                                                <label class="custom-file-label mb-4" for="upload_license_key"><?php echo esc_html( 'Ou clique para procurar seu arquivo', 'flexify-dashboard-for-woocommerce' ); ?></label>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        <?php
    } else {
        ?>
        <div>
            <form method="post" action="" class="flexify-dashboard-form-license" name="flexify-dashboard-form-license">
                <input type="hidden" name="flexify-dashboard-form-license" value="1"/>
                <table class="insert-license">
                    <tr>
                        <td class="d-grid">
                            <a class="btn btn-primary my-4 d-flex align-items-center py-3 px-4" href="https://meumouse.com/plugins/flexify-dashboard-para-woocommerce/?utm_source=wordpress&utm_medium=activate_tab&utm_campaign=flexify_dashboard" target="_blank">
                                <i class="bx bx-key fs-lg me-2"></i>
                                <span><?php _e(  'Comprar licença', 'flexify-dashboard-for-woocommerce' );?></span>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="w-75">
                            <span class="d-block bg-translucent-success rounded-3 py-2 px-3 mb-3"><?php echo esc_html__( 'Informe sua licença abaixo para desbloquear todos os recursos.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                            <span class="form-label d-block mt-2"><?php echo esc_html__( 'Código da licença', 'flexify-dashboard-for-woocommerce' ) ?></span>
                            <div class="input-group" style="width: 550px;">
                                <input class="form-control" type="text" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" id="flexify_dashboard_license_key" name="flexify_dashboard_license_key" size="50" value="<?php echo get_option( 'flexify_dashboard_license_key' ) ?>" />
                                <button id="flexify_dashboard_active_license" name="flexify_dashboard_active_license" class="btn btn-primary button-loading" type="submit">
                                    <span class="span-inside-button-loader"><?php esc_attr_e( 'Ativar licença', 'flexify-dashboard-for-woocommerce' ); ?></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        <?php
    }
}