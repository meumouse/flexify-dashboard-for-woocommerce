<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use MeuMouse\Flexify_Dashboard_Analytics\Google\Service\Exception as GoogleServiceException;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.3.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Init {

    public $responseObj;
    public $licenseMessage;
    public $show_message = false;
    public $activate_license = false;
    public $deactivate_license = false;
    public $clear_cache = false;
    public $site_not_allowed = false;
    public $product_not_allowed = false;

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        // set default tabs options
        add_action( 'admin_init', array( $this, 'flexify_dashboard_set_default_options' ) );

        // init API class after plugins loaded
        add_action( 'admin_init', array( $this, 'flexify_dashboard_api_connection' ) );

        // get object license on receive from file .key
        add_action( 'admin_init', array( $this, 'alternative_activation_process' ) );
    }


    /**
     * Set default options
     * 
     * @since 1.0.0
     * @version 1.3.0
     * @return array
     */
    public function set_default_data_options() {
        return array(
            'enable_total_users_widget' => 'yes',
            'enable_products_registered_widget' => 'yes',
            'enable_average_ticket_widget' => 'yes',
            'enable_anual_billing_widget' => 'yes',
            'enable_technology_ga_widget' => 'yes',
            'enable_orders_number_widget' => 'yes',
            'enable_visitor_type_widget' => 'yes',
            'enable_apexcharts_toolbar' => 'no',
            'enable_admin_search_posts' => 'yes',
            'enable_dark_mode' => 'yes',
            'dashboard_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-light.png' ),
            'admin_login_image' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/flexify-dashboard-login.jpg' ),
            'primary_color' => '#008aff',
            'success_color' => '#22c55e',
            'warning_color' => '#ffba08',
            'danger_color' => '#ef4444',
            'info_color' => '#4c82f7',
            'enable_recaptcha_admin_login' => 'no',
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'enable_ga_integration' => 'no',
            'ga_client_id' => '',
            'ga_client_secret' => '',
            'ga_map_target_country' => 'BR',
            'ga_google_maps_api_key' => '',
            'enable_meta_pixel_integration' => 'no',
            'enable_admin_bar' => 'no',
            'enable_flexify_dashboard_login_page' => 'yes',
            'admin_login_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-single.png' ),
            'enable_last_orders_widget' => 'yes',
            'get_last_order_number_query' => 5,
            'enable_flexify_dashboard_loader_pages' => 'yes',
            'set_primary_color' => '#008aff',
            'set_primary_hover_color' => '#0078ed',
            'set_success_color' => '#22c55e',
            'set_success_hover_color' => '#1ca44e',
            'set_warning_color' => '#ffc42d',
            'set_warning_hover_color' => '#e1a200',
            'set_danger_color' => '#ef4444',
            'set_danger_hover_color' => '#ec2121',
            'set_info_color' => '#4c82f7',
            'set_info_hover_color' => '#2768f5',
            'set_dark_color' => '#1a222c',
            'set_dark_hover_color' => '#24303f',
        );
    }


    /**
     * Gets the items from the array and inserts them into the option if it is empty,
     * or adds new items with default value to the option
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_set_default_options() {
        $get_options = $this->set_default_data_options();
        $default_options = get_option('flexify_dashboard_data_options', array());
        $default_options = maybe_unserialize( $default_options );
    
        if ( empty( $default_options ) ) {
            $options = $get_options;
            update_option('flexify_dashboard_data_options', maybe_serialize( $options ));
        } else {
            $options = $default_options;
    
            foreach ( $get_options as $key => $value ) {
                if ( ! isset( $options[$key] ) ) {
                    $options[$key] = $value;
                }
            }
    
            update_option('flexify_dashboard_data_options', maybe_serialize( $options ));
        }
    }


    /**
	 * Checks if the option exists and returns the indicated array item
	 * 
	 * @since 1.0.0
     * @param $key | Array key
     * @return mixed | string or false
	 */
    public static function get_setting( $key ) {
        $default_options = get_option('flexify_dashboard_data_options', array());
        $default_options = maybe_unserialize( $default_options );

        // check if array key exists and return key
        if ( isset( $default_options[$key] ) ) {
            return $default_options[$key];
        }

        return false;
    }


    /**
     * Load API settings
     * 
     * @since 1.0.0
     * @version 1.3.0
     * @return void
     */
    public function flexify_dashboard_api_connection() {
        if ( current_user_can('manage_woocommerce') ) {
            $this->responseObj = new stdClass();
            $message = '';
            $license_key = get_option('flexify_dashboard_license_key', '');
        
            // active license action
            if ( isset( $_POST['flexify_dashboard_active_license'] ) ) {
                // clear response cache first
                delete_transient('flexify_dashboard_api_request_cache');
                delete_transient('flexify_dashboard_api_response_cache');
        
                $license_key = isset( $_POST['flexify_dashboard_license_key'] ) ? $_POST['flexify_dashboard_license_key'] : '';
                update_option( 'flexify_dashboard_license_key', $license_key ) || add_option('flexify_dashboard_license_key', $license_key );
                update_option( 'flexify_dashboard_temp_license_key', $license_key ) || add_option('flexify_dashboard_temp_license_key', $license_key );
            }
      
            if ( ! self::license_valid() ) {
                update_option( 'flexify_dashboard_license_status', 'invalid' );
            }
      
            // Check on the server if the license is valid and update responses and options
            if ( Flexify_Dashboard_Api::check_purchase_key( $license_key, $this->licenseMessage, $this->responseObj, FLEXIFY_DASHBOARD_FILE ) ) {
                if ( $this->responseObj && $this->responseObj->is_valid ) {
                    update_option( 'flexify_dashboard_license_status', 'valid' );
                    delete_option('flexify_dashboard_temp_license_key');
                    delete_option('flexify_dashboard_alternative_license');
        
                    $this->activate_license = true;
                } else {
                    update_option( 'flexify_dashboard_license_status', 'invalid' );
                }
            } else {
                if ( ! empty( $license_key ) && ! empty( $this->licenseMessage ) ) {
                    $this->show_message = true;
                }
            }
      
            // deactive license action
            if ( isset( $_POST['flexify_dashboard_deactive_license'] ) ) {
              if ( Flexify_Dashboard_Api::RemoveLicenseKey( FLEXIFY_DASHBOARD_FILE, $message ) ) {
                    update_option( 'flexify_dashboard_license_status', 'invalid' );
                    delete_option( 'flexify_dashboard_license_key' );
                    delete_transient('flexify_dashboard_api_request_cache');
                    delete_transient('flexify_dashboard_api_response_cache');
                    delete_option('flexify_dashboard_license_response_object');
                    delete_option('flexify_dashboard_alternative_license_decrypted');
                    delete_option('flexify_dashboard_alternative_license_activation');
                    delete_option('flexify_dashboard_temp_license_key');
                    delete_option('flexify_dashboard_alternative_license');
        
                    $this->deactivate_license = true;
              }
            }
      
            // clear activation cache
            if ( isset( $_POST['flexify_dashboard_clear_activation_cache'] ) ) {
                delete_transient('flexify_dashboard_api_request_cache');
                delete_transient('flexify_dashboard_api_response_cache');
        
                $this->clear_cache = true;
            }
        }
    }


    /**
     * Generate alternative activation object from decrypted license
     * 
     * @since 1.3.0
     * @return void
     */
    public function alternative_activation_process() {
        $decrypted_license_data = get_option('flexify_dashboard_alternative_license_decrypted');
        $license_data_array = json_decode( stripslashes( $decrypted_license_data ) );
        $allowed_products = array( '6', '7', );

        if ( $license_data_array === null ) {
            return;
        }

        $this_domain = Flexify_Dashboard_Api::get_domain();

        if ( $this_domain !== $license_data_array->site_domain ) {
            $this->site_not_allowed = true;

            return;
        }

        if ( ! in_array( $license_data_array->selected_product, $allowed_products ) ) {
            $this->product_not_allowed = true;

            return;
        }

        $license_object = $license_data_array->license_object;

        if ( $this_domain === $license_data_array->site_domain ) {
            $obj = new stdClass();
            $obj->license_key = $license_data_array->license_code;
            $obj->email = $license_data_array->user_email;
            $obj->domain = $this_domain;
            $obj->app_version = FLEXIFY_DASHBOARD_VERSION;
            $obj->product_id = $license_data_array->selected_product;
            $obj->product_base = $license_data_array->product_base;
            $obj->is_valid = $license_object->is_valid;
            $obj->license_title = $license_object->license_title;
            $obj->expire_date = $license_object->expire_date;

            update_option( 'flexify_dashboard_alternative_license', 'active' );
            update_option( 'flexify_dashboard_license_response_object', $obj );
            update_option( 'flexify_dashboard_license_key', $obj->license_key );
            delete_option('flexify_dashboard_alternative_license_decrypted');
        }
    }


    /**
     * Check if license is valid
     * 
     * @since 1.2.5
     * @version 1.3.0
     * @return bool
     */
    public static function license_valid() {
        $object_query = get_option('flexify_dashboard_license_response_object');
    
        // clear api request and response cache if object is empty
        if ( empty( $object_query ) ) {
          delete_transient('flexify_dashboard_api_request_cache');
          delete_transient('flexify_dashboard_api_response_cache');
        }
    
        if ( ! empty( $object_query ) && isset( $object_query->is_valid )  ) {
          update_option( 'flexify_dashboard_license_status', 'valid' );
    
          return true;
        } else {
            update_option( 'flexify_dashboard_license_status', 'invalid' );
    
            return false;
        }
    }


    /**
     * Get license title
     * 
     * @since 1.2.5
     * @return string
     */
    public static function license_title() {
        $object_query = get_option('flexify_dashboard_license_response_object');

        if ( ! empty( $object_query ) && isset( $object_query->license_title ) ) {
            return $object_query->license_title;
        } else {
            return esc_html__(  'Não disponível', 'flexify-dashboard-for-woocommerce' );
        }
    }


    /**
     * Get license expire date
     * 
     * @since 1.2.5
     * @version 1.3.0
     * @return string
     */
    public static function license_expire() {
        $object_query = get_option('flexify_dashboard_license_response_object');

        if ( ! empty( $object_query ) && isset( $object_query->expire_date ) ) {
            if ( $object_query->expire_date === 'No expiry' ) {
                return esc_html__( 'Nunca expira', 'flexify-dashboard-for-woocommerce' );
            } else {
                if ( strtotime( $object_query->expire_date ) < time() ) {
                    update_option( 'flexify_dashboard_license_status', 'invalid' );
                    delete_option('flexify_dashboard_license_response_object');

                    return esc_html__( 'Licença expirada', 'flexify-dashboard-for-woocommerce' );
                }

                // get wordpress date format setting
                $date_format = get_option('date_format');
                $expire_date = date( $date_format, strtotime( $object_query->expire_date ) );
                update_option( 'flexify_dashboard_license_expire_date', $expire_date );

                return $expire_date;
            }
        }
    }
}

new Flexify_Dashboard_Init();