/**
 * Display screen options on navbar
 * 
 * @since 1.0.0
 */
jQuery(document).ready( function($) {
    const trigger = $('#flexify-dashboard-screen-widgets > .screen-options');
    const container = $('#flexify-dashboard-screen-widgets > .screen-options-container');

    // display screen elements popup
    trigger.on('click', function(e) {
        e.preventDefault();
        container.toggleClass('show');
        e.stopPropagation();
    });

    // hide on click outside container
    $(document).on('click', function(e) {
        if ( !container.is(e.target) && container.has(e.target).length === 0 ) {
            container.removeClass('show');
        }
    });

    // enable reorder widgets
    $(document).on('click', '#reorder-widgets', function() {
        $('.postbox-header').toggleClass('d-flex');
        $('.postbox-header').toggleClass('active');
        $('.empty-container').toggleClass('reorder');
    });
});


/**
 * Display sidebar on mobile
 * 
 * @since 1.2.0
 * @version 1.3.0
 */
jQuery(document).ready( function($) {
    $(document).on('click', '#display-sidebar', function(e) {
        e.preventDefault();
        
        $('#adminmenuwrap').addClass('active');
        $('#adminmenu').addClass('active');
    });
    
    $(document).on('click', '#close_sidebar', function(e) {
        e.preventDefault();
        
        $('#adminmenuwrap').removeClass('active');
        $('#adminmenu').removeClass('active');
    });
});

/**
 * Open search box
 * 
 * @since 1.3.0
 */
jQuery(document).ready( function($) {
    const trigger_search = $('#open_search_box');
    const container_search = $('.flexify-dashboard-search-results-container');

    // display screen elements popup
    trigger_search.on('click', function(e) {
        e.preventDefault();
        container_search.toggleClass('show');
        e.stopPropagation();
    });

    // hide on click outside container
    $(document).on('click', function(e) {
        if ( ! container_search.is(e.target) && container_search.has(e.target).length === 0 ) {
            container_search.removeClass('show');
        }
    });
});