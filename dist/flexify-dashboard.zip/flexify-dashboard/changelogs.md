Versão 1.5.0 (10/08/2024)
* Correção de bugs
* Otimizações
* Remoção do WooCommerce como dependência
* Recurso adicionado: Ativar alteração de tempo da API Heartbeat do WordPress
* Recurso adicionado: Ativar widget de produtos mais vendidos

Versão 1.3.0 (20/04/2024)
* Correção de bugs
* Otimizações
* Recurso adicionado: Ativar animação de carregamento de páginas
* Recurso adicionado: Ativar widget de últimos pedidos recebidos
* Recurso adicionado: Alteração de paleta de cores

Versão 1.2.6 (06/04/2024)
* Correção de bugs

Versão 1.2.5 (05/04/2024)
* Correção de bugs
* Otimizações
* Compatibilidade com Clube M
* Recurso adicionado: Logo da página de login administrativo
* Recurso adicionado: Ativar página de login administrativo

Versão 1.2.1 (02/03/2024)
* Alteração de servidor de verificação de licenças

Versão 1.2.0 (27/02/2024)
* Correção de bugs
* Otimizações
* Recurso adicionado: Integração com Google reCAPTCHA

Versão 1.0.0 inicial (07/02/2024)