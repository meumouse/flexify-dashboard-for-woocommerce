<?php

/**
 * Plugin Name: 			Flexify Dashboard
 * Description: 			Extensão que adiciona uma nova interface do usuário moderna e de simples uso para o WordPress e compatível com recursos de loja virtual do WooCommerce.
 * Plugin URI: 				https://meumouse.com/plugins/flexify-dashboard/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.5.0
 * WC tested up to: 		9.1.4
 * Requires PHP: 			7.4
 * Tested up to:      		6.6.1
 * Text Domain: 			flexify-dashboard
 * Domain Path: 			/languages
 * License: 				GPL2
 */

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Main Flexify_Dashboard Class
 *
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard {
	/**
	 * Flexify_Dashboard The single instance of Flexify_Dashboard.
	 *
	 * @since 1.0.0
	 * @var object
	 */
	private static $instance = null;

	/**
	 * The slug
	 *
	 * @since 1.0.0
	 * @var string
	 */
	public static $slug = 'flexify-dashboard';

	/**
	 * Plugin version number
	 *
	 * @since 1.0.0
	 * @var string
	 */
	public static $version = '1.5.0';

	/**
	 * Constructor function
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function __construct() {
		$this->setup_constants();

		add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
		add_action( 'plugins_loaded', array( $this, 'load_checker' ), 5 );
	}
	

	/**
	 * Check requeriments on plugins_loaded hook
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 * @return void
	 */
	public function load_checker() {
		// Display notice if PHP version is bottom 7.4
		if ( version_compare( phpversion(), '7.4', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'php_version_notice' ) );
			return;
		}

		add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 10 );
		add_filter( 'plugin_action_links_' . FLEXIFY_DASHBOARD_BASENAME, array( $this, 'add_action_links' ), 10, 4 );
		add_filter( 'plugin_row_meta', array( $this, 'add_row_meta_links' ), 10, 4 );

		if ( ! function_exists('is_plugin_active') ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		// check if WooCommerce is active
		if ( is_plugin_active('woocommerce/woocommerce.php') ) {
			add_action( 'before_woocommerce_init', array( $this, 'setup_hpos_compatibility' ) );
		}
	}


	/**
	 * Setup WooCommerce High-Performance Order Storage (HPOS) compatibility
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 * @return void
	 */
	public function setup_hpos_compatibility() {
		if ( defined('WC_VERSION') && version_compare( WC_VERSION, '7.1', '>' ) ) {
			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
					'custom_order_tables', FLEXIFY_DASHBOARD_FILE, true
				);
			}
		}
	}


	/**
	 * Main Flexify_Dashboard Instance
	 *
	 * Ensures only one instance of Flexify_Dashboard is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @see Flexify_Dashboard()
	 * @return Main Flexify_Dashboard instance
	 */
	public static function run() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}


	/**
	 * Define constant if not already set
	 *
	 * @since 1.0.0
	 * @param string $name | Constant name
	 * @param string|bool $value | Constant value
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}


	/**
	 * Setup plugin constants
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function setup_constants() {
		$this->define( 'FLEXIFY_DASHBOARD_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'FLEXIFY_DASHBOARD_DIR', plugin_dir_path( __FILE__ ) );
		$this->define( 'FLEXIFY_DASHBOARD_INC_DIR', FLEXIFY_DASHBOARD_DIR . '/includes/' );
		$this->define( 'FLEXIFY_DASHBOARD_URL', plugin_dir_url( __FILE__ ) );
		$this->define( 'FLEXIFY_DASHBOARD_ASSETS_URL', FLEXIFY_DASHBOARD_URL . 'assets/' );
		$this->define( 'FLEXIFY_DASHBOARD_FILE', __FILE__ );
		$this->define( 'FLEXIFY_DASHBOARD_ABSPATH', dirname( FLEXIFY_DASHBOARD_FILE ) . '/' );
		$this->define( 'FLEXIFY_DASHBOARD_SLUG', self::$slug );
		$this->define( 'FLEXIFY_DASHBOARD_VERSION', self::$version );
		$this->define( 'FLEXIFY_DASHBOARD_ADMIN_EMAIL', get_option('admin_email') );
		$this->define( 'FLEXIFY_DASHBOARD_DOCS_LINK', 'https://meumouse.com/docs/flexify-dashboard/' );
	}


	/**
	 * Setup includes based on predefined priorities
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 * @return void
	 */
	public function setup_includes() {
		$includes = apply_filters( 'flexify_dashboard_setup_includes', array(
			'functions.php',
			'class-init.php',
			'classes/class-license.php',
			'classes/class-logger.php',
			'admin/class-admin-options.php',
			'classes/class-core.php',
			'classes/class-helpers.php',
			'classes/class-assets.php',
			'classes/class-ajax.php',
			'classes/class-widgets.php',
			'classes/class-compat-autoloader.php',
			'classes/class-modules.php',
			'classes/class-updater.php',
		));

		foreach ( $includes as $file ) {
			$file_path = FLEXIFY_DASHBOARD_INC_DIR . $file;

			if ( file_exists( $file_path ) ) {
				include_once $file_path;
			}
		}
	}


	/**
	 * PHP version notice
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 * @return void
	 */
	public function php_version_notice() {
		$class = 'notice notice-error is-dismissible';
		$message = __( '<strong>Flexify Dashboard</strong> requer a versão do PHP 7.4 ou superior. Contate o suporte da sua hospedagem para realizar a atualização.', 'flexify-dashboard' );

		printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message );
	}


	/**
	 * Plugin action links
	 * 
	 * @since 1.0.0
	 * @version 1.2.5
	 * @return array
	 */
	public function add_action_links( $action_links ) {
		$plugins_links = array(
			'<a href="' . admin_url( 'admin.php?page=flexify-dashboard' ) . '">'. __( 'Configurar', 'flexify-dashboard' ) .'</a>',
		);

		return array_merge( $plugins_links, $action_links );
	}


	/**
	 * Add meta links on plugin
	 * 
	 * @since 1.2.5
	 * @param string $plugin_meta | An array of the plugin’s metadata, including the version, author, author URI, and plugin URI
	 * @param string $plugin_file | Path to the plugin file relative to the plugins directory
	 * @param array $plugin_data | An array of plugin data
	 * @param string $status | Status filter currently applied to the plugin list
	 * @return string
	 */
	public function add_row_meta_links( $plugin_meta, $plugin_file, $plugin_data, $status ) {
		if ( strpos( $plugin_file, FLEXIFY_DASHBOARD_BASENAME ) !== false ) {
			$new_links = array(
				'docs' => '<a href="'. FLEXIFY_DASHBOARD_DOCS_LINK .'" target="_blank">'. __( 'Documentação', 'flexify-dashboard' ) .'</a>',
			);
			
			$plugin_meta = array_merge( $plugin_meta, $new_links );
		}
	
		return $plugin_meta;
	}


	/**
	 * Load the plugin text domain for translation
	 * 
	 * @since 1.0.0
	 * @return void
	 */
	public static function load_plugin_textdomain() {
		load_plugin_textdomain( 'flexify-dashboard', false, dirname( FLEXIFY_DASHBOARD_BASENAME ) . '/languages/' );
	}


	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-dashboard' ), '1.0.0' );
	}


	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-dashboard' ), '1.0.0' );
	}
}

/**
 * Initialise the plugin
 */
Flexify_Dashboard::run();