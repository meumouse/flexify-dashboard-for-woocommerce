<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\Init;
use MeuMouse\Flexify_Dashboard\License;
use MeuMouse\Flexify_Dashboard\Helpers;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Core {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function __construct() {
     //   add_action( 'admin_init', array( $this, 'replace_menu_header_template' ) );

        if ( ! empty( Init::get_setting('dashboard_logo') ) ) {
            add_action( 'flexify_dashboard_before_menu', array( $this, 'flexify_dashboard_sidebar_logo' ) );
        }

        add_filter( 'admin_body_class', array( $this, 'flexify_dashboard_theme_mode_state' ) );
        add_action( 'in_admin_header', array( $this, 'flexify_dashboard_navbar' ) );

        // add loader
        if ( Init::get_setting('enable_flexify_dashboard_loader_pages') === 'yes' && ! defined('FLEXIFY_DASHBOARD_PAGE_LOADER_DISABLED') ) {
            add_action( 'in_admin_header', array( $this, 'flexify_dashboard_loader' ) );
        }

        // add styles to login page
        if ( Init::get_setting('enable_flexify_dashboard_login_page') === 'yes' ) {
            add_action( 'login_footer', array( $this, 'flexify_dashboard_copyright_login' ) );
            add_filter( 'login_headerurl', array( $this, 'flexify_dashboard_login_logo_url' ) );
            add_filter( 'login_headertext', array( $this, 'flexify_dashboard_login_logo_text' ) );
            add_action( 'login_enqueue_scripts', array( $this, 'flexify_dashboard_login_styles' ) );
        }

        if ( ! empty( Init::get_setting('admin_login_image') ) ) {
            add_action( 'login_enqueue_scripts', array( $this, 'flexify_dashboard_login_image' ) );
        }

        if ( ! empty( Init::get_setting('admin_login_logo') ) ) {
            add_action( 'login_head', array( $this, 'flexify_dashboard_admin_login_logo' ) );
        }
        
        // clear cache when receive new order
        add_action( 'woocommerce_new_order', array( $this, 'clear_cache_for_dependent_order_functions' ) );

        // set color palette to CSS root
        add_action( 'admin_head', array( $this, 'set_color_palette_root' ) );

        if ( Init::get_setting('enable_custom_heartbeat_control') === 'yes' ) {
            add_filter( 'heartbeat_settings', array( $this, 'change_heartbeat_interval' ) );
        }

        if ( Init::get_setting('enable_admin_search_posts') === 'yes' ) {
            add_action( 'in_admin_header', array( $this, 'add_modal_search' ) );
        }
    }

    
    /**
     * Replace original menu header archive from WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function replace_menu_header_template() {
        $wp_menu_header = ABSPATH . 'wp-admin/menu-header.php';
        $flexify_dashboard_menu_header = FLEXIFY_DASHBOARD_INC_DIR . 'admin/parts/menu-header.php';
    
        // Checks if the modified file exists
        if ( file_exists( $flexify_dashboard_menu_header ) ) {
            // Copies the contents of the modified file to the original file
            copy( $flexify_dashboard_menu_header, $wp_menu_header );
        }
    }


    /**
     * Load navbar template
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function flexify_dashboard_navbar() {
        $screen = get_current_screen();
        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

        if ( in_array( $screen->id, array('post', 'page') ) || strpos( $url, 'admin.php?page=wc-admin&path=%2F' ) !== false ) {
            return;
        }
    
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/parts/navbar.php';
    }


    /**
     * Add loader pages
     * 
     * @since 1.3.0
     * @return void
     */
    public function flexify_dashboard_loader() {
        ?>
        <div class="flexify-dashboard-loader-container">
            <span class="flexify-dashboard-circular-progress flexify-dashboard-loader" role="progressbar">
                <svg class="loader-circular-progress d-block" viewBox="22 22 44 44">
                    <circle class="circular-progress-animation" cx="44" cy="44" r="20.2" fill="none" stroke-width="3.6"></circle>
                </svg>
            </span>
        </div>

        <style>
            .flexify-dashboard-loader {
                width: 3rem;
                height: 3rem;
                display: inline-block;
                color: var(--flexify-dashboard-primary);
                -webkit-animation: transform-animation-circular 1.4s linear infinite;
                animation: transform-animation-circular 1.4s linear infinite;
            }

            .circular-progress-animation {
                stroke: currentColor;
                stroke-dasharray: 80px, 200px;
                stroke-dashoffset: 0;
                -webkit-animation: stroke-animation-circular 1.4s ease-in-out infinite;
                animation: stroke-animation-circular 1.4s ease-in-out infinite;
            }

            @-webkit-keyframes stroke-animation-circular {
                0% {
                    stroke-dasharray: 1px,200px;
                    stroke-dashoffset: 0;
                }

                50% {
                    stroke-dasharray: 100px,200px;
                    stroke-dashoffset: -15px;
                }

                100% {
                    stroke-dasharray: 100px,200px;
                    stroke-dashoffset: -125px;
                }
            }

            @keyframes stroke-animation-circular {
                0% {
                    stroke-dasharray: 1px,200px;
                    stroke-dashoffset: 0;
                }

                50% {
                    stroke-dasharray: 100px,200px;
                    stroke-dashoffset: -15px;
                }

                100% {
                    stroke-dasharray: 100px,200px;
                    stroke-dashoffset: -125px;
                }
            }

            @keyframes transform-animation-circular {
                0% {
                    -webkit-transform: rotate(0deg);
                    -moz-transform: rotate(0deg);
                    -ms-transform: rotate(0deg);
                    transform: rotate(0deg);
                }

                100% {
                    -webkit-transform: rotate(360deg);
                    -moz-transform: rotate(360deg);
                    -ms-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }

            @-webkit-keyframes transform-animation-circular {
                0% {
                    -webkit-transform: rotate(0deg);
                    -moz-transform: rotate(0deg);
                    -ms-transform: rotate(0deg);
                    transform: rotate(0deg);
                }

                100% {
                    -webkit-transform: rotate(360deg);
                    -moz-transform: rotate(360deg);
                    -ms-transform: rotate(360deg);
                    transform: rotate(360deg);
                }
            }
        </style>

        <script>
            jQuery(document).ready( function($) {
                $(window).on('load', function() {
                    $('.flexify-dashboard-loader-container').hide();
                });
            });
        </script>
        <?php
    }


    /**
     * Load sidebar logo
     * 
     * @since 1.0.0
     * @version 1.3.0
     * @return void
     */
    public function flexify_dashboard_sidebar_logo() {
        ?>
        <div class="flexify-dashboard-menu-logo px-4 py-3">
            <a href="<?php echo admin_url(); ?>">
                <img class="logo" src="<?php echo esc_url( Init::get_setting('dashboard_logo') ); ?>">
            </a>

            <button id="close_sidebar" class="btn-close"></button>

            <button class="btn btn-icon btn-lg fs-4 navbar-collapse navbar-collapse-menu" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-title="<?php echo esc_attr( 'Mostrar o menu superior', 'flexify-dashboard' ) ?>">
                <i class="bx bx-menu"></i>
            </button>
        </div>
        <?php
    }
    

    /**
     * Add class 'dark-mode' to body on change theme mode
     * 
     * @since 1.0.0
     * @return array
     */
    public function flexify_dashboard_theme_mode_state( $classes ) {
        $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true );

        if ( isset( $theme_mode_state ) && $theme_mode_state === 'yes' ) {
            $classes .= 'dark-mode';
        }

        return $classes;
    }

    
    /**
     * Add copyright message to admin login footer
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_copyright_login() {
        echo '<div id="flexify-dashboard-login-image"></div>';
        echo '<p class="flexify-dashboard-copyright">'. sprintf( __( '&copy; %s %s. Todos os direitos reservados.', 'flexify-dashboard' ), date('Y'), get_bloginfo('name') ) .'</p>';
    }

    
    /**
     * Replace admin login logo URL
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_logo_url() {
        return home_url('/');
    }

    
    /**
     * Replace admin login logo alt name
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_logo_text() {
        return get_bloginfo('name');
    }

    
    /**
     * Add admin login styles
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_styles() {
        wp_enqueue_style( 'flexify-dashboard-login-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-login.css', array(), FLEXIFY_DASHBOARD_VERSION );
    }

    
    /**
     * Add admin login image on container
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_image() { 
        ?>
        <style type="text/css">
            @media screen and (min-width: 992px) {
                #flexify-dashboard-login-image {
                    background-image: url(<?php echo esc_url( Init::get_setting('admin_login_image') ); ?>);
                    background-repeat: no-repeat;
                    background-position: right;
                    background-size: cover;
                    height: 100vh;
                    width: 50%;
                }
            }
        </style>
        <?php
    }


    /**
     * Replace default logo on admin login page
     * 
     * @since 1.2.5
     * @return void
     */
    public function flexify_dashboard_admin_login_logo() {
        echo '<style type="text/css">
                .login h1 a {
                    background-image: url("'. esc_url( Init::get_setting('admin_login_logo') ) .'") !important;
                    background-color: #F8F9FA;
                    padding: 0.5rem;
                    border-radius: 100%;
                    background-position: center center;
                }
            </style>';
    }


    /**
     * Clear cache of functions that depend on order information when receiving a new order
     * 
     * @since 1.0.0
     * @version 1.3.0
     * @param int $order_id | Order ID
     * @return void
     */
    public function clear_cache_for_dependent_order_functions( $order_id ) {
        $order = wc_get_order( $order_id ); // get order object
        $order_total = $order->get_total();

        // check if order total is bigger then zero
        if ( $order_total > 0 ) {
            delete_transient('monthly_revenue_data');
            delete_transient('flexify_dashboard_get_order_count');
            delete_transient('flexify_dashboard_last_order_details_cache');
        }
    }


    /**
     * Set colors from root CSS
     * 
     * @since 1.3.0
     * @version 1.5.0
     * @return void
     */
    public function set_color_palette_root() {
        $primary = Init::get_setting('set_primary_color');
        $success = Init::get_setting('set_success_color');
        $warning = Init::get_setting('set_warning_color');
        $danger = Init::get_setting('set_danger_color');
        $info = Init::get_setting('set_info_color');
        $dark = Init::get_setting('set_dark_color'); ?>

        <style>
            :root {
                --flexify-dashboard-primary: <?php echo $primary ?>;
                --flexify-dashboard-primary-hover: <?php echo Helpers::convert_rgba_colors( $primary, -0.2, 100 ) ?>;
                --flexify-dashboard-primary-65: <?php echo Helpers::convert_rgba_colors( $primary, 0, 65 ) ?>;
                --flexify-dashboard-border: #d7dde2;
                --flexify-dashboard-bg-faded-primary: <?php echo Helpers::convert_rgba_colors( $primary, 0, 15 ) ?>;
                --flexify-dashboard-bg-faded-success: <?php echo Helpers::convert_rgba_colors( $success, 0, 15 ) ?>;
                --flexify-dashboard-bg-faded-danger: <?php echo Helpers::convert_rgba_colors( $danger, 0, 15 ) ?>;
                --flexify-dashboard-bg-faded-warning: <?php echo Helpers::convert_rgba_colors( $warning, 0, 15 ) ?>;
                --flexify-dashboard-bg-faded-info: <?php echo Helpers::convert_rgba_colors( $info, 0, 15 ) ?>;
                --flexify-dashboard-bg-faded-dark: <?php echo Helpers::convert_rgba_colors( $dark, 0, 15 ) ?>;
                --success-color: <?php echo $success ?>;
                --success-hover-color: <?php echo Helpers::convert_rgba_colors( $success, -0.2, 100 ) ?>;
                --danger-color: <?php echo $danger ?>;
                --danger-hover-color: <?php echo Helpers::convert_rgba_colors( $danger, -0.2, 100 ) ?>;
                --warning-color: <?php echo $warning ?>;
                --warning-hover-color: <?php echo Helpers::convert_rgba_colors( $warning, -0.2, 100 ) ?>;
                --info-color: <?php echo $info ?>;
                --info-hover-color: <?php echo Helpers::convert_rgba_colors( $info, -0.2, 100 ) ?>;
                --bs-primary: <?php echo $primary ?>;
                --bs-primary-rgb: <?php echo Helpers::generate_rgb_color( $primary ) ?>;
                --bs-success: <?php echo $success ?>;
                --bs-success-rgb: <?php echo Helpers::generate_rgb_color( $success ) ?>;
                --bs-warning: <?php echo $warning ?>;
                --bs-warning-rgb: <?php echo Helpers::generate_rgb_color( $warning ) ?>;
                --bs-danger: <?php echo $danger ?>;
                --bs-danger-rgb: <?php echo Helpers::generate_rgb_color( $danger ) ?>;
                --bs-info: <?php echo $info ?>;
                --bs-info-rgb: <?php echo Helpers::generate_rgb_color( $info ) ?>;
                --bs-dark: <?php echo $dark ?>;
                --bs-dark-rgb: <?php echo Helpers::generate_rgb_color( $dark ) ?>;
            }

            .btn-primary {
                --bs-btn-color: #fff;
                --bs-btn-bg: <?php echo $primary ?>;
                --bs-btn-border-color: <?php echo $primary ?>;
                --bs-btn-hover-color: #fff;
                --bs-btn-hover-bg: <?php echo Helpers::convert_rgba_colors( $primary, -0.2, 100 ) ?>;
                --bs-btn-hover-border-color: <?php echo Helpers::convert_rgba_colors( $primary, -0.21, 100 ) ?>;
                --bs-btn-focus-shadow-rgb: <?php echo Helpers::generate_rgb_color( $primary ) ?>;
                --bs-btn-active-color: #fff;
                --bs-btn-active-bg: <?php echo Helpers::convert_rgba_colors( $primary, -0.21, 100 ) ?>;
                --bs-btn-active-border-color: <?php echo Helpers::convert_rgba_colors( $primary, -0.22, 100 ) ?>;
                --bs-btn-active-shadow: inset 0 3px 5px rgba(0, 0, 0, 0.125);
                --bs-btn-disabled-color: #fff;
                --bs-btn-disabled-bg: <?php echo $primary ?>;
                --bs-btn-disabled-border-color: <?php echo $primary ?>;
            }
        </style>
        <?php
    }


    /**
     * Change Heartbeat API interval
     * 
     * @since 1.5.0
     * @see https://developer.wordpress.org/reference/hooks/heartbeat_settings/
     * @param array $settings | 
     * @return array
     */
    public function change_heartbeat_interval( $settings ) {
        if ( is_admin() ) {
            $settings['interval'] = Init::get_setting('set_admin_heartbeat_interval');
        } else {
            $settings['interval'] = Init::get_setting('set_front_heartbeat_interval');
        }

        return $settings;
    }


    /**
     * Add modal for search posts
     * 
     * @since 1.5.0
     * @return void
     */
    public function add_modal_search() {
        ?>
        <div class="modal fade" id="flexify_dashboard_search_posts" tabindex="-1" aria-labelledby="flexify_dashboard_search_posts_label" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header px-3 py-4">
                        <input class="form-control form-control-lg me-5 search-posts" id="flexify_dashboard_search" autocomplete="off" placeholder="<?php echo esc_attr( 'Digite para pesquisar...', 'flexify-dashboard' ); ?>"/>
                        <button type="button" class="btn-close me-2" data-bs-dismiss="modal" aria-label="<?php echo esc_attr( 'Fechar', 'flexify-dashboard' ) ?>"></button>
                    </div>
                    <div class="modal-body p-0">
                        <div id="flexify-dashboard-search-results"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

new Core();