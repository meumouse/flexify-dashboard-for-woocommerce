<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\Init;
use MeuMouse\Flexify_Dashboard\License;
use Automattic\WooCommerce\Internal\Admin\Orders\MetaBoxes;
use Automattic\WooCommerce\Internal\Traits\OrderAttributionMeta;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Widgets {

    private $flexify_dashboard_analytics;

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function __construct() {
        global $pagenow;

    //    $this->flexify_dashboard_analytics = Analytics();

        if ( $pagenow === 'index.php' ) {
            if ( Init::get_setting('enable_total_users_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_users_total_widget' ) );
            }

            if ( Init::get_setting('enable_products_registered_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_products_total_widget' ) );
            }

            if ( Init::get_setting('enable_average_ticket_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_average_ticket_widget' ) );
            }

            if ( Init::get_setting('enable_anual_billing_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_billing_store_widget' ) );
            }

            if ( Init::get_setting('enable_orders_number_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'add_woocommerce_orders_widget' ) );
            }

        /*    if ( Init::get_setting('enable_ga_integration') === 'yes' && $this->flexify_dashboard_analytics->config->options['token'] !== false ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_analytics_sessions_widget' ) );
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_sessions_pageviews_stats' ) );
            }*/

            if ( Init::get_setting('enable_last_orders_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_woocommerce_last_orders_widget' ) );
            }

            if ( Init::get_setting('enable_widget_best_selling_products') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'register_best_selling_products_widget' ) );
            }
        }
    }


    /**
     * Add users total widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_users_total_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_total_users_widget', // ID
            esc_html__( 'Usuários totais', 'flexify-dashboard' ), // widget display name
            array( $this, 'render_users_total_widget' ), // render content
        );
    }


    /**
     * Render HTML content for total users widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_users_total_widget() {
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-user"></i>
            </div>
    
            <span id="flexify_dashboard_get_total_users" class="fw-bold fs-4 mt-2 mb-1">
                <div class="placeholder-content" style="height: 50px; width: 100px"></div>
            </span>
    
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html__('Usuários totais', 'flexify-dashboard'); ?></span>
            </div>
        </div>
        <?php
    }


    /**
     * Add products total widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_products_total_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_total_products_widget', // ID
            esc_html( 'Produtos cadastrados', 'flexify-dashboard' ), // widget display name
            array( $this, 'render_products_total_widget' ), // render content
        );
    }


    /**
     * Render HTML content for total products widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_products_total_widget() {
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-purchase-tag"></i>
            </div>

            <span id="flexify_dashboard_get_total_products" class="fw-bold fs-4 mt-2 mb-1">
                <div class="placeholder-content" style="height: 50px; width: 100px"></div>
            </span>

            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html__('Produtos cadastrados', 'flexify-dashboard'); ?></span>
            </div>
        </div>
        <?php
    }    


    /**
     * Add average ticket widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_average_ticket_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_average_ticket_widget', // ID
            esc_html( 'Ticket médio', 'flexify-dashboard' ), // widget display name
            array( $this, 'render_average_ticket_widget' ), // render content
        );
    }

    /**
     * Register orders total WooCommerce widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function add_woocommerce_orders_widget() {
        wp_add_dashboard_widget(
            'woocommerce_orders_widget', // ID
            esc_html__( 'Pedidos do WooCommerce', 'flexify-dashboard' ), // widget display name
            array( $this, 'render_woocommerce_orders_widget' ), // render content
        );
    }


    /**
     * Render orders total WooCommerce widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_woocommerce_orders_widget() {
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-cart"></i>
            </div>

            <span id="flexify_dashboard_get_total_orders" class="fw-bold fs-4 mt-2 mb-1">
                <div class="placeholder-content" style="height: 50px; width: 100px"></div>
            </span>

            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html__('Pedidos recebidos', 'flexify-dashboard'); ?></span>
            </div>
        </div>
        <?php
    }

    
    /**
     * Render content for average ticket widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_average_ticket_widget() { ?>
        <div class="d-grid">
            <div class="d-flex justify-content-between">
                <div class="widget-icon">
                    <i class="bx bx-cart"></i>
                </div>

                <select id="flexify_dashboard_set_average_ticket_period" class="form-select form-select-sm w-auto">
                    <option value="12"><?php echo esc_html__('Últimos 12 meses', 'flexify-dashboard'); ?></option>
                    <option value="6"><?php echo esc_html__('Últimos 6 meses', 'flexify-dashboard'); ?></option>
                    <option value="3"><?php echo esc_html__('Últimos 3 meses', 'flexify-dashboard'); ?></option>
                    <option value="1"><?php echo esc_html__('Último mês', 'flexify-dashboard'); ?></option>
                </select>
            </div>
    
            <span id="average-ticket-amount" class="fw-bold fs-4 mt-2 mb-1">
                <div class="placeholder-content" style="height: 50px; width: 100px"></div>
            </span>
    
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html( 'Ticket médio', 'flexify-dashboard' ); ?></span>
            </div>
        </div>
        <?php 
    }    


    /**
     * Add billing last year screen widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function flexify_dashboard_billing_store_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_billing_store', // ID
            esc_html( 'Faturamento da loja', 'flexify-dashboard' ), // label
            array( $this, 'render_billing_store_widget' ), // render function
        );
    }
    

    /**
     * Render content for billing last year screen widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_billing_store_widget() {
        ?>
        <div class="d-flex align-items-center justify-content-between mb-3">
            <div class="monthly-sessions-title">
                <span class="fs-5 fw-semibold"><?php echo esc_html__('Faturamento', 'flexify-dashboard'); ?></span>
                <span class="fs-6 text-body-secondary mt-2 d-block billing-period-title"></span>
            </div>
        
            <select id="flexify_dashboard_set_billing_period" class="form-select form-select-sm">
                <option value="12"><?php echo esc_html__('Últimos 12 meses', 'flexify-dashboard'); ?></option>
                <option value="6"><?php echo esc_html__('Últimos 6 meses', 'flexify-dashboard'); ?></option>
                <option value="3"><?php echo esc_html__('Últimos 3 meses', 'flexify-dashboard'); ?></option>
                <option value="1"><?php echo esc_html__('Último mês', 'flexify-dashboard'); ?></option>
            </select>
        </div>
    
        <div id="flexify_dashboard_billing_store_chart">
            <div class="placeholder-content" style="height: 300px;">
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
            </div>
        </div>
        <?php
    }    


    /**
     * Add Analytics sessions widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_analytics_sessions_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_analytics_sessions',
            __( 'Sessões de usuários', 'flexify-dashboard' ),
            array( $this, 'render_flexify_dashboard_analytics_chart' ),
        );
    }


    /**
     * Render analytics sessions widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_flexify_dashboard_analytics_chart() {
        // get data from Analytics option
        $chart_data = get_option('flexify_dashboard_analytics_areachart', array());

        // Extract labels and data series from chart
        $labels = array();
        $series = array();

        foreach ( $chart_data as $data ) {
            if ( $data[0] !== 'Data' ) {
                $labels[] = $data[0];
                $series[] = $data[1];
            }
        }

        // Build the chart data
        $chart_data = array(
            'labels' => $labels,
            'series' => array(
                array(
                    'name' => esc_html('Sessões', 'flexify-dashboard'),
                    'data' => $series,
                ),
            ),
        );

        // send data from JS variable
        wp_localize_script('apexcharts', 'flexifyAnalyticsChartData', $chart_data); ?>

        <div class="monthly-sessions-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html('Visitas ao site', 'flexify-dashboard'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo esc_html('Últimos 30 dias', 'flexify-dashboard'); ?></span>
        </div>
        <div id="flexify_dashboard_month_sessions"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var options = {
                    chart: {
                        type: 'bar',
                        height: 350,
                        stacked: false,
                        zoom: {
                            enabled: true
                        },
                        toolbar: {
                            show: true
                        }
                    },
                    dataLabels: {
                        enabled: false
                    },
                    stroke: {
                        curve: 'smooth'
                    },
                    series: flexifyAnalyticsChartData.series,
                    xaxis: {
                        categories: flexifyAnalyticsChartData.labels,
                        labels: {
                            show: false,
                        }
                    },
                    tooltip: {
                        x: {
                            format: 'dd/MM/yy'
                        },
                    }
                };

                var chart = new ApexCharts(document.getElementById('flexify_dashboard_month_sessions'), options);
                chart.render();
            });
        </script>
        <?php
    }


    /**
     * Register sessions and pageviews stats widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_sessions_pageviews_stats() {
        wp_add_dashboard_widget(
            'flexify_dashboard_bottom_stats_donut', // ID
            esc_html( 'Estatísticas de sessões', 'flexify-dashboard' ), // label
            array( $this, 'render_sessions_pageviews_stats' ) // render function
        );
    }
    

    /**
     * Render sessions and pageviews stats widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_sessions_pageviews_stats() {
        // Get the option data
        $bottom_stats_data = get_option('flexify_dashboard_analytics_bottom_stats');

        // Extract the data for sessions and page views
        $sessions = $bottom_stats_data[0];
        $page_views = $bottom_stats_data[2];

        // Prepare translated labels for the chart
        $labels = array(
            esc_html('Sessões', 'flexify-dashboard'),
            esc_html('Page views', 'flexify-dashboard')
        ); ?>

        <div class="monthly-sessions-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html('Sessões vs Page views', 'flexify-dashboard'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo esc_html('Últimos 30 dias', 'flexify-dashboard'); ?></span>
        </div>
        <div id="flexify_dashboard_session_vs_pageviews"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var options = {
                    series: [<?php echo $sessions; ?>, <?php echo $page_views; ?>],
                    chart: {
                        width: 380,
                        type: 'donut',
                    },
                    dataLabels: {
                        enabled: false
                    },
                    responsive: [{
                        breakpoint: 480,
                        options: {
                            chart: {
                                width: 200
                            },
                            legend: {
                                show: false
                            }
                        }
                    }],
                    legend: {
                        position: 'right',
                        offsetY: 0,
                        height: 230,
                    },
                    labels: <?php echo json_encode($labels); ?>
                };

                var chart = new ApexCharts(document.getElementById('flexify_dashboard_session_vs_pageviews'), options);
                chart.render();
            });
        </script>
        <?php
    }


    /**
     * Register last orders widget
     * 
     * @since 1.3.0
     * @return void
     */
    public function flexify_dashboard_woocommerce_last_orders_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_last_orders', // ID
            esc_html__( 'Últimos pedidos do WooCommerce', 'flexify-dashboard' ), // widget display name
            array( $this, 'render_last_orders_widget' ), // render content callback
        );
    }

    /**
     * Render WooCommerce Orders Widget
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function render_last_orders_widget() {
        ?>
        <div class="monthly-sessions-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html__('Resumo de vendas', 'flexify-dashboard'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo sprintf( esc_html__('Últimos %s pedidos', 'flexify-dashboard'), Init::get_setting('get_last_order_number_query') ); ?></span>
        </div>
        <div id="orders-widget-container">
            <div class="placeholder-content" style="height: 260px;">
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
                <div class="placeholder-content_item"></div>
            </div>
        </div>
        <?php
    }


    /**
     * Register and display the best-selling products widget
     * 
     * @since 1.5.0
     * @return void
     */
    public function register_best_selling_products_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_best_selling_products', // Widget slug
            __('Produtos mais vendidos', 'flexify-dashboard'), // Widget title
            array( $this, 'render_best_selling_products_widget' ), // Callback to render the content
        );
    }


    /**
     * Render best-selling products widget
     * 
     * @since 1.5.0
     * @return void
     */
    public function render_best_selling_products_widget() {
        ?>
        <div class="d-flex align-items-center">
            <div class="widget-icon me-3">
                <i class="bx bx-crown"></i>
            </div>
            <span class="fs-5 fw-semibold"><?php echo esc_html__('Produtos mais vendidos', 'flexify-dashboard'); ?></span>
        </div>

        <span class="fs-6 text-body-secondary d-block mt-2 mb-3"><?php echo sprintf( esc_html__('Os %s produtos mais vendidos em sua loja', 'flexify-dashboard'), Init::get_setting('get_best_selling_products_query') ); ?></span>

        <div id="best-selling-products-widget">
            <div class="placeholder-content" style="height: 100px;">
                <div class="placeholder-content_item"></div>
            </div>
        </div>
        <?php
    }
}

new Widgets();