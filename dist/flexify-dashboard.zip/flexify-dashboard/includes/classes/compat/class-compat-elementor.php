<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with Elementor plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_Elementor {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_head', array( __CLASS__, 'add_compat_styles' ) );
	}


	/**
	 * Add admin styles for resolution breaks
	 * 
	 * @since 1.5.0
	 * @return string
	 */
	public static function add_compat_styles() {
		if ( ! defined('ELEMENTOR_VERSION') ) {
			return;
		}

		ob_start(); ?>

        #e-admin-top-bar-root {
            top: 8rem;
            box-shadow: none;
            padding-left: 1rem;
            height: 5rem;
            display: flex !important;
            align-items: center;
            justify-content: space-between;
            width: calc(100% - 18.125rem);
        }

        #e-admin-top-bar-root .e-admin-top-bar {
            width: 100%;
        }

        #elementor-new-template__form .elementor-form-field__select__wrapper:after {
            display: none;
        }

        #elementor-new-template__description {
            width: 50%;
            max-width: 500px;
        }

		<?php $css = ob_get_clean();
		$css = wp_strip_all_tags( $css );

		printf( __('<style>%s</style>'), $css );
	}
}

new Compat_Elementor();