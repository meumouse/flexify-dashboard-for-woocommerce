<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with WPForms plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_WPForms {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_head', array( __CLASS__, 'add_compat_styles' ) );
	}


	/**
	 * Add admin styles for resolution breaks
	 * 
	 * @since 1.5.0
	 * @return string
	 */
	public static function add_compat_styles() {
		if ( ! function_exists('wpforms') ) {
			return;
		}

		ob_start(); ?>

        .wpforms-dash-widget-settings {
            display: flex;
            align-items: center;
        }

        @media screen and (min-width: 992px) and (max-width: 1600px) {
            #wpforms_reports_widget_lite,
			#wpforms_reports_widget_pro {
				width: 196%;
			}
		}

		@media screen and (min-width: 1600px) {
            #wpforms_reports_widget_lite,
			#wpforms_reports_widget_pro {
				width: 194%;
			}
		}

		<?php $css = ob_get_clean();
		$css = wp_strip_all_tags( $css );

		printf( __('<style>%s</style>'), $css );
	}
}

new Compat_WPForms();