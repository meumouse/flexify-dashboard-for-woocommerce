<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\Init;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with WPCode plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_Version_Flexify_Dashboard {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'replace_settings_url' ) );
	}

	/**
	 * Replace settings URL for images
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function replace_settings_url() {
		if ( version_compare( FLEXIFY_DASHBOARD_VERSION, '1.5.0', '<' ) ) {
			return;
		}

		$current_dashboard_logo = Init::get_setting('dashboard_logo');
		$current_admin_login_image = Init::get_setting('admin_login_image');
		$current_admin_login_logo = Init::get_setting('admin_login_logo');
        $default_options = maybe_unserialize( get_option('flexify_dashboard_data_options', array()) );
        $plugin_old_slug = 'flexify-dashboard-for-woocommerce';

		// Update dashboard logo
		if ( $current_dashboard_logo && strpos( $current_dashboard_logo, $plugin_old_slug ) !== false ) {
			$default_options['dashboard_logo'] = esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-light.png' );

			update_option('flexify_dashboard_data_options', $default_options);
		}

		// Updates the admin login image
		if ( $current_admin_login_image && strpos( $current_admin_login_image, $plugin_old_slug ) !== false ) {
			$default_options['admin_login_image'] = esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/flexify-dashboard-login.jpg' );

			update_option('flexify_dashboard_data_options', $default_options);
		}

		// Updates the admin login logo
		if ( $current_admin_login_logo && strpos( $current_admin_login_logo, $plugin_old_slug ) !== false ) {
			$default_options['admin_login_logo'] = esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-single.png' );

			update_option('flexify_dashboard_data_options', $default_options);
		}
	}
}

new Compat_Version_Flexify_Dashboard();