<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with Rank Math plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_Rank_Math {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_head', array( __CLASS__, 'add_compat_styles' ) );
	}


	/**
	 * Add admin styles for resolution breaks
	 * 
	 * @since 1.5.0
	 * @return string
	 */
	public static function add_compat_styles() {
		if ( ! class_exists('RankMath') ) {
			return;
		}

		ob_start(); ?>

		#adminmenu .rm-menu-new.update-plugins {
			height: 10px;
    		width: 10px;
		}

		#wp-admin-bar-rank-math .rank-math-icon svg {
			margin-top: -0.7rem !important;
		}

		@media screen and (min-width: 992px) and (max-width: 1600px) {
			#rank_math_dashboard_widget {
				width: 196%;
			}
		}

		@media screen and (min-width: 1600px) {
			#rank_math_dashboard_widget {
				width: 194%;
			}
		}

		<?php $css = ob_get_clean();
		$css = wp_strip_all_tags( $css );

		printf( __('<style>%s</style>'), $css );
	}
}

new Compat_Rank_Math();