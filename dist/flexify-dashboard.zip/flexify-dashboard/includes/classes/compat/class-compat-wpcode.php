<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with WPCode plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_WPCode {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_head', array( __CLASS__, 'add_compat_styles' ) );
	}


	/**
	 * Add admin styles for resolution breaks
	 * 
	 * @since 1.5.0
	 * @return string
	 */
	public static function add_compat_styles() {
		if ( ! class_exists('WPCode') ) {
			return;
		}

		ob_start();

		$url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
		
		if ( strpos( $url, 'admin.php?page=wpcode' ) !== false ) : ?>
			#wpbody-content {
				padding: 0;
			}

			#wpcode-header-between {
				display: none;
			}
		<?php endif;

		$css = ob_get_clean();
		$css = wp_strip_all_tags( $css );

		printf( __('<style>%s</style>'), $css );
	}
}

new Compat_WPCode();