<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Compatibility with Loco Translate plugin
 *
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Compat_Loco_Translate {

	/**
	 * Construct function
	 * 
	 * @since 1.5.0
	 * @return void
	 */
	public function __construct() {
		add_action( 'admin_head', array( __CLASS__, 'add_compat_styles' ) );
	}


	/**
	 * Add admin styles for resolution breaks
	 * 
	 * @since 1.5.0
	 * @return string
	 */
	public static function add_compat_styles() {
		if ( ! function_exists('loco_plugin_file') ) {
			return;
		}

		ob_start(); ?>

        #loco-admin.wrap div.progress {
            display: block;
            background-color: #e9ecef !important;
        }

		<?php $css = ob_get_clean();
		$css = wp_strip_all_tags( $css );

		printf( __('<style>%s</style>'), $css );
	}
}

new Compat_Loco_Translate();