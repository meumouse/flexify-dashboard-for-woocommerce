<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\Init;
use MeuMouse\Flexify_Dashboard\License;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Load dependencies and scripts
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Assets {

    /**
     * Construc function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
        add_action( 'admin_head', array( $this, 'change_loader_icon' ) );

        if ( Init::get_setting('enable_flexify_dashboard_login_page') === 'yes' ) {
            add_action( 'login_enqueue_scripts', array( $this, 'load_icons_on_login_page' ) );
        }

        // show or hide apexcharts toolbox 
        if ( Init::get_setting('enable_apexcharts_toolbar') !== 'yes' ) {
            add_action( 'admin_head', array( $this, 'show_apexcharts_toolbox' ) );
        }

        // scrollbar styles
        $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true );

        if ( isset( $theme_mode_state ) && $theme_mode_state === 'yes' ) {
            add_action( 'admin_head', array( $this, 'scrollbar_dark_styles' ) );
        }

        // show or hide adminbar
        add_action( 'admin_head', array( $this, 'show_wp_adminbar' ) );
    }


    /**
     * Enqueue dependencies
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function admin_assets() {
        wp_enqueue_script( 'flexify-dashboard-cookies', FLEXIFY_DASHBOARD_ASSETS_URL . 'components/cookies/set-and-get-cookies.js', array(), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_script( 'flexify-dashboard-install-modules', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/install-modules.js', array(), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_script( 'flexify-dashboard-visibility-controller', FLEXIFY_DASHBOARD_ASSETS_URL . 'components/visibility-controller/visibility-controller.min.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );

        wp_enqueue_style( 'flexify-dashboard-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard.css', array(), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_script( 'flexify-dashboard-global', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-global.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_style( 'flexify-dashboard-bootstrap-components', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/bootstrap-components.css', array(), FLEXIFY_DASHBOARD_VERSION );
        
        wp_enqueue_style( 'bootstrap-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/bootstrap/css/bootstrap.min.css', array(), '5.3.2' );
        wp_enqueue_script( 'bootstrap-bundle', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/bootstrap/js/bootstrap.bundle.min.js', array('jquery'), '5.3.2' );
        wp_enqueue_style( 'boxicons', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );

        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        
        if ( strpos( $url, 'admin.php?page=flexify-dashboard' ) !== false ) {
            wp_enqueue_media();

            wp_enqueue_style( 'flexify-dashboard-admin-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-admin.css', array(), FLEXIFY_DASHBOARD_VERSION );
            wp_enqueue_script( 'flexify-dashboard-admin-scripts', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-admin-scripts.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );

            wp_localize_script( 'flexify-dashboard-admin-scripts', 'flexify_dashboard_admin_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'sidebar_logo_title' => esc_html( 'Escolher logo da barra lateral', 'flexify-dashboard' ),
                'use_this_image' => esc_html( 'Usar esta imagem', 'flexify-dashboard' ),
                'admin_login_title' => esc_html( 'Escolher imagem para área administrativa', 'flexify-dashboard' ),
                'admin_login_logo_title' => esc_html( 'Escolher logo para área administrativa', 'flexify-dashboard' ),
                'toast_error' => esc_html__( 'Ops! Ocorreu um erro.', 'flexify-dashboard' ),
                'toast_success_license' => esc_html__( 'Licença ativada com sucesso!', 'flexify-dashboard' ),
                'active_license_message' => esc_html__( 'Todos os recursos da versão Pro agora estão ativos!', 'flexify-dashboard' ),
                'confirm_deactivate_license' => esc_html__( 'Tem certeza que deseja desativar sua licença?', 'flexify-dashboard' ),
            ) );
        }

        $screen = get_current_screen();

        if ( $screen->id === 'dashboard' ) {
            wp_enqueue_script( 'apexcharts', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/apexcharts/apexcharts.min.js', array(), '3.50.0', true );
            wp_enqueue_script( 'flexify-dashboard-widgets', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/dashboard-widgets.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        }

        // load dark styles
        if ( Init::get_setting('enable_dark_mode') === 'yes' && ! in_array( $screen->id, array('post', 'product', 'page') ) ) {
            wp_enqueue_style( 'flexify-dashboard-dark-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-dark.css', array(), FLEXIFY_DASHBOARD_VERSION );
            wp_enqueue_script( 'flexify-dashboard-theme-mode', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-theme-mode.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        }

        // load navbar search script
        if ( Init::get_setting('enable_admin_search_posts') === 'yes' ) {
            wp_enqueue_script( 'flexify-dashboard-search', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-ajax-search.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );

            wp_localize_script( 'flexify-dashboard-search', 'fd_search_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
            ));
        }

        // load product editor
        if ( isset( $screen->id ) && in_array( $screen->id, array( 'product' ) ) ) {
            wp_enqueue_style( 'flexify-dashboard-product-editor-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-product-editor.css', array(), FLEXIFY_DASHBOARD_VERSION );
        }

        wp_localize_script( 'flexify-dashboard-widgets', 'fd_widgets_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'origin_title' => esc_html__( 'Origem', 'flexify-dashboard' ),
            'order_id_title' => esc_html__( 'ID do pedido', 'flexify-dashboard' ),
            'customer_title' => esc_html__( 'Cliente', 'flexify-dashboard' ),
            'order_total_title' => esc_html__( 'Valor do pedido', 'flexify-dashboard' ),
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'billing_nonce' => wp_create_nonce('billing_data_nonce'),
            'last_orders_nonce' => wp_create_nonce('last_orders_nonce'),
            'average_tickets_nonce' => wp_create_nonce('average_tickets'),
            'total_users' => wp_create_nonce('total_users_nonce'),
            'total_products' => wp_create_nonce('total_products_nonce'),
            'total_orders' => wp_create_nonce('total_orders_nonce'),
            'best_selling_products' => wp_create_nonce('best_selling_products_nonce'),
        ));

        wp_localize_script( 'flexify-dashboard-install-modules', 'fd_modules_params', array(
            'ajax_url' => admin_url('admin-ajax.php'),
        ));

        wp_localize_script( 'flexify-dashboard-global', 'fd_global_params', array(
            'empty_widgets' => esc_html__( 'Nenhum widget para exibir nesta tela.', 'flexify-dashboard' ),
        ));
    }


    /**
     * Change default loader
     * 
     * @since 1.0.0
     * @return void
     */
    public function change_loader_icon() {
        $icon = FLEXIFY_DASHBOARD_ASSETS_URL . 'img/loader.gif';
    
        echo '<style>
            .spinner {
                background: url(' . esc_url( $icon ) . ') no-repeat;
                background-size: 4rem;
                width: 4rem;
                height: 4rem;
            }
        </style>';
    }


    /**
     * Hide Apexcharts toolbox
     * 
     * @since 1.0.0
     * @return void
     */
    public function show_apexcharts_toolbox() {
        echo '<style>
            .apexcharts-toolbar {
                display: none !important;
            }
        </style>';
    }


    /**
     * Show or hide adminbar
     * 
     * @since 1.2.0
     * @return void
     */
    public function show_wp_adminbar() {
        if ( Init::get_setting('enable_admin_bar') === 'yes' ) {
            echo '<style>
                .flexify-dashboard-menu-logo,
                #flexify-dashboard-navbar {
                    top: 2rem;
                }

                #adminmenu {
                    margin-top: 2rem;
                }
            </style>';
        } else {
            echo '<style>
                body.wp-admin #wpadminbar {
                    display: none;
                }
            </style>';
        }
    }


    /**
     * Add scrollbar dark styles
     * 
     * @since 1.0.0
     * @return void
     */
    public function scrollbar_dark_styles() {
        echo '<style>
            ::-webkit-scrollbar-track {
                background-color: #6C757D !important; 
            }
            
            ::-webkit-scrollbar-thumb {
                background-color: var(--flexify-dashboard-border-dark) !important;
                border-radius: 50px;
            }
        </style>';
    }


    /**
     * Load Boxicons on login page
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function load_icons_on_login_page() {
        wp_enqueue_style( 'boxicons', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
    }
}

new Assets();