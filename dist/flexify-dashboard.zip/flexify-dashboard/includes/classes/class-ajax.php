<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\License;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Class for handle AJAX callbacks
 * 
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Ajax {

    /**
     * Construct function
     * 
     * @since 1.5.0
     * @return void
     */
    public function __construct() {
        // save admin options panel
        add_action( 'wp_ajax_flexify_dashboard_ajax_save_options', array( $this, 'ajax_save_options_callback' ) );
        
        // get license file .key and process
        add_action( 'wp_ajax_fd_alternative_activation_license', array( $this, 'alternative_activation_callback' ) );
        
        // save user theme mode
        add_action( 'wp_ajax_save_theme_mode_state', array( $this, 'save_theme_mode_state_callback' ) );
        
        // navbar search
        add_action( 'wp_ajax_flexify_dashboard_search', array( $this, 'flexify_dashboard_search_callback' ) );

        // get last orders
        add_action( 'wp_ajax_get_last_orders', array( $this, 'get_last_orders_callback' ) );

        // get billing data
        add_action( 'wp_ajax_get_billing_data', array( $this, 'get_billing_data_callback' ) );

        // get average ticket
        add_action( 'wp_ajax_get_average_ticket', array( $this, 'process_ajax_average_ticket' ) );

        // get total users
        add_action( 'wp_ajax_get_total_users', array( $this, 'process_ajax_total_users' ) );

        // get total products
        add_action( 'wp_ajax_get_total_products', array( $this, 'process_ajax_total_products' ) );

        // get total orders on WooCommerce
        add_action( 'wp_ajax_get_total_orders', array( $this, 'process_ajax_total_orders' ) );

        // get best sellers products
        add_action( 'wp_ajax_get_best_selling_products', array( $this, 'process_ajax_best_selling_products' ) );
    }


    /**
     * Save options in AJAX
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function ajax_save_options_callback() {
        if ( isset( $_POST['action'] ) && $_POST['action'] === 'flexify_dashboard_ajax_save_options' ) {
            // Convert serialized data into an array
            parse_str( $_POST['form_data'], $form_data );

            $options = maybe_unserialize( get_option('flexify_dashboard_data_options', array()) );
            $options['enable_ga_integration'] = isset( $form_data['enable_ga_integration'] ) ? 'yes' : 'no';
            $options['enable_meta_pixel_integration'] = isset( $form_data['enable_meta_pixel_integration'] ) ? 'yes' : 'no';
            $options['enable_apexcharts_toolbar'] = isset( $form_data['enable_apexcharts_toolbar'] ) ? 'yes' : 'no';
            $options['enable_admin_search_posts'] = isset( $form_data['enable_admin_search_posts'] ) ? 'yes' : 'no';
            $options['enable_dark_mode'] = isset( $form_data['enable_dark_mode'] ) ? 'yes' : 'no';
            $options['enable_product_cost_info'] = isset( $form_data['enable_product_cost_info'] ) ? 'yes' : 'no';
            $options['enable_total_users_widget'] = isset( $form_data['enable_total_users_widget'] ) ? 'yes' : 'no';
            $options['enable_anual_billing_widget'] = isset( $form_data['enable_anual_billing_widget'] ) ? 'yes' : 'no';
            $options['enable_average_ticket_widget'] = isset( $form_data['enable_average_ticket_widget'] ) ? 'yes' : 'no';
            $options['enable_orders_number_widget'] = isset( $form_data['enable_orders_number_widget'] ) ? 'yes' : 'no';
            $options['enable_products_registered_widget'] = isset( $form_data['enable_products_registered_widget'] ) ? 'yes' : 'no';
            $options['enable_recaptcha_admin_login'] = isset( $form_data['enable_recaptcha_admin_login'] ) ? 'yes' : 'no';
            $options['enable_admin_bar'] = isset( $form_data['enable_admin_bar'] ) ? 'yes' : 'no';
            $options['enable_flexify_dashboard_login_page'] = isset( $form_data['enable_flexify_dashboard_login_page'] ) ? 'yes' : 'no';
            $options['enable_last_orders_widget'] = isset( $form_data['enable_last_orders_widget'] ) ? 'yes' : 'no';
            $options['enable_flexify_dashboard_loader_pages'] = isset( $form_data['enable_flexify_dashboard_loader_pages'] ) ? 'yes' : 'no';
			$options['enable_custom_heartbeat_control'] = isset( $form_data['enable_custom_heartbeat_control'] ) ? 'yes' : 'no';

            // Merge the form data with the default options
            $updated_options = wp_parse_args( $form_data, $options );

            // Get existing options from flexify_dashboard_analytics_options
            $ga_options = get_option('flexify_dashboard_analytics_options', array());
         //   $ga_options = json_decode( $ga_options );

            if ( isset( $form_data['ga_client_id'] ) ) {
                $ga_options->client_id = $form_data['ga_client_id'];
            }

            if ( isset( $form_data['ga_client_secret'] ) ) {
                $ga_options->client_secret = $form_data['ga_client_secret'];
            }

            if ( isset( $form_data['ga_map_target_country'] ) ) {
                $ga_options->ga_target_geomap = $form_data['ga_map_target_country'];
            }

            if ( isset( $form_data['ga_google_maps_api_key'] ) ) {
                $ga_options->maps_api_key = $form_data['ga_google_maps_api_key'];
            }

            if ( isset( $form_data['options']['webstream_jail'] ) ) {
                $ga_options->webstream_jail = $form_data['options']['webstream_jail'];
            }

            // Save updates to flexify_dashboard_analytics_options
            update_option( 'flexify_dashboard_analytics_options', json_encode( $ga_options ) );

            // Delete cache of last orders when changing order query number
            if ( isset( $form_data['get_last_order_number_query'] ) ) {
                delete_transient('flexify_dashboard_last_order_details_cache');
            }

            // Save the updated options
            $saved_options = update_option( 'flexify_dashboard_data_options', maybe_serialize( $updated_options ) );

            if ( $saved_options ) {
				$response = array(
					'status' => 'success',
					'toast_header_title' => esc_html__( 'Salvo com sucesso', 'flexify-dashboard' ),
					'toast_body_title' => esc_html__( 'As configurações foram atualizadas!', 'flexify-dashboard' ),
					'options' => $updated_options,
				);

				wp_send_json( $response ); // Send JSON response
			}
        }
    }


    /**
     * Handle alternative activation license file .key
     * 
     * @since 1.3.0
     * @version 1.5.0
     * @return void
     */
    public function alternative_activation_callback() {
        if ( ! isset( $_POST['action'] ) || $_POST['action'] !== 'fd_alternative_activation_license' ) {
            $response = array(
                'status' => 'error',
                'message' => __( 'Erro ao carregar o arquivo. A ação não foi acionada corretamente.', 'flexify-dashboard' ),
            );

            wp_send_json( $response );
        }

        // Checks if the file was sent
        if ( empty( $_FILES['file'] ) ) {
            $response = array(
                'status' => 'error',
                'message' => __( 'Erro ao carregar o arquivo. O arquivo não foi enviado.', 'flexify-dashboard' ),
            );

            wp_send_json( $response );
        }

        $file = $_FILES['file'];

        // Checks if it is a .key file
        if ( pathinfo( $file['name'], PATHINFO_EXTENSION ) !== 'key' ) {
            $response = array(
                'status' => 'invalid_file',
                'message' => __( 'Arquivo inválido. O arquivo deve ser extensão .key', 'flexify-dashboard' ),
            );
            
            wp_send_json( $response );
        }

        // Read the contents of the file
        $file_content = file_get_contents( $file['tmp_name'] );

        $decrypt_keys = array(
            '3D5766063EF7E2B5', // original product key
            'B729F2659393EE27', // Clube M
        );

        $decrypted_data = License::decrypt_alternative_license( $file_content, $decrypt_keys );

        if ( $decrypted_data !== null ) {
            update_option( 'flexify_dashboard_alternative_license_decrypted', $decrypted_data );
            
            $response = array(
                'status' => 'success',
                'message' => __( 'Licença enviada e decriptografada com sucesso.', 'flexify-dashboard' ),
            );
        } else {
            $response = array(
                'status' => 'error',
                'message' => __( 'Não foi possível descriptografar o arquivo de licença.', 'flexify-dashboard' ),
            );
        }

        wp_send_json( $response );
    }


    /**
     * Save theme mode state in AJAX
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function save_theme_mode_state_callback() {
        $theme_mode_state = sanitize_text_field( $_POST['theme_mode_state'] );

        // update user option
        update_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', $theme_mode_state );
        
        $response = array(
            'status' => 'success',
        );
        
        wp_send_json( $response ); // Send JSON response
    }


    /**
     * Search posts of blog, produts and pages in AJAX
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function flexify_dashboard_search_callback() {
        $search_term = sanitize_text_field( $_POST['search_term'] );

        // query post type product
        $product_query = new \WP_Query( array(
            'post_type' => 'product',
            's' => $search_term,
        ));
    
        // query post type page
        $page_query = new \WP_Query( array(
            'post_type' => 'page',
            's' => $search_term,
        ));
    
        // query posts of blog
        $blog_query = new \WP_Query( array(
            'post_type' => 'post',
            's' => $search_term,
        ));
    
        // init HTML container
        $output = '';
    
        // get products
        if ( $product_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Produtos:', 'flexify-dashboard') . '</h4>';
            $output .= '<ul class="product-list">';
            
            while ( $product_query->have_posts() ) {
                $product_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';

                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // get pages
        if ( $page_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Páginas:', 'flexify-dashboard') . '</h4>';
            $output .= '<ul class="page-list">';

            while ( $page_query->have_posts() ) {
                $page_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';

                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // get posts of blog
        if ( $blog_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Postagens do blog:', 'flexify-dashboard') . '</h4>';
            $output .= '<ul class="blog-post-list">';
            
            while ( $blog_query->have_posts() ) {
                $blog_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';
                
                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // Restore global post information
        wp_reset_postdata();
    
        wp_send_json( $output );
    }


    /**
     * Get last orders in AJAX callback
     * 
     * @since 1.5.0
     * @return void
     */
    public function get_last_orders_callback() {
        // Check the nonce for security
        check_ajax_referer('last_orders_nonce', 'nonce');
    
        // Get the latest orders
        $orders = get_transient('flexify_dashboard_last_order_details_cache');
    
        if ( false === $orders || empty( $orders ) ) {
            $orders = get_latest_orders_details();
            set_transient('flexify_dashboard_last_order_details_cache', $orders, HOUR_IN_SECONDS);
        }
    
        $origin_filter = flexify_dashboard_origin_filter();
    
        // Add origin information to each order
        foreach ( $orders as &$order ) {
            $order['origin_icon'] = $origin_filter[$order['order_origin']]['icon'];
            $order['origin_label'] = $origin_filter[$order['order_origin']]['label'];
        }
    
        // Return orders in JSON format
        wp_send_json_success( $orders );
    }


    /**
     * Get billing data for create charts on AJAX callback
     * 
     * @since 1.5.0
     * @return void
     */
    public function get_billing_data_callback() {
        check_ajax_referer('billing_data_nonce', 'nonce');
        $period = intval( $_POST['period'] );

        if ( $period <= 0 ) {
            wp_send_json_error('Invalid period');
        }
    
        $monthly_revenue = get_monthly_revenue_data();
        $last_months = array_slice( array_keys( $monthly_revenue ), -$period );

        $filtered_chart_data = array(
            'labels' => array_values( $last_months ),
            'series' => array(
                array(
                    'name' => esc_html('Faturamento bruto do mês', 'flexify-dashboard'),
                    'data' => array_column( array_values( array_intersect_key( $monthly_revenue, array_flip( $last_months ) ) ), 'revenue_gross'),
                ),
                array(
                    'name' => esc_html('Faturamento líquido do mês', 'flexify-dashboard'),
                    'data' => array_column( array_values( array_intersect_key( $monthly_revenue, array_flip( $last_months ) ) ), 'revenue_net'),
                ),
            ),
        );
    
        wp_send_json_success( $filtered_chart_data );
    }


    /**
     * Process AJAX request for average ticket
     * 
     * @since 1.5.0
     * @return void
     */
    public function process_ajax_average_ticket() {
        check_ajax_referer('average_tickets', 'nonce');

        $period = isset( $_POST['period'] ) ? intval( $_POST['period'] ) : 12;
        $get_data = get_monthly_revenue_data( $period );
        $total_gross = 0;
        $total_orders = 0;

        foreach ( $get_data as $month_data ) {
            $total_gross += $month_data['revenue_gross'];
            $total_orders += $month_data['order_count_completed'];
        }

        // Calculate the overall average ticket
        $average_ticket = $total_orders > 0 ? $total_gross / $total_orders : 0;

        wp_send_json_success( array(
            'average_ticket' => wc_price( $average_ticket ),
        ));
    }
    

    /**
     * Process AJAX request for total users count
     * 
     * @since 1.5.0
     * @return void
     */
    public function process_ajax_total_users() {
        check_ajax_referer('total_users_nonce', 'nonce');

        $total_users = count_users()['total_users'];

        wp_send_json_success( array(
            'total_users' => $total_users,
        ));
    }


    /**
     * Process AJAX request for total products count
     * 
     * @since 1.5.0
     * @return void
     */
    public function process_ajax_total_products() {
        check_ajax_referer('total_products_nonce', 'nonce');

        $total_products = wp_count_posts('product')->publish;

        wp_send_json_success( array(
            'total_products' => $total_products,
        ));
    }

    
    /**
     * Process AJAX request for total WooCommerce orders count
     * 
     * @since 1.5.0
     * @return void
     */
    public function process_ajax_total_orders() {
        check_ajax_referer('total_orders_nonce', 'nonce');

        // Check if the transient exists
        $order_count = get_transient('flexify_dashboard_get_order_count');

        // If transient doesn't exist, make the database query
        if (false === $order_count) {
            global $wpdb;

            $total_order_count = $wpdb->get_var("
                SELECT COUNT(ID)
                FROM {$wpdb->prefix}posts
                WHERE post_type = 'shop_order'
                AND post_status IN ('wc-processing', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed', 'wc-on-hold')
            ");

            // Cache the result for 1 day
            set_transient('flexify_dashboard_get_order_count', $total_order_count, DAY_IN_SECONDS);
        } else {
            // Use the cached result
            $total_order_count = $order_count;
        }

        wp_send_json_success(array(
            'total_orders' => $total_order_count,
        ));
    }


    /**
     * Process AJAX request for best-selling products
     * 
     * @since 1.5.0
     * @return void
     */
    public function process_ajax_best_selling_products() {
        check_ajax_referer('best_selling_products_nonce', 'nonce');

        $get_query = Init::get_setting('get_best_selling_products_query');
        $best_selling_products = get_best_selling_products( $get_query );

        if ( ! empty( $best_selling_products ) ) {
            $response = '<div class="table-responsive"><table class="table">';
            $response .= '<thead><tr>';
            $response .= '<th scope="col">#</th>';
            $response .= '<th scope="col">' . esc_html__('Produto', 'flexify-dashboard') . '</th>';
            $response .= '<th scope="col">' . esc_html__('Pedidos', 'flexify-dashboard') . '</th>';
            $response .= '<th scope="col">' . esc_html__('Faturamento', 'flexify-dashboard') . '</th>';
            $response .= '</tr></thead><tbody>';

            $index = 1;

            foreach ( $best_selling_products as $product ) {
                $response .= '<tr>';
                $response .= '<td class="align-middle py-3">' . esc_html( $index++ ) . '</td>';
                $response .= '<td class="align-middle"><a href="' . get_edit_post_link( $product['ID'] ) . '">' . esc_html( $product['post_title'] ) . '</a></td>';
                $response .= '<td class="align-middle">' . esc_html( $product['order_count'] ) . '</td>';
                $response .= '<td class="align-middle">' . wc_price( $product['total_revenue'] ) . '</td>';
                $response .= '</tr>';
            }

            $response .= '</tbody></table></div>';

            wp_send_json_success( $response );
        } else {
            wp_send_json_error( __('Nenhum produto encontrado', 'flexify-dashboard') );
        }
    }
}

new Ajax();