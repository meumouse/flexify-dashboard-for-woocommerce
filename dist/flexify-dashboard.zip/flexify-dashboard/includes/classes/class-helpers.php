<?php

namespace MeuMouse\Flexify_Dashboard;

/**
 * Helpers functions
 * 
 * @since 1.5.0
 * @package MeuMouse.com
 */
class Helpers {

    /**
     * Converts hex color to RGBA
     * 
     * @since 1.5.0
     * @param string $hex | Hexadecimal color
     * @param float $brightness | (Optional) Brightness adjusment 
     * @param int $opacity | (Optional) Opacity color
     * @return string RGBA color
     * 
     * E.g: convert_rgba_colors( '#3498db', 0.2, 80 ) - Lighter color at 80% opacity
     * E.g:  convert_rgba_colors( '#3498db', -0.2, 50 ) - Darker color at 50% opacity
     */
    public static function convert_rgba_colors( $hex, $brightness = 0, $opacity = 100 ) {
        // Remove the '#' character if present
        $hex = str_replace( '#', '', $hex );
    
        // Converts hexadecimal color to RGB values
        if ( strlen( $hex ) == 6 ) {
            list( $r, $g, $b ) = [
                hexdec( substr( $hex, 0, 2 ) ),
                hexdec( substr( $hex, 2, 2 ) ),
                hexdec( substr( $hex, 4, 2 ) )
            ];
        } elseif ( strlen( $hex ) == 3 ) {
            list( $r, $g, $b ) = [
                hexdec( str_repeat( substr( $hex, 0, 1 ), 2 ) ),
                hexdec( str_repeat( substr( $hex, 1, 1 ), 2 ) ),
                hexdec( str_repeat( substr( $hex, 2, 1 ), 2 ) ),
            ];
        } else {
            throw new InvalidArgumentException('Formato de cor hexadecimal inválido');
        }
    
        // Adjusts color based on adjustment factor
        $r = max( 0, min( 255, $r + ( $brightness * 255 ) ) );
        $g = max( 0, min( 255, $g + ( $brightness * 255 ) ) );
        $b = max( 0, min( 255, $b + ( $brightness * 255 ) ) );
    
        // Normalize opacity
        $opacity = max( 0, min( 100, $opacity ) ) / 100;
    
        // Returns the color in RGBA format
        return "rgba($r, $g, $b, $opacity)";
    }


    /**
     * Generate RGB color from hexadecimal color
     * 
     * @since 1.3.0
     * @param string $color | Color hexadecimal
     * @return string RGB color
     */
    public static function generate_rgb_color( $color ) {
        // removes the "#" character if present 
        $color = str_replace("#", "", $color);

        // gets the RGB decimal value of each color component
        $red = hexdec( substr( $color, 0, 2 ) );
        $green = hexdec( substr( $color, 2, 2 ) );
        $blue = hexdec( substr( $color, 4, 2 ) );

        // generates RGBA color based on foreground color
        $rgb_color = "$red, $green, $blue";

        return $rgb_color;
    }
}

new Helpers();