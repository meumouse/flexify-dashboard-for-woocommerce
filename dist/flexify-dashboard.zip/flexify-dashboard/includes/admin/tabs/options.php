<?php

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="general" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar caixa de ferramentas para gráficos', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar as ferramentas para análise de gráficos.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_apexcharts_toolbar" name="enable_apexcharts_toolbar" value="yes" <?php checked( self::get_setting('enable_apexcharts_toolbar') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar pesquisa de posts', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar a caixa de pesquisa de posts na barra superior.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_admin_search_posts" name="enable_admin_search_posts" value="yes" <?php checked( self::get_setting('enable_admin_search_posts') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar modo escuro', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o seletor de modo escuro.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_dark_mode" name="enable_dark_mode" value="yes" <?php checked( self::get_setting('enable_dark_mode') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar barra de administração', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar a barra de administração superior.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_admin_bar" name="enable_admin_bar" value="yes" <?php checked( self::get_setting('enable_admin_bar') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar página de login administrativo', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para carregar os estilos da página de login administrativo.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_flexify_dashboard_login_page" name="enable_flexify_dashboard_login_page" value="yes" <?php checked( self::get_setting('enable_flexify_dashboard_login_page') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar animação de carregamento de páginas', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar a animação de carregamento enquanto o DOM é criado.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_flexify_dashboard_loader_pages" name="enable_flexify_dashboard_loader_pages" value="yes" <?php checked( self::get_setting('enable_flexify_dashboard_loader_pages') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr class="container-separator"></tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar alteração de tempo da API Heartbeat do WordPress', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para controlar o tempo de resposta entre ações não agendadas, permitindo aumentar desempenho em ações AJAX.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_custom_heartbeat_control" name="enable_custom_heartbeat_control" value="yes" <?php checked( self::get_setting('enable_custom_heartbeat_control') === 'yes' ); ?> />

               <button class="btn btn-sm btn-outline-primary ms-3 require-enabled-heartbeat-control" data-bs-toggle="modal" data-bs-target="#heartbeat_settings_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></button>

               <div class="modal fade" id="heartbeat_settings_modal" tabindex="-1" aria-labelledby="heartbeat_settings_label" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h1 class="modal-title fs-5" id="heartbeat_settings_label"><?php echo esc_html__( 'Configurar API Heartbeat do WordPress', 'flexify-dashboard' ) ?></h1>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_html__( 'Fechar', 'flexify-dashboard' ) ?>"></button>
                        </div>

                        <div class="modal-body">
                           <table class="popup-table">
                              <tbody>
                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'Tempo da API Heartbeat para administração', 'flexify-dashboard' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__( 'Informe o tempo em segundos entre cada consulta e resposta da API Heartbeat para a visão de administradores. O tempo padrão é de 15 segundos.', 'flexify-dashboard' ) ?></span>
                                    </th>
                                    <td>
                                       <input type="number" class="form-control input-control-wd-5" id="set_admin_heartbeat_interval" name="set_admin_heartbeat_interval" value="<?php echo self::get_setting('set_admin_heartbeat_interval') ?>"/>
                                    </td>
                                 </tr>

                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'Tempo da API Heartbeat para front-end', 'flexify-dashboard' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__( 'Informe o tempo em segundos entre cada consulta e resposta da API Heartbeat para a visão de usuários. O tempo padrão é de 60 segundos.', 'flexify-dashboard' ) ?></span>
                                    </th>
                                    <td>
                                       <input type="number" class="form-control input-control-wd-5" id="set_front_heartbeat_interval" name="set_front_heartbeat_interval" value="<?php echo self::get_setting('set_front_heartbeat_interval') ?>"/>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </td>
      </tr>
   </table>
</div>