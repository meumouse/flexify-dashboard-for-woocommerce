<?php

use MeuMouse\Flexify_Dashboard\Init;

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="extensions" class="nav-content">
    <?php
    /**
     * Add custom card extension on start section
     * 
     * @since 1.5.0
     */
    do_action('flexify_dashboard_start_extensions'); ?>

    <div class="cards-group ps-5 mb-5">
        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg width="800px" height="800px" viewBox="-14 0 284 284" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid"><g><path d="M256.003159,247.933017 C256.055907,258.030289 251.77298,267.664804 244.241349,274.390297 C236.709718,281.11579 226.653817,284.285366 216.626905,283.094249 C198.58347,280.424364 185.360959,264.722632 185.800619,246.488035 L185.800619,36.8452103 C185.364944,18.5907614 198.619678,2.88144681 216.687112,0.238996295 C226.704325,-0.933476157 236.743571,2.24455542 244.261279,8.9678962 C251.778988,15.691237 256.053811,25.3147619 256.003159,35.4002282 L256.003159,247.933017 Z" fill="#F9AB00"></path><path d="M35.1010243,213.193238 C54.4867848,213.193238 70.2020487,228.908502 70.2020487,248.294263 C70.2020487,267.680023 54.4867848,283.395287 35.1010243,283.395287 C15.7152639,283.395287 0,267.680023 0,248.294263 C0,228.908502 15.7152639,213.193238 35.1010243,213.193238 Z M127.459466,106.806429 C107.981896,107.874068 92.8698765,124.212107 93.3217628,143.713681 L93.3217628,237.998765 C93.3217628,263.58699 104.580582,279.120548 121.077461,282.431965 C131.434034,284.530959 142.185473,281.860819 150.356699,275.160414 C158.527925,268.460009 163.252393,258.439904 163.222912,247.872809 L163.222912,142.088076 C163.240039,132.641687 159.462041,123.584285 152.737293,116.950107 C146.012546,110.315928 136.904752,106.661084 127.459466,106.806429 L127.459466,106.806429 Z" fill="#E37400"></path></g></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Google Analytics 4', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Rastreie eventos importantes em seu site com facilidade! Integre o Google Analytics agora e obtenha insights valiosos para otimizar sua performance online.', 'flexify-dashboard' ) ?></p>
                
                <?php if ( is_plugin_active( 'flexify-dashboard-analytics-addon/flexify-dashboard-analytics-addon.php' ) ) : ?>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url( admin_url('admin.php?page=flexify-dashboard') ) ?>"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></a>
                <?php elseif ( array_key_exists( 'flexify-dashboard-analytics-addon/flexify-dashboard-analytics-addon.php', get_plugins() ) ) : ?>
                    <button class="btn btn-sm btn-primary activate-plugin" data-plugin-slug="<?php echo esc_attr('flexify-dashboard-recaptcha-addon/flexify-dashboard-recaptcha-addon.php'); ?>"><?php echo esc_html__( 'Ativar módulo', 'flexify-dashboard' ) ?></button>
                <?php else : ?>
                    <button class="btn btn-sm btn-primary install-module" data-plugin-url="" data-plugin-slug="<?php echo esc_attr( 'flexify-dashboard-analytics-addon/flexify-dashboard-analytics-addon.php' ); ?>"><?php echo esc_html__( 'Instalar módulo', 'flexify-dashboard' ) ?></button>
                <?php endif; ?>
            </div>

            <?php
            /**
             * Add module settings for Analytics addon
             * 
             * @since 1.5.0
             */
            do_action('flexify_dashboard_analytics_addon'); ?>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34.66 34.56"><path d="M77.33,21.16c0-.25,0-.49,0-.74v-14l-3.87,3.88a17.3,17.3,0,0,0-27.2.48l6.35,6.42a8.4,8.4,0,0,1,2.58-2.88A7.65,7.65,0,0,1,60,12.71a1.67,1.67,0,0,1,.61.09,8.38,8.38,0,0,1,6.41,3.86l-4.5,4.5c5.7,0,12.13,0,14.78,0" transform="translate(-42.67 -3.9)" style="fill:#1c3aa9"/><path d="M59.93,3.91H45.16L49,7.8A17.32,17.32,0,0,0,49.51,35l6.43-6.36a8.39,8.39,0,0,1-2.89-2.57,7.65,7.65,0,0,1-1.58-4.86,1.92,1.92,0,0,1,.09-.61,8.4,8.4,0,0,1,3.86-6.41l4.5,4.5c0-5.7,0-12.14,0-14.78" transform="translate(-42.67 -3.9)" style="fill:#4285f4"/><path d="M42.67,21.21c0,.25,0,.5,0,.74V36l3.87-3.88a17.3,17.3,0,0,0,27.2-.48L67.41,25.2a8.52,8.52,0,0,1-2.58,2.89A7.71,7.71,0,0,1,60,29.66a1.67,1.67,0,0,1-.61-.09A8.38,8.38,0,0,1,53,25.71l4.5-4.5c-5.7,0-12.13,0-14.78,0" transform="translate(-42.67 -3.9)" style="fill:#ababab"/></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Google reCAPTCHA', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Aumente a segurança do seu WordPress ativando o Google reCAPTCHA no login do administrador. Evite acessos indesejados e proteja seu site contra ameaças.', 'flexify-dashboard' ) ?></p>

                <?php if ( is_plugin_active( 'flexify-dashboard-recaptcha-addon/flexify-dashboard-recaptcha-addon.php' ) ) : ?>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#recaptcha_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></button>
                <?php elseif ( array_key_exists( 'flexify-dashboard-recaptcha-addon/flexify-dashboard-recaptcha-addon.php', get_plugins() ) ) : ?>
                    <button class="btn btn-sm btn-primary activate-plugin" data-plugin-slug="<?php echo esc_attr('flexify-dashboard-recaptcha-addon/flexify-dashboard-recaptcha-addon.php'); ?>"><?php echo esc_html__( 'Ativar módulo', 'flexify-dashboard' ) ?></button>
                <?php else : ?>
                    <button class="btn btn-sm btn-primary install-module" data-plugin-url="https://github.com/meumouse/flexify-dashboard-recaptcha-addon/raw/main/dist/flexify-dashboard-recaptcha-addon.zip" data-plugin-slug="<?php echo esc_attr( 'flexify-dashboard-recaptcha-addon/flexify-dashboard-recaptcha-addon.php' ); ?>"><?php echo esc_html__( 'Instalar módulo', 'flexify-dashboard' ) ?></button>
                <?php endif; ?>
            </div>

            <?php
            /**
             * Add module settings for reCAPTCHA addon
             * 
             * @since 1.5.0
             */
            do_action('flexify_dashboard_recaptcha_addon'); ?>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="fill: #008aff"><path d="M20.26 7.8a4.82 4.82 0 0 0-3.93-2.44 3.91 3.91 0 0 0-2.54 1.09 10.58 10.58 0 0 0-1.52 1.71 11 11 0 0 0-1.63-1.72 4.39 4.39 0 0 0-2.88-1.08A5 5 0 0 0 3.7 8 11.49 11.49 0 0 0 2 14a7 7 0 0 0 .18 1.64A4.44 4.44 0 0 0 2.71 17a3.23 3.23 0 0 0 3 1.6c1.25 0 2.19-.56 3.3-2a26.4 26.4 0 0 0 2.21-3.6l.63-1.12c.06-.09.11-.18.16-.27l.15.25 1.79 3A14.77 14.77 0 0 0 16 17.63a3.38 3.38 0 0 0 2.55 1 3 3 0 0 0 2.54-1.23 2.2 2.2 0 0 0 .18-.28 4.1 4.1 0 0 0 .31-.63l.12-.35A6.53 6.53 0 0 0 22 15a9 9 0 0 0 0-1 11.15 11.15 0 0 0-1.74-6.2zm-10.12 3.56c-.64 1-1.57 2.51-2.37 3.61-1 1.37-1.51 1.51-2.07 1.51a1.29 1.29 0 0 1-1.15-.66 3.3 3.3 0 0 1-.39-1.7A9.74 9.74 0 0 1 5.54 9a2.8 2.8 0 0 1 2.19-1.47A3 3 0 0 1 10 8.74a14.07 14.07 0 0 1 1 1.31zm8.42 5.12c-.48 0-.85-.19-1.38-.83A34.87 34.87 0 0 1 14.82 12l-.52-.86c-.36-.61-.71-1.16-1-1.65a2.46 2.46 0 0 1 .17-.27c.94-1.39 1.77-2.17 2.8-2.17a3.12 3.12 0 0 1 2.49 1.66 10.17 10.17 0 0 1 1.37 5.34c-.04 1.31-.34 2.43-1.57 2.43z"></path></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Meta Pixel', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Comece a rastrear ações dos visitantes e refinar suas campanhas de marketing no Facebook. Ganhe insights valiosos para segmentar melhor seu público e aumentar suas conversões.', 'flexify-dashboard' ) ?></p>

                <div class="badge bg-translucent-primary rounded-pill py-2 px-3 fs-md"><?php echo esc_html__( 'Em breve', 'flexify-dashboard' ) ?></div>
            </div>

            <?php
            /**
             * Add module settings for Meta Pixel addon
             * 
             * @since 1.5.0
             */
            do_action('flexify_dashboard_meta_pixel_addon'); ?>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 945.76 891.08"><path d="M514,116.38c-234.22,0-424.08,189.87-424.08,424.07S279.74,964.53,514,964.53,938,774.67,938,540.45,748.17,116.38,514,116.38Zm171.38,426.1c-141.76.37-257.11,117.69-257.4,259.45H339.72c0-191.79,153.83-347.42,345.62-347.42Zm0-176.64c-141.76.19-266.84,69.9-346,176.13V410.6C431,328.12,551.92,277.5,685.34,277.5Z" transform="translate(-89.88 -73.45)" style="fill:#141d26"/><circle cx="779.75" cy="166.01" r="166.01" style="fill:#fff"/><path d="M906.38,257.83H911a13.79,13.79,0,0,0,13.78-13.78V161.37A13.79,13.79,0,0,0,911,147.59H791.54a13.79,13.79,0,0,0-13.78,13.78V294.58l49-36.75Zm-85.74-18.37-24.51,18.37V166H906.38v73.5Zm127.08-36.75h-4.59v55.13a18.41,18.41,0,0,1-18.29,18.37h-92v4.59a13.79,13.79,0,0,0,13.78,13.78h65.85l49,36.75V216.49A13.8,13.8,0,0,0,947.72,202.71Z" transform="translate(-89.88 -73.45)" style="fill:#141d26;stroke:#141d26;stroke-miterlimit:133.33332824707"/></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Flexify Dashboard - Chat addon', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Adicione um chat ao seu site e permita que seus clientes tirem dúvidas e recebam suporte sem sair da página. Mais engajamento, menos abandono!', 'flexify-dashboard' ) ?></p>

                <div class="badge bg-translucent-primary rounded-pill py-2 px-3 fs-md"><?php echo esc_html__( 'Em breve', 'flexify-dashboard' ) ?></div>
            </div>

            <?php
            /**
             * Add module settings for Flexify Dashboard - Chat addon
             * 
             * @since 1.5.0
             */
            do_action('flexify_dashboard_chat_addon'); ?>
        </div>
    </div>

    <div class="container-separator"></div>

    <h5 class="ps-5 m-4"><?php echo esc_html__( 'Extensões recomendadas:', 'flexify-dashboard' ) ?></h5>

    <div class="cards-group ps-5 mb-5">
        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 945.76 891.08"><path d="M514,116.38c-234.22,0-424.08,189.87-424.08,424.07S279.74,964.53,514,964.53,938,774.67,938,540.45,748.17,116.38,514,116.38Zm171.38,426.1c-141.76.37-257.11,117.69-257.4,259.45H339.72c0-191.79,153.83-347.42,345.62-347.42Zm0-176.64c-141.76.19-266.84,69.9-346,176.13V410.6C431,328.12,551.92,277.5,685.34,277.5Z" transform="translate(-89.88 -73.45)" style="fill:#141d26"/><circle cx="779.75" cy="166.01" r="166.01" style="fill:#fff"/><path d="M785.1,285.69c-9.31-37.24-14-55.85-4.19-68.37s29-12.52,67.35-12.52h50.25c38.38,0,57.57,0,67.34,12.52s5.12,31.13-4.18,68.37c-5.93,23.68-8.89,35.52-17.72,42.42s-21,6.89-45.44,6.89H848.26c-24.41,0-36.62,0-45.45-6.89S791,309.37,785.1,285.69Z" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-miterlimit:133.33332824707;stroke-width:15px"/><path d="M954.76,210.22,947.05,182c-3-10.9-4.45-16.35-7.5-20.45a27.08,27.08,0,0,0-11.91-9.09c-4.76-1.86-10.41-1.86-21.7-1.86M792,210.22l7.7-28.27c3-10.9,4.46-16.35,7.51-20.45a27.11,27.11,0,0,1,11.9-9.09c4.77-1.86,10.42-1.86,21.71-1.86" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-miterlimit:133.33332824707;stroke-width:15px"/><path d="M840.83,150.55a10.85,10.85,0,0,1,10.85-10.85h43.41a10.85,10.85,0,1,1,0,21.7H851.68A10.85,10.85,0,0,1,840.83,150.55Z" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-miterlimit:133.33332824707;stroke-width:15px"/><path d="M830,248.2v43.4" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-linecap:round;stroke-linejoin:round;stroke-width:15px"/><path d="M916.79,248.2v43.4" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-linecap:round;stroke-linejoin:round;stroke-width:15px"/><path d="M873.38,248.2v43.4" transform="translate(-89.88 -73.45)" style="fill:none;stroke:#141d26;stroke-linecap:round;stroke-linejoin:round;stroke-width:15px"/></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Flexify Checkout para WooCommerce', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Otimize a finalização de compras no seu WooCommerce com um processo intuitivo em múltiplas etapas. Aumente a conversão e melhore a experiência do seu cliente.', 'flexify-dashboard' ) ?></p>

                <?php if ( is_plugin_active('flexify-checkout-for-woocommerce/flexify-checkout-for-woocommerce.php') ) : ?>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url( admin_url('admin.php?page=flexify-checkout-for-woocommerce') ) ?>"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></a>
                <?php else : ?>
                    <button class="btn btn-sm btn-primary install-module" data-plugin-url="https://github.com/meumouse/flexify-checkout-for-woocommerce/raw/main/dist/flexify-checkout-for-woocommerce.zip" data-plugin-slug="flexify-checkout-for-woocommerce"><?php echo esc_html__( 'Instalar módulo', 'flexify-dashboard' ) ?></button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <img src="<?php echo esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-parcelas-customizadas-para-woocommerce-single.png' ) ?>">
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Parcelas Customizadas para WooCommerce', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Extensão que permite exibir o parcelamento, desconto e juros por forma de pagamento para lojas WooCommerce.', 'flexify-dashboard' ) ?></p>

                <?php if ( is_plugin_active( 'woo-custom-installments/woo-custom-installments.php' ) ) : ?>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url( admin_url('admin.php?page=woo-custom-installments') ) ?>"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></a>
                <?php elseif ( array_key_exists( 'woo-custom-installments/woo-custom-installments.php', get_plugins() ) ) : ?>
                    <button class="btn btn-sm btn-primary activate-plugin" data-plugin-slug="<?php echo esc_attr( 'woo-custom-installments/woo-custom-installments.php' ); ?>"><?php echo esc_html__( 'Ativar módulo', 'flexify-dashboard' ) ?></button>
                <?php else : ?>
                    <button class="btn btn-sm btn-primary install-module" data-plugin-url="https://github.com/meumouse/woo-custom-installments/raw/main/dist/woo-custom-installments.zip" data-plugin-slug="<?php echo esc_attr( 'woo-custom-installments/woo-custom-installments.php' ); ?>"><?php echo esc_html__( 'Instalar módulo', 'flexify-dashboard' ) ?></button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 826.56 823.37"><defs><style>.agw-1{fill:none;}.agw-2{clip-path:url(#clip-path);}.agw-3{fill:#008aff;}.agw-3,.agw-4,.agw-5{fill-rule:evenodd;}.agw-4{fill:#f12bf2;}.agw-5{fill:#021b8d;opacity:0.51;}.agw-6{fill:#1c2a39;}</style><clipPath id="clip-path" transform="translate(-160.8 -227.32)"><rect class="agw-1" x="-26.92" width="1202" height="1202"/></clipPath></defs><g class="agw-2"><path class="agw-3" d="M572.3,227.82c-227.23,0-411.43,184.21-411.43,411.44s184.2,411.43,411.43,411.43Z" transform="translate(-160.8 -227.32)"/><path class="agw-4" d="M987.36,1050.69H572.3c-227.29-1-411.43-183.62-411.43-411.43l-.07,0H572.31v0l.69,0h20.82a404,404,0,0,1,393.55,396.5Z" transform="translate(-160.8 -227.32)"/><path class="agw-5" d="M572.31,639.24l-411.44,0a408.71,408.71,0,0,0,75.3,237.33l1.08,1.51a413.1,413.1,0,0,0,335,172.59Z" transform="translate(-160.8 -227.32)"/></g><path class="agw-6" d="M837.56,227.32S850.67,367.8,985.48,375.24c0,0-122,10.69-148.8,148.8,0,0-11.6-126.33-148.91-148.91C687.77,375.13,812.55,372.36,837.56,227.32Z" transform="translate(-160.8 -227.32)"/></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Account Genius para WooCommerce', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Extensão que permite alterar o modelo de página minha conta padrão do WooCommerce por um modelo profissional e responsivo.', 'flexify-dashboard' ) ?></p>

                <?php if ( is_plugin_active('wc-account-genius/wc-account-genius.php') ) : ?>
                    <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url( admin_url('admin.php?page=wc-account-genius') ) ?>"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></a>
                <?php else : ?>
                    <button class="btn btn-sm btn-primary install-module" data-plugin-url="https://github.com/meumouse/wc-account-genius/raw/main/dist/wc-account-genius.zip" data-plugin-slug="wc-account-genius"><?php echo esc_html__( 'Instalar módulo', 'flexify-dashboard' ) ?></button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card text-center p-0 m-4">
            <div class="card-header border-bottom">
                <div class="integration-item p-4 rounded-circle">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 703 882.5"><path d="M908.66,248V666a126.5,126.5,0,0,1-207.21,97.41l-16.7-16.7L434.08,496.07l-62-62a47.19,47.19,0,0,0-72,30.86V843.36a47.52,47.52,0,0,0,69.57,35.22l19.3-19.3,56-56,81.19-81.19,10.44-10.44a47.65,47.65,0,0,1,67.63,65.05l-13,13L428.84,952.12l-9.59,9.59a128,128,0,0,1-213.59-95.18V413.17a124.52,124.52,0,0,1,199.78-82.54l22.13,22.13L674.45,599.64l46.22,46.22,17,17a47.8,47.8,0,0,0,71-31.44V270.19a48.19,48.19,0,0,0-75-40.05L720.43,243.4l-68.09,68.09L575.7,388.13a48.39,48.39,0,0,1-67.43-67.93L680,148.46A136,136,0,0,1,908.66,248Z" transform="translate(-205.66 -112.03)" style="fill:#22c55e"/></svg>
                </div>
            </div>
            
            <div class="card-body px-3 py-4 d-flex flex-column align-items-center text-center">
                <h5 class="card-title"><?php echo esc_html__( 'Joinotify', 'flexify-dashboard' ) ?></h5>
                <p class="card-text fs-sm mb-4"><?php echo esc_html__( 'Automatize o envio de mensagens via WhatsApp no WordPress com Joinotify. Desde confirmações a notificações, deixe tudo no fluxo certo sem esforço!', 'flexify-dashboard' ) ?></p>

                <div class="badge bg-translucent-primary rounded-pill py-2 px-3 fs-md"><?php echo esc_html__( 'Em breve', 'flexify-dashboard' ) ?></div>
            </div>

            <?php
            /**
             * Add module settings for Joinotify
             * 
             * @since 1.5.0
             */
            do_action('flexify_dashboard_joinotify'); ?>
        </div>
    </div>

    <?php
    /**
     * Add custom card extension on end section
     * 
     * @since 1.5.0
     */
    do_action('flexify_dashboard_end_extensions'); ?>
</div>