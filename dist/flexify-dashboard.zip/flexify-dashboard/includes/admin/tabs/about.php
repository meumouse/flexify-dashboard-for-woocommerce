<?php

use MeuMouse\Flexify_Dashboard\License;

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="about" class="nav-content">
  <table class="form-table">
	<tr>
		<td class="d-grid">
			<h3 class="mb-4"><?php esc_html_e( 'Informações sobre a licença:', 'flexify-dashboard' ); ?></h3>
			<span class="mb-2"><?php echo esc_html__( 'Status da licença:', 'flexify-dashboard' ) ?>
				<?php if ( License::is_valid() ) : ?>
					<span class="badge bg-translucent-success rounded-pill"><?php _e(  'Válida', 'flexify-dashboard' );?></span>
				<?php elseif ( empty( get_option('flexify_dashboard_license_key') ) ) : ?>
					<span class="fs-sm"><?php _e(  'Nenhuma licença informada', 'flexify-dashboard' );?></span>
				<?php else : ?>
					<span class="badge bg-translucent-danger rounded-pill"><?php _e(  'Inválida', 'flexify-dashboard' );?></span>
				<?php endif; ?>
			</span>

			<span class="mb-2"><?php echo esc_html__( 'Recursos:', 'flexify-dashboard' ) ?>
				<?php if ( License::is_valid() ) : ?>
					<span class="badge bg-translucent-primary rounded-pill"><?php _e(  'Pro', 'flexify-dashboard' );?></span>
				<?php endif; ?>
			</span>

			<?php if ( License::is_valid() ) :
				$license_key = get_option('flexify_dashboard_license_key');

				if ( strpos( $license_key, 'CM-' ) === 0 ) : ?>
					<span class="mb-2"><?php echo sprintf( esc_html__( 'Assinatura: Clube M - %s', 'flexify-dashboard' ), License::license_title() ) ?></span>
				<?php else : ?>
					<span class="mb-2"><?php echo sprintf( esc_html__( 'Tipo da licença: %s', 'flexify-dashboard' ), License::license_title() ) ?></span>
				<?php endif; ?>

				<span class="mb-2"><?php echo sprintf( esc_html__( 'Licença expira em: %s', 'flexify-dashboard' ), License::license_expire() ) ?></span>
				
				<span class="mb-2"><?php echo esc_html__( 'Sua chave de licença:', 'flexify-dashboard' ) ?>
					<?php if ( ! empty( $license_key ) ) :
						echo esc_attr( substr( $license_key, 0, 9 ) . "XXXXXXXX-XXXXXXXX" . substr( $license_key, -9 ) );
					else :
						echo esc_html__( 'Não disponível', 'flexify-dashboard' );
					endif; ?>
				</span>
			<?php endif; ?>
		</td>
	</tr>
	<?php if ( License::is_valid() ) : ?>
		<tr>
			<td>
				<button id="flexify_dashboard_deactive_license" name="flexify_dashboard_deactive_license" class="btn btn-sm btn-primary" type="submit"><?php echo esc_html__( 'Desativar licença', 'flexify-dashboard' ); ?></button>
			</td>
		</tr>
	<?php else :
		if ( get_option('flexify_dashboard_alternative_license_activation') === 'yes' ) : ?>
			<div class="flexify-dashboard-wrapper">
				<form method="post" action="" class="flexify-dashboard-form-license" name="flexify-dashboard-form-license">
					<table class="flexify-dashboard-form-license">
						<tr>
							<td>
								<span class="h4 d-block"><?php echo esc_html__( 'Notamos que teve problemas de conexão ao tentar ativar sua licença', 'flexify-dashboard' ); ?></span>
								<span class="d-block text-muted"><?php echo esc_html__( 'Você pode fazer upload do arquivo .key da licença para fazer sua ativação manual.', 'flexify-dashboard' ); ?></span>
								<a class="fancy-link mt-2 mb-3" href="https://meumouse.com/minha-conta/licenses/?domain=<?php echo urlencode( License::get_domain() ); ?>&license_key=<?php echo urlencode( get_option('flexify_dashboard_temp_license_key') ); ?>&app_version=<?php echo urlencode( FLEXIFY_DASHBOARD_VERSION ); ?>&product_id=6&settings_page=<?php echo urlencode( License::get_domain() . '/wp-admin/admin.php?page=flexify-dashboard-for-woocommerce' ); ?>" target="_blank"><?php echo esc_html__( 'Clique aqui para gerar seu arquivo de licença', 'flexify-dashboard' ) ?></a>
	
								<div class="drop-file-license-key">
									<div class="dropzone-license mt-4" id="license_key_zone">
										<div class="drag-text">
											<svg class="drag-and-drop-file-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.937 8.68c-.011-.032-.02-.063-.033-.094a.997.997 0 0 0-.196-.293l-6-6a.997.997 0 0 0-.293-.196c-.03-.014-.062-.022-.094-.033a.991.991 0 0 0-.259-.051C13.04 2.011 13.021 2 13 2H6c-1.103 0-2 .897-2 2v16c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2V9c0-.021-.011-.04-.013-.062a.99.99 0 0 0-.05-.258zM16.586 8H14V5.414L16.586 8zM6 20V4h6v5a1 1 0 0 0 1 1h5l.002 10H6z"></path></svg>
											<?php echo esc_html( 'Arraste e solte o arquivo .key aqui', 'flexify-dashboard' ); ?>
										</div>
										<div class="file-list"></div>
										<form enctype="multipart/form-data" action="upload.php" class="upload-license-key" method="POST">
											<div class="drag-and-drop-file">
												<div class="custom-file">
													<input type="file" class="custom-file-input" id="upload_license_key" name="upload_license_key" hidden>
													<label class="custom-file-label mb-4" for="upload_license_key"><?php echo esc_html( 'Ou clique para procurar seu arquivo', 'flexify-dashboard' ); ?></label>
												</div>
											</div>
										</form>
									</div>
								</div>
							</td>
						</tr>
					</table>
				</form>
			</div>
		<?php else : ?>
			<div>
				<form method="post" class="flexify-dashboard-form-license" name="flexify-dashboard-form-license">
					<table class="insert-license">
						<tr>
							<td class="d-grid">
								<a class="btn btn-primary my-4 d-flex align-items-center py-3 px-4" href="https://meumouse.com/plugins/flexify-dashboard-para-woocommerce/?utm_source=wordpress&utm_medium=activate_tab&utm_campaign=flexify_dashboard" target="_blank">
									<i class="bx bx-key fs-lg me-2"></i>
									<span><?php _e(  'Comprar licença', 'flexify-dashboard' );?></span>
								</a>
							</td>
						</tr>
						<tr>
							<td class="w-75">
								<span class="d-block bg-translucent-success rounded-3 py-2 px-3 mb-3"><?php echo esc_html__( 'Informe sua licença abaixo para desbloquear todos os recursos.', 'flexify-dashboard' ) ?></span>
								<span class="form-label d-block mt-2"><?php echo esc_html__( 'Código da licença', 'flexify-dashboard' ) ?></span>
								<div class="input-group" style="width: 550px;">
									<input class="form-control" type="text" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" id="flexify_dashboard_license_key" name="flexify_dashboard_license_key" size="50" value="<?php echo get_option( 'flexify_dashboard_license_key' ) ?>" />
									<button id="flexify_dashboard_active_license" name="flexify_dashboard_active_license" class="btn btn-primary button-loading" type="submit">
										<span class="span-inside-button-loader"><?php esc_attr_e( 'Ativar licença', 'flexify-dashboard' ); ?></span>
									</button>
								</div>
							</td>
						</tr>
					</table>
				</form>
			</div>
		<?php endif;
	endif; ?>
	
	<tr class="container-separator"></tr>

	<tr class="w-75 mt-5">
		<td>
			<h3 class="h2 mt-0"><?php esc_html_e( 'Status do sistema:', 'flexify-dashboard' ); ?></h3>
			<h4 class="mt-4"><?php esc_html_e( 'WordPress', 'flexify-dashboard' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do WordPress:', 'flexify-dashboard' ); ?></span>
				<span class="ms-2"><?php echo esc_html( get_bloginfo( 'version' ) ); ?></span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'WordPress Multisite:', 'flexify-dashboard' ); ?></span>
				<span class="ms-2"><?php echo is_multisite() ? esc_html__( 'Sim', 'flexify-dashboard' ) : esc_html__( 'Não', 'flexify-dashboard' ); ?></span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Modo de depuração do WordPress:', 'flexify-dashboard' ); ?></span>
				<span class="ms-2"><?php echo defined( 'WP_DEBUG' ) && WP_DEBUG ? esc_html__( 'Ativo', 'flexify-dashboard' ) : esc_html__( 'Desativado', 'flexify-dashboard' ); ?></span>
			</div>

			<h4 class="mt-4"><?php esc_html_e( 'WooCommerce', 'flexify-dashboard' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do WooCommerce:', 'flexify-dashboard' ); ?></span>

				<span class="ms-2">
					<?php if( version_compare( WC_VERSION, '6.0', '<' ) ) : ?>
						<span class="badge bg-translucent-danger">
							<span>
								<?php echo esc_html( WC_VERSION ); ?>
							</span>
							<span>
								<?php esc_html_e( 'A versão mínima exigida do WooCommerce é 6.0', 'flexify-dashboard' ); ?>
							</span>
						</span>
					<?php else : ?>
						<span class="badge bg-translucent-success">
							<?php echo esc_html( WC_VERSION ); ?>
						</span>
					<?php endif; ?>
				</span>
			</div>

			<h4 class="mt-4"><?php esc_html_e( 'Servidor', 'flexify-dashboard' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do PHP:', 'flexify-dashboard' ); ?></span>

				<span class="ms-2">
					<?php if ( version_compare( PHP_VERSION, '7.2', '<' ) ) : ?>
						<span class="badge bg-translucent-danger">
							<span>
								<?php echo esc_html( PHP_VERSION ); ?>
							</span>
							<span>
								<?php esc_html_e( 'A versão mínima exigida do PHP é 7.2', 'flexify-dashboard' ); ?>
							</span>
						</span>
					<?php else : ?>
						<span class="badge bg-translucent-success">
							<?php echo esc_html( PHP_VERSION ); ?>
						</span>
					<?php endif; ?>
				</span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'DOMDocument:', 'flexify-dashboard' ); ?></span>
				<span class="ms-2">
					<span>
						<?php if ( ! class_exists( 'DOMDocument' ) ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Não', 'flexify-dashboard' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Sim', 'flexify-dashboard' ); ?>
							</span>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Extensão cURL:', 'flexify-dashboard' ); ?></span>

				<span class="ms-2">
					<span>
						<?php if ( !extension_loaded('curl') ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Não', 'flexify-dashboard' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Sim', 'flexify-dashboard' ); ?>
							</span>
							<span>
								<?php echo sprintf( __( 'Versão %s', 'flexify-dashboard' ), curl_version()['version'] ) ?>
							</span>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Extensão OpenSSL:', 'flexify-dashboard' ); ?></span>
				
				<span class="ms-2">
					<span>
						<?php if ( ! extension_loaded('openssl') ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Não', 'flexify-dashboard' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Sim', 'flexify-dashboard' ); ?>
							</span>
							<span>
								<?php echo OPENSSL_VERSION_TEXT ?>
							</span>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<?php if ( function_exists( 'ini_get' ) ) : ?>
				<div class="d-flex mb-2">
					<span>
						<?php $post_max_size = ini_get( 'post_max_size' ); ?>

						<?php esc_html_e( 'Tamanho máximo da postagem do PHP:', 'flexify-dashboard' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $post_max_size ) < 64000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $post_max_size ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 64M', 'flexify-dashboard' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $post_max_size ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $max_execution_time = ini_get('max_execution_time'); ?>
						<?php esc_html_e( 'Limite de tempo do PHP:', 'flexify-dashboard' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( $max_execution_time < 180 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $max_execution_time ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 180', 'flexify-dashboard' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $max_execution_time ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $max_input_vars = ini_get('max_input_vars'); ?>
						<?php esc_html_e( 'Variáveis máximas de entrada do PHP:', 'flexify-dashboard' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( $max_input_vars < 10000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $max_input_vars ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 10000', 'flexify-dashboard' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $max_input_vars ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $memory_limit = ini_get( 'memory_limit' ); ?>
						<?php esc_html_e( 'Limite de memória do PHP:', 'flexify-dashboard' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $memory_limit ) < 128000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $memory_limit ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 128M', 'flexify-dashboard' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $memory_limit ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $upload_max_filesize = ini_get( 'upload_max_filesize' ); ?>
						<?php esc_html_e( 'Tamanho máximo de envio do PHP:', 'flexify-dashboard' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $upload_max_filesize ) < 64000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $upload_max_filesize ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 64M', 'flexify-dashboard' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $upload_max_filesize ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span><?php esc_html_e( 'Função PHP "file_get_content":', 'flexify-dashboard' ); ?></span>
					<span class="ms-2">
						<?php if ( ! ini_get( 'allow_url_fopen' ) ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Desligado', 'flexify-dashboard' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Ligado', 'flexify-dashboard' ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
			<?php endif; ?>
		</td>
		<tr>
			<td>
				<a class="btn btn-sm btn-outline-danger" target="_blank" href="https://meumouse.com/reportar-problemas/"><?php esc_html_e( 'Reportar problemas', 'flexify-dashboard' ); ?></a>
				<button class="btn btn-sm btn-outline-primary ms-2 button-loading" name="flexify_dashboard_clear_activation_cache"><?php esc_html_e( 'Limpar cache de ativação', 'flexify-dashboard' ); ?></button>
			</td>
		</tr>
	</tr>
  </table>
</div>