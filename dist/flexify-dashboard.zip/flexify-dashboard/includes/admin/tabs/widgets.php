<?php

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="widgets" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de usuários totais', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de usuários totais registrados.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_total_users_widget" name="enable_total_users_widget" value="yes" <?php checked( self::get_setting('enable_total_users_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de produtos cadastrados', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de produtos cadastrados do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_products_registered_widget" name="enable_products_registered_widget" value="yes" <?php checked( self::get_setting('enable_products_registered_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de faturamento anual', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de faturamento anual bruto e líquido do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_anual_billing_widget" name="enable_anual_billing_widget" value="yes" <?php checked( self::get_setting('enable_anual_billing_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de ticket médio', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de ticket médio de pedidos do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_average_ticket_widget" name="enable_average_ticket_widget" value="yes" <?php checked( self::get_setting('enable_average_ticket_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de quantidade de pedidos', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de quantidade de pedidos do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_orders_number_widget" name="enable_orders_number_widget" value="yes" <?php checked( self::get_setting('enable_orders_number_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr class="enable-ga-integration d-none <?php echo ( self::get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
         <th>
            <?php echo esc_html__( 'Ativar widget de tecnologia dos visitantes', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de tecnologia dos visitantes do site.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_technology_ga_widget" name="enable_technology_ga_widget" value="yes" <?php checked( self::get_setting('enable_technology_ga_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr class="enable-ga-integration d-none <?php echo ( self::get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
         <th>
            <?php echo esc_html__( 'Ativar widget de tipo de visitante', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de tipo de visitante do site.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_visitor_type_widget" name="enable_visitor_type_widget" value="yes" <?php checked( self::get_setting('enable_visitor_type_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de últimos pedidos recebidos', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de últimos pedidos recebidos do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_last_orders_widget" name="enable_last_orders_widget" value="yes" <?php checked( self::get_setting('enable_last_orders_widget') === 'yes' ); ?> />
            
               <button class="btn btn-sm btn-outline-primary ms-3 require-last-orders-widget" data-bs-toggle="modal" data-bs-target="#last_orders_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></button>

               <div class="modal fade" id="last_orders_modal" tabindex="-1" aria-labelledby="last_orders_label" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h1 class="modal-title fs-5" id="last_orders_label"><?php echo esc_html__( 'Configurar widget de últimos pedidos', 'flexify-dashboard' ) ?></h1>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_html__( 'Fechar', 'flexify-dashboard' ) ?>"></button>
                        </div>

                        <div class="modal-body">
                           <table class="popup-table">
                              <tbody>
                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'Quantidade de pedidos para exibir', 'flexify-dashboard' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__( 'Informe a quantidade de últimos pedidos a ser consultado. O padrão são os últimos 5 pedidos.', 'flexify-dashboard' ) ?></span>
                                    </th>
                                    <td>
                                       <input type="number" class="form-control input-control-wd-5" id="get_last_order_number_query" name="get_last_order_number_query" value="<?php echo self::get_setting('get_last_order_number_query') ?>"/>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </td>
      </tr>

      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de produtos mais vendidos', 'flexify-dashboard' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget dos produtos mais vendidos do WooCommerce.', 'flexify-dashboard' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_widget_best_selling_products" name="enable_widget_best_selling_products" value="yes" <?php checked( self::get_setting('enable_widget_best_selling_products') === 'yes' ); ?> />
            
               <button class="btn btn-sm btn-outline-primary ms-3 require-best-selling-widget" data-bs-toggle="modal" data-bs-target="#best_selling_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard' ) ?></button>

               <div class="modal fade" id="best_selling_modal" tabindex="-1" aria-labelledby="best_selling_label" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h1 class="modal-title fs-5" id="best_selling_label"><?php echo esc_html__( 'Configurar widget de produtos mais vendidos', 'flexify-dashboard' ) ?></h1>
                           <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_html__( 'Fechar', 'flexify-dashboard' ) ?>"></button>
                        </div>

                        <div class="modal-body">
                           <table class="popup-table">
                              <tbody>
                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'Quantidade de produtos a consultar', 'flexify-dashboard' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__( 'Informe a quantidade de últimos pedidos a ser consultado. O padrão são os 5 produtos mais vendidos.', 'flexify-dashboard' ) ?></span>
                                    </th>
                                    <td>
                                       <input type="number" class="form-control input-control-wd-5" id="get_best_selling_products_query" name="get_best_selling_products_query" value="<?php echo self::get_setting('get_best_selling_products_query') ?>"/>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </td>
      </tr>
   </table>
</div>