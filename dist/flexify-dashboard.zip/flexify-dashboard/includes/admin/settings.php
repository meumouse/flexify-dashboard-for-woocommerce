<?php

use MeuMouse\Flexify_Dashboard\License;

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div class="flexify-dashboard-admin-tile-container">
    <svg id="flexify_dashboard_logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 901.23 848.15"><defs><style>.cls-1{fill:#141d26;}.cls-2{fill:#fff;}.cls-3{fill:none;stroke:#141d26;stroke-linecap:round;stroke-linejoin:round;stroke-width:15px;}</style></defs><path class="cls-1" d="M514,116.38c-234.22,0-424.08,189.87-424.08,424.07S279.74,964.53,514,964.53,938,774.67,938,540.45,748.17,116.38,514,116.38Zm171.38,426.1c-141.76.37-257.11,117.69-257.4,259.45H339.72c0-191.79,153.83-347.42,345.62-347.42Zm0-176.64c-141.76.19-266.84,69.9-346,176.13V410.6C431,328.12,551.92,277.5,685.34,277.5Z" transform="translate(-89.88 -116.38)"/><circle class="cls-2" cx="780.25" cy="121.6" r="120.99"/><g id="SVGRepo_iconCarrier" data-name="SVGRepo iconCarrier"><path class="cls-3" d="M847.71,222H823.08a13.62,13.62,0,0,0-13.73,13.51v51.14a13.61,13.61,0,0,0,13.73,13.5h24.63a13.62,13.62,0,0,0,13.74-13.51V235.54A13.62,13.62,0,0,0,847.71,222Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M847.71,169.93H823.08a13.36,13.36,0,0,0-13.73,13v8.81a13.36,13.36,0,0,0,13.73,13h24.63a13.37,13.37,0,0,0,13.74-13v-8.81A13.38,13.38,0,0,0,847.71,169.93Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M892.55,248.08h24.62a13.62,13.62,0,0,0,13.74-13.51V183.44a13.62,13.62,0,0,0-13.73-13.51H892.55a13.62,13.62,0,0,0-13.74,13.51v51.13a13.62,13.62,0,0,0,13.74,13.51Z" transform="translate(-89.88 -116.38)"/><path class="cls-3" d="M892.55,300.18h24.62a13.37,13.37,0,0,0,13.74-13v-8.81a13.36,13.36,0,0,0-13.73-13H892.55a13.37,13.37,0,0,0-13.74,13v8.8A13.37,13.37,0,0,0,892.55,300.18Z" transform="translate(-89.88 -116.38)"/></g></svg>
    <h1 class="flexify-dashboard-admin-section-tile"><?php echo esc_html__( 'Flexify Dashboard', 'flexify-dashboard' ); ?></h1>
</div>

<div class="flexify-dashboard-admin-title-description">
    <p><?php echo esc_html__( 'Extensão que adiciona uma nova interface do usuário moderna e de simples uso para o WordPress e compatível com recursos de loja virtual do WooCommerce. Se precisar de ajuda para configurar, acesse nossa', 'flexify-dashboard' ) ?>
        <a class="fancy-link" href="<?php echo FLEXIFY_DASHBOARD_DOCS_LINK ?>" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'flexify-dashboard' ) ?></a>
    </p>
</div>

<?php
/**
 * Display admin notices
 * 
 * @since 1.5.0
 */
do_action('flexify_dashboard_display_admin_notices');

settings_errors(); ?>

<div class="flexify-dashboard-wrapper">
    <div class="nav-tab-wrapper flexify-dashboard-tab-wrapper">
        <a href="#general" class="nav-tab ">
            <i class="bx bx-slider-alt fs-xg me-2"></i>
            <?php echo esc_html__( 'Geral', 'flexify-dashboard' ) ?>
        </a>

        <a href="#extensions" class="nav-tab ">
            <i class="bx bx-plug fs-xg me-2"></i>
            <?php echo esc_html__( 'Extensões', 'flexify-dashboard' ) ?>
        </a>

        <a href="#widgets" class="nav-tab ">
            <i class="bx bx-extension fs-xg me-2"></i>
            <?php echo esc_html__( 'Widgets', 'flexify-dashboard' ) ?>
        </a>

        <a href="#styles" class="nav-tab ">
            <i class="bx bx-palette fs-xg me-2"></i>
            <?php echo esc_html__( 'Estilos', 'flexify-dashboard' ) ?>
        </a>

        <a href="#about" class="nav-tab ">
            <i class="bx bx-info-circle fs-xg me-2"></i>
            <?php echo esc_html__( 'Sobre', 'flexify-dashboard' ) ?>
        </a>

        <?php
        /**
         * After nav tabs hook
         * 
         * @since 1.5.0
         * @return void
         */
        do_action('flexify_dashboard_after_nav_tabs'); ?>
    </div>

    <form method="post" class="flexify-dashboard-form" name="flexify-dashboard">
        <?php
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/options.php';
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/extensions.php';
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/widgets.php';
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/design.php';
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/about.php';
        
        /**
         * Add custom tab file on form
         * 
         * @since 1.5.0
         * @return void
         */
        do_action('flexify_dashboard_include_tab_file'); ?>
    </form>
</div>