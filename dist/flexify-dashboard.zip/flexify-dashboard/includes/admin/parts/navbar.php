<?php

/**
 * Navbar template for Flexify Dashboard
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */

use MeuMouse\Flexify_Dashboard\Init;

// Exit if accessed directly.
defined('ABSPATH') || exit; ?>

<div id="flexify-dashboard-navbar" class="shadow-sm d-flex align-items-center px-4 py-3 <?php echo ( Init::get_setting('enable_admin_search_posts') === 'yes' ) ? 'justify-content-between' : 'justify-content-end'; ?>">
    <div class="d-lg-none">
        <button id="display-sidebar" class="btn btn-icon fs-3 lh-1">
            <i class="bx bx-menu"></i>
        </button>
    </div>

    <?php if ( Init::get_setting('enable_admin_search_posts') === 'yes' ) : ?>
        <div class="d-flex align-items-center w-100">
            <div class="search-container d-flex align-items-center justify-content-between w-50">
                <button id="open_search_box" class="btn d-flex align-items-center">
                    <i class="bx bx-search me-2 fs-4 text-body-secondary"></i>
                </button>

                <input class="form-control search-posts" name="flexify_dashboard_search" data-bs-toggle="modal" data-bs-target="#flexify_dashboard_search_posts" autocomplete="off" placeholder="<?php echo esc_attr( 'Digite para pesquisar...', 'flexify-dashboard' ); ?>"/>
            </div>
        </div>
    <?php endif; ?>

    <div class="d-flex align-items-center">
        <?php if ( Init::get_setting('enable_dark_mode') === 'yes' ) : ?>
            <div class="form-check form-switch mode-switch me-3">
                <?php $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true ); ?>
                <input type="checkbox" class="toggle-switch" id="theme-mode" name="flexify_dashboard_theme_mode" <?php checked( $theme_mode_state === 'yes' ); ?>/>
            </div>
        <?php endif;

        $screen = get_current_screen();

        if ( $screen->render_screen_options() !== '' ) : ?>
            <div id="flexify-dashboard-screen-widgets" class="me-3">
                <button class="screen-options">
                    <i class="bx bx-customize"></i>
                </button>

                <div class="screen-options-container">
                    <?php global $pagenow;

                    if ( $pagenow === 'index.php' || in_array( $screen->id, array('product') ) ) : ?>
                        <div class="enable-reorder-widgets p-3">
                            <h6><?php echo esc_html('Reposicionamento de elementos da tela', 'flexify-dashboard'); ?></h6>
                            
                            <p class="text-muted"><?php echo esc_html__('Ative esta função para reposicionar os elementos da tela conforme sua necessidade.', 'flexify-dashboard'); ?></p>
                        
                            <div class="form-check form-switch">
                                <input type="checkbox" class="toggle-switch" id="reorder-widgets"/>
                            </div>
                        </div>
                    <?php endif;

                    // Checks if the screen supports widgets
                    if ( method_exists( $screen, 'add_option' ) ) :
                        // Adds the option that allows widgets to be displayed
                        $screen->add_option('layout_columns', array('layout_columns' => 1));

                        // display available widgets
                        $screen->render_screen_options();

                    // If the screen does not support widgets, displays a message
                    else : ?>
                        <span class="d-flex align-items-center p-3 fs-6 text-muted">
                            <i class="bx bx-info-circle me-2 fs-lg"></i>
                            <?php echo esc_html('Nenhum widget para exibir nesta tela.', 'flexify-dashboard'); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="dropdown user-logged">
            <?php
            $user_id = get_current_user_id();
            $user_data = get_userdata( $user_id );

            // check if user data exists
            if ( $user_data ) :
                $first_name = $user_data->first_name;
                $last_name = $user_data->last_name;
                $user_roles = $user_data->roles;

                $role_labels = apply_filters( 'flexify_dashboard_role_labels', array(
                    'subscriber' => __( 'Assinante', 'flexify-dashboard' ),
                    'editor' => __( 'Editor', 'flexify-dashboard' ),
                    'author' => __( 'Autor', 'flexify-dashboard' ),
                    'contributor' => __( 'Colaborador', 'flexify-dashboard' ),
                    'administrator' => __( 'Administrador', 'flexify-dashboard' ),
                    'customer' => __( 'Cliente', 'flexify-dashboard' ),
                    'shop_manager' => __( 'Gerente de loja', 'flexify-dashboard' ),
                ));

                $role_label = isset( $role_labels[$user_roles[0]] ) ? $role_labels[$user_roles[0]] : $user_roles[0];
            endif; ?>
                
            <button class="dropdown-toggle bg-transparent border-0 d-flex align-items-center" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="d-flex flex-column align-items-end me-3">
                    <span class="d-flex fs-6 user-name">
                        <span class="me-2"><?php echo esc_html( $first_name ); ?></span>
                        <span><?php echo esc_html( $last_name ); ?></span>
                    </span>
                    <span class="fs-md text-body-secondary user-role"><?php echo esc_html( $role_label ); ?></span>
                </div>
                <img class="navbar-avatar" src="<?php echo esc_url( get_avatar_url( $user_id ) ); ?>"/>
            </button>
            
            <ul class="dropdown-menu user-profile">
                <li>
                    <a class="dropdown-item px-3 py-2 fs-lg" href="<?php echo esc_url( get_edit_profile_url() ) ?>">
                        <i class="bx bx-user"></i>
                        <?php echo esc_html( 'Meu perfil', 'flexify-dashboard' ); ?>
                    </a>
                </li>

                <li>
                    <hr class="dropdown-divider">
                </li>

                <li>
                    <a class="dropdown-item px-3 py-2 fs-lg" href="<?php echo esc_url( wp_logout_url() ) ?>">
                        <i class="bx bx-log-out"></i>
                        <?php echo esc_html( 'Sair', 'flexify-dashboard' ); ?>
                    </a>
                </li>
            </ul>
        </div>

        <div class="ms-3">
            <button class="btn btn-icon btn-lg fs-4 navbar-collapse text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-title="<?php echo esc_attr( 'Ocultar o menu superior', 'flexify-dashboard' ) ?>">
                <i class="bx bx-menu"></i>
            </button>
        </div>
    </div>
</div>