<?php

namespace MeuMouse\Flexify_Dashboard;

use MeuMouse\Flexify_Dashboard\Init;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Admin plugin options class
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Admin_Options extends Init {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function __construct() {
        parent::__construct();
        
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
    }


    /**
     * Function for create submenu in settings
     * 
     * @since 1.0.0
     * @return array
     */
    public function add_admin_menu() {
        // add submenu on WooCommerce if Flexify theme is not active
        if ( ! class_exists('Flexify') ) {
            add_submenu_page(
                'woocommerce', // parent page slug
                esc_html__( 'Flexify Dashboard', 'flexify-dashboard'), // page title
                esc_html__( 'Flexify Dashboard', 'flexify-dashboard'), // submenu title
                'manage_woocommerce', // user capabilities
                'flexify-dashboard', // page slug
                array( $this, 'load_settings_page' ) // public function for print content page
            );
        }
    }


    /**
     * Plugin general setting page and save options
     * 
     * @since 1.0.0
     * @return void
     */
    public function load_settings_page() {
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/settings.php';
    }
}

new Admin_Options();