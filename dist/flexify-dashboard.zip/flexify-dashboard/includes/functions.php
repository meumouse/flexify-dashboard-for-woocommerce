<?php

use MeuMouse\Flexify_Dashboard\Init;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Get monthly revenue data from WooCommece
 * 
 * @since 1.0.0
 * @return array
 */
function get_monthly_revenue_data() {
    // Try to get the cached data
    $cached_data = get_transient('monthly_revenue_data');

    // If data is not cached, query the database and cache it
    if ( $cached_data === false ) {
        // Gets all orders with complete and processing status
        $args = array(
            'post_type' => 'shop_order',
            'post_status' => array('wc-completed', 'wc-processing'),
            'posts_per_page' => -1,
        );

        $orders = get_posts( $args );

        // Stores monthly billing, number of completed and processing orders in an array
        $monthly_data = array();

        foreach ( $orders as $order ) {
            $order_id = $order->ID;
            $order_date = strtotime( $order->post_date );
            $order_month = date('m/Y', $order_date);
        
            // Fetch the order object
            $order_object = wc_get_order( $order_id );
        
            // Check if the order object is valid
            if ( $order_object ) {
                $order_total = $order_object->get_total();
                $order_discounts = $order_object->get_total_discount();
        
                // Initializes the month key to zero if it does not already exist
                if ( ! isset( $monthly_data[$order_month] ) ) {
                    $monthly_data[$order_month] = array(
                        'revenue_gross' => 0,
                        'revenue_net' => 0,
                        'order_count_completed' => 0,
                        'order_count_processing' => 0,
                    );
                }
        
                // Adds the total to the array corresponding to the month
                $monthly_data[$order_month]['revenue_gross'] += ($order_total + $order_discounts);
                $monthly_data[$order_month]['revenue_net'] += $order_total;
        
                // Counts the order as completed or in process
                if ( $order->post_status === 'wc-completed' ) {
                    $monthly_data[$order_month]['order_count_completed'] += 1;
                } elseif ($order->post_status === 'wc-processing') {
                    $monthly_data[$order_month]['order_count_processing'] += 1;
                }
            }
        }

        // Fill the array with zeros for months with no data
        $last_12_months = array_map( function($i) {
            return date('m/Y', strtotime("-$i months"));
        }, range( 0, 11 ) );

        $monthly_data = array_merge( array_fill_keys( $last_12_months, array('revenue_gross' => 0, 'revenue_net' => 0, 'order_count_completed' => 0, 'order_count_processing' => 0 ) ), $monthly_data );

        // Sort the array according to the keys
        uksort( $monthly_data, function( $a, $b ) {
            $dateA = DateTime::createFromFormat( 'm/Y', $a );
            $dateB = DateTime::createFromFormat( 'm/Y', $b );

            return $dateA <=> $dateB;
        });

        // Calculate the average ticket
        foreach ( $monthly_data as &$data ) {
            if ( $data['order_count_completed'] > 0 ) {
                $data['average_ticket'] = $data['revenue_gross'] / $data['order_count_completed'];
            } else {
                $data['average_ticket'] = 0;
            }
        }

        // Caches data for 1 day
        set_transient( 'monthly_revenue_data', $monthly_data, DAY_IN_SECONDS );
    } else {
        // If data is cached, use it directly
        $monthly_data = $cached_data;
    }

    return $monthly_data;
}


/**
 * Get latest orders details
 * 
 * @since 1.3.0
 * @version 1.5.0
 * @return array Orders details
 */
function get_latest_orders_details() {
    $orders = wc_get_orders( array(
        'limit' => Init::get_setting('get_last_order_number_query'),
        'orderby' => 'date',
        'order' => 'DESC',
    ) );

    $orders_details = array();

    foreach ( $orders as $order ) {
        $order_details = array();

        // Check if the order object is a WC_Order instance
        if ( $order instanceof WC_Order ) {
            // Get customer details
            $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

            // Get metadata from order object
            $meta_data = $order->get_meta_data();

            foreach ( $meta_data as $meta ) {
                // Get source type
                if ( $meta->key === '_wc_order_attribution_source_type' ) {
                    $order_source_type = $meta->value;
                }

                // Get UTM source
                if ( $meta->key === '_wc_order_attribution_utm_source' ) {
                    $order_utm_source = $meta->value;
                }

                // Get browser
                if ( $meta->key === '_wc_order_attribution_user_agent' ) {
                    $order_user_agent = $meta->value;
                }

                // Get start time from order
                if ( $meta->key === '_wc_order_attribution_session_start_time' ) {
                    $order_session_start = $meta->value;
                }

                // Get orders received from user
                if ( $meta->key === '_wc_order_attribution_session_count' ) {
                    $order_session_count = $meta->value;
                }

                // Get device type
                if ( $meta->key === '_wc_order_attribution_device_type' ) {
                    $order_session_device_type = $meta->value;
                }

                // Get entry page before order
                if ( $meta->key === '_wc_order_attribution_session_entry' ) {
                    $order_session_entry = $meta->value;
                }

                // Get number of pages visited before order
                if ( $meta->key === '_wc_order_attribution_session_pages' ) {
                    $order_session_pages = $meta->value;
                }

                // Get order referrer
                if ( $meta->key === '_wc_order_attribution_referrer' ) {
                    $order_referrer = $meta->value;
                }
            }

            $order_details['order_id'] = $order->get_id();
            $order_details['order_total'] = $order->get_total();
            $order_details['order_edit_url'] = $order->get_edit_order_url();
            $order_details['customer_name'] = $customer_name;
            $order_details['order_origin'] = isset( $order_source_type ) ? $order_source_type : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_utm_source'] = isset( $order_utm_source ) ? $order_utm_source : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_browser'] = isset( $order_user_agent ) ? $order_user_agent : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_session_start'] = isset( $order_session_start ) ? $order_session_start : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_session_count'] = isset( $order_session_count ) ? $order_session_count : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_session_device_type'] = isset( $order_session_device_type ) ? $order_session_device_type : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_session_entry'] = isset( $order_session_entry ) ? $order_session_entry : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_session_pages'] = isset( $order_session_pages ) ? $order_session_pages : esc_html__( 'N/A', 'flexify-dashboard' );
            $order_details['order_referrer'] = isset( $order_referrer ) ? $order_referrer : esc_html__( 'N/A', 'flexify-dashboard' );
        } else {
            // Skip the object if it's not a WC_Order
            continue;
        }

        $orders_details[] = $order_details;
    }

    return $orders_details;
}


/**
 * Origin filter for order details
 * 
 * @since 1.5.0
 * @return array
 */
function flexify_dashboard_origin_filter() {
    $origin_filter = array(
        'typein' => array(
            'icon' => 'bg-faded-primary text-primary rounded-circle p-1 fs-3 bx bx-subdirectory-right',
            'label' => esc_html__( 'Direto', 'flexify-dashboard' ),
        ),
        'organic' => array(
            'icon' => 'bg-faded-success text-success rounded-circle p-1 fs-3 bx bx-search',
            'label' => esc_html__( 'Orgânico', 'flexify-dashboard' ),
        ),
        'wordpress' => array(
            'icon' => 'bg-faded-dark text-dark rounded-circle p-1 fs-3 bx bxl-wordpress',
            'label' => esc_html__( 'WordPress', 'flexify-dashboard' ),
        ),
        'youtube.com' => array(
            'icon' => 'bg-faded-danger text-danger rounded-circle p-1 fs-3 bx bxl-youtube',
            'label' => esc_html__( 'YouTube', 'flexify-dashboard' ),
        ),
        'facebook' => array(
            'icon' => 'bg-faded-primary text-primary rounded-circle p-1 fs-3 bx bxl-facebook-circle',
            'label' => esc_html__( 'Facebook', 'flexify-dashboard' ),
        ),
        'instagram' => array(
            'icon' => 'bg-faded-danger text-danger rounded-circle p-1 fs-3 bx bxl-instagram',
            'label' => esc_html__( 'Instagram', 'flexify-dashboard' ),
        ),
        'google' => array(
            'icon' => 'bg-faded-info text-dark rounded-circle p-1 fs-3 bx bxl-google',
            'label' => esc_html__( 'Google', 'flexify-dashboard' ),
        ),
        'referral' => array(
            'icon' => 'bg-faded-success text-success rounded-circle p-1 fs-3 bx bx-share',
            'label' => esc_html__( 'Indicação ou referência', 'flexify-dashboard' ),
        ),
        'admin' => array(
            'icon' => 'bg-faded-primary text-primary rounded-circle p-1 fs-3 bx bx-card',
            'label' => esc_html__( 'Administrador', 'flexify-dashboard' ),
        ),
        'mobile_app' => array(
            'icon' => 'bg-faded-dark text-dark rounded-circle p-1 fs-3 bx bx-mobile-alt',
            'label' => esc_html__( 'Aplicativo móvel', 'flexify-dashboard' ),
        ),
        '' => array(
            'icon' => 'bg-faded-info text-info rounded-circle p-1 fs-3 bx bx-hash',
            'label' => esc_html__( 'Desconhecido', 'flexify-dashboard' ),
        ),
    );

    return apply_filters( 'flexify_dashboard_origin_filter', $origin_filter );
}


/**
 * Get best-selling products
 * 
 * @since 1.5.0
 * @param int $limit | The number of products to retrieve
 * @return array
 */
function get_best_selling_products( $limit = 5 ) {
    global $wpdb;

    $query = "
        SELECT 
            p.ID, 
            p.post_title, 
            SUM(om_qty.meta_value) as total_sales,
            COUNT(DISTINCT oi.order_id) as order_count,
            SUM(om_total.meta_value) as total_revenue
        FROM {$wpdb->prefix}posts p
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta om_qty ON p.ID = om_qty.meta_value
        INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oi.order_item_id = om_qty.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta om_total ON oi.order_item_id = om_total.order_item_id
        WHERE p.post_type = 'product'
        AND om_qty.meta_key = '_product_id'
        AND om_total.meta_key = '_line_total'
        AND p.post_status = 'publish'
        GROUP BY p.ID
        ORDER BY total_sales DESC
        LIMIT %d
    ";

    $results = $wpdb->get_results( $wpdb->prepare( $query, $limit ), ARRAY_A );

    return $results;
}
