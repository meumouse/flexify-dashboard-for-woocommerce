<?php

namespace MeuMouse\Flexify_Dashboard;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.5.0
 * @package MeuMouse.com
 */
class Init {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function __construct() {
        // set default options
        add_action( 'admin_init', array( $this, 'set_default_options' ) );
    }


    /**
     * Set default options
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return array
     */
    public function set_default_data_options() {
        $options = array(
            'enable_total_users_widget' => 'yes',
            'enable_products_registered_widget' => 'yes',
            'enable_average_ticket_widget' => 'yes',
            'enable_anual_billing_widget' => 'yes',
            'enable_technology_ga_widget' => 'yes',
            'enable_orders_number_widget' => 'yes',
            'enable_visitor_type_widget' => 'yes',
            'enable_apexcharts_toolbar' => 'no',
            'enable_admin_search_posts' => 'yes',
            'enable_dark_mode' => 'yes',
            'dashboard_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-light.png' ),
            'admin_login_image' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/flexify-dashboard-login.jpg' ),
            'primary_color' => '#008aff',
            'success_color' => '#22c55e',
            'warning_color' => '#ffba08',
            'danger_color' => '#ef4444',
            'info_color' => '#4c82f7',
            'enable_recaptcha_admin_login' => 'no',
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'enable_ga_integration' => 'no',
            'ga_client_id' => '',
            'ga_client_secret' => '',
            'ga_map_target_country' => 'BR',
            'ga_google_maps_api_key' => '',
            'enable_meta_pixel_integration' => 'no',
            'enable_admin_bar' => 'no',
            'enable_flexify_dashboard_login_page' => 'yes',
            'admin_login_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-single.png' ),
            'enable_last_orders_widget' => 'yes',
            'get_last_order_number_query' => 5,
            'enable_flexify_dashboard_loader_pages' => 'yes',
            'set_primary_color' => '#008aff',
            'set_success_color' => '#22c55e',
            'set_warning_color' => '#ffc42d',
            'set_danger_color' => '#ef4444',
            'set_info_color' => '#4c82f7',
            'set_dark_color' => '#1a222c',
            'enable_custom_heartbeat_control' => 'yes',
            'set_admin_heartbeat_interval' => 120,
            'set_front_heartbeat_interval' => 120,
            'enable_widget_best_selling_products' => 'yes',
            'get_best_selling_products_query' => 5,
        );

        return apply_filters( 'flexify_dashboard_set_default_options', $options );
    }


    /**
     * Gets the items from the array and inserts them into the option if it is empty,
     * or adds new items with default value to the option
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @return void
     */
    public function set_default_options() {
        $get_options = $this->set_default_data_options();
        $default_options = maybe_unserialize( get_option('flexify_dashboard_data_options', array()) );
    
        if ( empty( $default_options ) ) {
            update_option('flexify_dashboard_data_options', maybe_serialize( $get_options ));
        } else {
            foreach ( $get_options as $key => $value ) {
                if ( ! isset( $default_options[$key] ) ) {
                    $default_options[$key] = $value;
                }
            }
    
            update_option('flexify_dashboard_data_options', maybe_serialize( $default_options ));
        }
    }


    /**
	 * Checks if the option exists and returns the indicated array item
	 * 
	 * @since 1.0.0
     * @version 1.5.0
     * @param $key | Array key
     * @return mixed | string or false
	 */
    public static function get_setting( $key ) {
        $default_options = maybe_unserialize( get_option('flexify_dashboard_data_options', array()) );

        // check if array key exists and return key
        if ( isset( $default_options[$key] ) ) {
            return $default_options[$key];
        }

        return false;
    }
}

new Init();