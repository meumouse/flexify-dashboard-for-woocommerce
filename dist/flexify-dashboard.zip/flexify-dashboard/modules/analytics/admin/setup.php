<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Backend_Setup' ) ) {

	final class Flexify_Dashboard_Analytics_Backend_Setup {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			// Styles & Scripts
			add_action( 'admin_enqueue_scripts', array( $this, 'load_styles_scripts' ) );

			include ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/admin/settings.php' );
			// Site Menu
		//	add_action( 'admin_menu', array( $this, 'site_menu' ) );
			// Network Menu
		//	add_action( 'network_admin_menu', array( $this, 'network_menu' ) );
		}

		/**
		 * Add Site Menu
		 */
		public function site_menu() {
			global $wp_version;

			if ( current_user_can( 'manage_options' ) ) {
				add_menu_page( __( "Analytics Insights", 'flexify-dashboard' ), __( "Analytics Insights", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'general_settings' ), version_compare( $wp_version, '3.8.0', '>=' ) ? 'dashicons-chart-area' : FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/admin/images/flexify_dashboard_analytics-icon.png' );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "General Settings", 'flexify-dashboard' ), __( "General Settings", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'general_settings' ) );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "Backend Settings", 'flexify-dashboard' ), __( "Backend Settings", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_backend_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'backend_settings' ) );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "Frontend Settings", 'flexify-dashboard' ), __( "Frontend Settings", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_frontend_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'frontend_settings' ) );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "Tracking Code", 'flexify-dashboard' ), __( "Tracking Code", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_tracking_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'tracking_settings' ) );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "Errors & Debug", 'flexify-dashboard' ), __( "Errors & Debug", 'flexify-dashboard' ), 'manage_options', 'flexify_dashboard_analytics_errors_debugging', array( 'Flexify_Dashboard_Analytics_Settings', 'errors_debugging' ) );
			}
		}

		/**
		 * Add Network Menu
		 */
		public function network_menu() {
			global $wp_version;

			if ( current_user_can( 'manage_network' ) ) {
				include ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/admin/settings.php' );
				add_menu_page( __( "Analytics Insights", 'flexify-dashboard' ), "Analytics Insights", 'manage_network', 'flexify_dashboard_analytics_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'general_settings_network' ), version_compare( $wp_version, '3.8.0', '>=' ) ? 'dashicons-chart-area' : FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/admin/images/flexify_dashboard_analytics-icon.png' );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "General Settings", 'flexify-dashboard' ), __( "General Settings", 'flexify-dashboard' ), 'manage_network', 'flexify_dashboard_analytics_settings', array( 'Flexify_Dashboard_Analytics_Settings', 'general_settings_network' ) );
				add_submenu_page( 'flexify_dashboard_analytics_settings', __( "Errors & Debug", 'flexify-dashboard' ), __( "Errors & Debug", 'flexify-dashboard' ), 'manage_network', 'flexify_dashboard_analytics_errors_debugging', array( 'Flexify_Dashboard_Analytics_Settings', 'errors_debugging' ) );
			}
		}

		/**
		 * Styles & Scripts conditional loading (based on current URI)
		 *
		 * @since 1.0.0
		 * @param string $hook
		 */
		public function load_styles_scripts( $hook ) {
			$new_hook = explode( '_page_', $hook );

			if ( isset( $new_hook[1] ) ) {
				$new_hook = '_page_' . $new_hook[1];
			} else {
				$new_hook = $hook;
			}

			/*
			 * Flexify_Dashboard_Analytics main stylesheet
			 */
		//	wp_enqueue_style( 'flexify_dashboard_analytics', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/admin/css/flexify_dashboard_analytics' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.css', null, FLEXIFY_DASHBOARD_VERSION );
			/*
			 * Flexify_Dashboard_Analytics UI
			 */
			if ( Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ) ) {
				$ed_bubble = '!';
			} else {
				$ed_bubble = '';
			}

		/*	wp_enqueue_script( 'flexify_dashboard_analytics-backend-ui', plugins_url( 'js/ui' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.js', __FILE__ ), array( 'jquery' ), FLEXIFY_DASHBOARD_VERSION, true );
			
			wp_localize_script( 'flexify_dashboard_analytics-backend-ui', 'flexify_dashboard_analytics_ui_data', array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'security' => wp_create_nonce( 'flexify_dashboard_analytics_dismiss_notices' ),
				'ed_bubble' => $ed_bubble,
			)
			);*/

			if ( $this->flexify_dashboard_analytics->config->options['switch_profile'] && count( $this->flexify_dashboard_analytics->config->options['ga4_webstreams_list'] ) > 1 ) {
				$views = array();
				
				foreach ( $this->flexify_dashboard_analytics->config->options['ga4_webstreams_list'] as $items ) {
					if ( $items[2] ) {
						$views[$items[1]] = sanitize_text_field( Flexify_Dashboard_Analytics_Tools::strip_protocol( $items[2] ) );
					}
				}
			} else {
				$views = false;
			}

			/*
			 * Main Dashboard Widgets Styles & Scripts
			 */
			$widgets_hooks = array( 'index.php' );

			if ( in_array( $new_hook, $widgets_hooks ) ) {
				if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) && $this->flexify_dashboard_analytics->config->options['dashboard_widget'] ) {
					if ( $this->flexify_dashboard_analytics->config->options['ga_target_geomap'] ) {
						$country_codes = Flexify_Dashboard_Analytics_Tools::get_countrycodes();
						$country_codes = array_flip($country_codes);
						
						if ( 'none' !== $this->flexify_dashboard_analytics->config->options['ga_target_geomap'] && isset( $country_codes[$this->flexify_dashboard_analytics->config->options['ga_target_geomap']] ) ) {
							$region = sanitize_text_field( $country_codes[$this->flexify_dashboard_analytics->config->options['ga_target_geomap']] );
						} else {
							$region = false;
						}
					} else {
						$region = false;
					}

					wp_enqueue_style( 'flexify_dashboard_analytics-nprogress', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/common/nprogress/nprogress.css', null, FLEXIFY_DASHBOARD_VERSION );
					wp_enqueue_style( 'flexify_dashboard_analytics-backend-item-reports', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/admin/css/admin-widgets.css', null, FLEXIFY_DASHBOARD_VERSION );
					wp_register_style( 'jquery-ui-tooltip-html', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/common/realtime/jquery.ui.tooltip.html.css' );
					wp_enqueue_style( 'jquery-ui-tooltip-html' );
					wp_register_script( 'jquery-ui-tooltip-html', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/common/realtime/jquery.ui.tooltip.html.js' );
					wp_register_script( 'googlecharts', 'https://www.gstatic.com/charts/loader.js', array(), null );
					wp_enqueue_script( 'flexify_dashboard_analytics-nprogress', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/common/nprogress/nprogress.js', array( 'jquery' ), FLEXIFY_DASHBOARD_VERSION );
					wp_enqueue_script( 'flexify_dashboard_analytics-backend-dashboard-reports', FLEXIFY_DASHBOARD_URL . '/modules/analytics/assets/admin/js/analytics-request.js', array( 'jquery', 'googlecharts', 'flexify_dashboard_analytics-nprogress', 'jquery-ui-tooltip', 'jquery-ui-core', 'jquery-ui-position', 'jquery-ui-tooltip-html' ), FLEXIFY_DASHBOARD_VERSION, true );
					
					$datelist = array(
						'realtime' => __( 'Tempo real', 'flexify-dashboard' ),
						'today' => __( 'Hoje', 'flexify-dashboard' ),
						'yesterday' => __( 'Ontem', 'flexify-dashboard' ),
						'7daysAgo' => sprintf( __( 'Últimos %d dias', 'flexify-dashboard' ), 7 ),
						'14daysAgo' => sprintf( __( 'Últimos %d dias', 'flexify-dashboard' ), 14 ),
						'30daysAgo' => sprintf( __( 'Últimos %d dias', 'flexify-dashboard' ), 30 ),
						'90daysAgo' => sprintf( __( 'Últimos %d dias', 'flexify-dashboard' ), 90 ),
						'365daysAgo' =>  sprintf( _n( '%s ano', '%s anos', 1, 'flexify-dashboard' ), __('Um', 'flexify-dashboard') ),
						'1095daysAgo' =>  sprintf( _n( '%s ano', '%s anos', 3, 'flexify-dashboard' ), __('Três', 'flexify-dashboard') ),
					);

					$report_list = array(
						'sessions' => __( 'Sessões', 'flexify-dashboard' ),
						'users' => __( 'Usuários', 'flexify-dashboard' ),
						'organicSearches' => __( 'Engajamento', 'flexify-dashboard' ),
						'pageviews' => __( 'Visualizações de página', 'flexify-dashboard' ),
						'visitBounceRate' => __( 'Taxa de rejeição', 'flexify-dashboard' ),
						'locations' => __( 'Localização', 'flexify-dashboard' ),
						'contentpages' =>  __( 'Páginas', 'flexify-dashboard' ),
						'referrers' => __( 'Referenciadores', 'flexify-dashboard' ),
						'searches' => __( 'Pesquisas', 'flexify-dashboard' ),
						'trafficdetails' => __( 'Tráfego', 'flexify-dashboard' ),
						'technologydetails' => __( 'Tecnologia', 'flexify-dashboard' ),
						'404errors' => __( 'Erros 404', 'flexify-dashboard' ),
					);

					$i18n = array(
						__( 'Um erro de JavaScript está bloqueando os recursos do plugin!', 'flexify-dashboard' ), //0
						__( 'Meios de tráfego', 'flexify-dashboard' ),
						__( 'Tipo de visitante', 'flexify-dashboard' ),
						__( 'Mecanismos de busca', 'flexify-dashboard' ),
						__( 'Idioma', 'flexify-dashboard' ),
						__( 'Sessões', 'flexify-dashboard' ),
						__( 'Usuários', 'flexify-dashboard' ),
						__( 'Visualizações de página', 'flexify-dashboard' ),
						__( 'Taxa de rejeição', 'flexify-dashboard' ),
						__( 'Duração da sessão', 'flexify-dashboard' ),
						__( 'Páginas/Sessão', 'flexify-dashboard' ),
						__( 'Resposta inválida', 'flexify-dashboard' ),
						__( 'Erro:', 'flexify-dashboard' ),
						__( 'Processando dados, verifique novamente em algumas horas', 'flexify-dashboard' ),
						__( 'Este recurso precisa de uma autorização:', 'flexify-dashboard' ) . ' <a href="' . menu_page_url( 'flexify-dashboard', false ) . '">' . __( 'Autorizar integração', 'flexify-dashboard' ) . '</a>.',
						__( 'Navegador', 'flexify-dashboard' ), //16
						__( 'Sistema operacional', 'flexify-dashboard' ),
						__( 'Resolução da tela', 'flexify-dashboard' ),
						__( 'Marca do celular', 'flexify-dashboard' ),
						__( 'REFERÊNCIAS', 'flexify-dashboard' ), //20
						__( 'PALAVRAS-CHAVE', 'flexify-dashboard' ),
						__( 'SOCIAL', 'flexify-dashboard' ),
						__( 'CAMPANHA', 'flexify-dashboard' ),
						__( 'DIRETO', 'flexify-dashboard' ),
						__( 'NOVO', 'flexify-dashboard' ), //25
						__( 'Pesquisa orgânica', 'flexify-dashboard' ),
						__( 'Sessões engajadas', 'flexify-dashboard' ),
						__( 'Engajamento total', 'flexify-dashboard' ),
						__( 'Duração da sessão', 'flexify-dashboard' ),
						__( '', 'flexify-dashboard' ),
						__( 'Procurar...', 'flexify-dashboard' ), //31
						__( 'COMPUTADOR', 'flexify-dashboard' ), //32
						__( 'CELULAR', 'flexify-dashboard' ), //33
						__( 'TABLET', 'flexify-dashboard' ), //34
						__( 'USUÁRIOS NOS ÚLTIMOS 30 MINUTOS', 'flexify-dashboard' ), //35
					);

					wp_localize_script( 'flexify_dashboard_analytics-backend-dashboard-reports', 'flexify_dashboard_analyticsItemData', array(
						'ajaxurl' => admin_url('admin-ajax.php'),
						'security' => wp_create_nonce( 'flexify_dashboard_analytics_backend_item_reports' ),
						'dateList' => $datelist,
						'reportList' => $report_list,
						'i18n' => $i18n,
						'rtLimitPages' => $this->flexify_dashboard_analytics->config->options['ga_realtime_pages'],
						'colorVariations' => Flexify_Dashboard_Analytics_Tools::variations( sanitize_text_field( $this->flexify_dashboard_analytics->config->options['theme_color'] ) ),
						'region' => $region,
						'mapsApiKey' => apply_filters( 'flexify_dashboard_analytics_maps_api_key', sanitize_text_field( Flexify_Dashboard_Init::get_setting('ga_google_maps_api_key') ) ),
						'language' => get_bloginfo( 'language' ),
						'viewList' => $views,
						'scope' => 'admin-widgets',
					));
				}
			}
		}
	}
}
