<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tools' ) ) {

	class Flexify_Dashboard_Analytics_Tools {

		public static function guess_default_domain( $profiles, $index = 3 ) {
			$domain = get_option( 'siteurl' );
			$domain = str_ireplace( array( 'http://', 'https://' ), '', $domain );
			if ( ! empty( $profiles ) ) {
				foreach ( $profiles as $items ) {
					if ( strpos( $items[$index], $domain ) ) {
						return $items[1];
					}
				}
				return $profiles[0][1];
			} else {
				return '';
			}
		}

		public static function get_selected_profile( $profiles, $profile ) {
			if ( ! empty( $profiles ) ) {
				foreach ( $profiles as $item ) {
					if ( isset( $item[1] ) && $item[1] == $profile ) {
						return $item;
					}
				}
			}
		}

		public static function get_root_domain() {
			$url = site_url();
			$root = explode( '/', $url );
			preg_match( '/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', str_ireplace( 'www', '', isset( $root[2] ) ? $root[2] : $url ), $root );
			if ( isset( $root['domain'] ) ) {
				return $root['domain'];
			} else {
				return '';
			}
		}

		public static function strip_protocol( $domain ) {
			return str_replace( array( "https://", "http://", " " ), "", $domain );
		}

		public static function colourVariator( $colour, $per ) {
			$colour = substr( $colour, 1 );
			$rgb = '';
			$per = $per / 100 * 255;
			if ( $per < 0 ) {
				// Darker
				$per = abs( $per );
				for ( $x = 0; $x < 3; $x++ ) {
					$c = hexdec( substr( $colour, ( 2 * $x ), 2 ) ) - $per;
					$c = ( $c < 0 ) ? 0 : dechex( (int) $c );
					$rgb .= ( strlen( $c ) < 2 ) ? '0' . $c : $c;
				}
			} else {
				// Lighter
				for ( $x = 0; $x < 3; $x++ ) {
					$c = hexdec( substr( $colour, ( 2 * $x ), 2 ) ) + $per;
					$c = ( $c > 255 ) ? 'ff' : dechex( (int) $c );
					$rgb .= ( strlen( $c ) < 2 ) ? '0' . $c : $c;
				}
			}
			return '#' . $rgb;
		}

		public static function variations( $base ) {
			$variations[] = $base;
			$variations[] = self::colourVariator( $base, - 10 );
			$variations[] = self::colourVariator( $base, + 10 );
			$variations[] = self::colourVariator( $base, + 20 );
			$variations[] = self::colourVariator( $base, - 20 );
			$variations[] = self::colourVariator( $base, + 30 );
			$variations[] = self::colourVariator( $base, - 30 );
			return $variations;
		}

		public static function check_roles( $access_level, $tracking = false ) {
			if ( is_user_logged_in() && isset( $access_level ) ) {
				$current_user = wp_get_current_user();
				$roles = (array) $current_user->roles;
				if ( ( current_user_can( 'manage_options' ) ) && ! $tracking ) {
					return true;
				}
				if ( count( array_intersect( $roles, $access_level ) ) > 0 ) {
					return true;
				} else {
					return false;
				}
			}
		}

		public static function unset_cookie( $name ) {
			$name = 'flexify_dashboard_analytics_wg_' . $name;
			setcookie( $name, '', time() - 3600, '/' );
			$name = 'flexify_dashboard_analytics_ir_' . $name;
			setcookie( $name, '', time() - 3600, '/' );
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function set_cache( $name, $value, $expiration = 0 ) {
			update_option( '_flexify_dashboard_analytics_cache_' . $name, $value, 'no' );
			if ( $expiration ) {
				update_option( '_flexify_dashboard_analytics_cache_timeout_' . $name, time() + (int) $expiration, 'no' );
			} else {
				update_option( '_flexify_dashboard_analytics_cache_timeout_' . $name, time() + 7 * 24 * 3600, 'no' );
			}
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function delete_cache( $name ) {
			delete_option( '_flexify_dashboard_analytics_cache_' . $name );
			delete_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function get_cache( $name ) {
			$value = get_option( '_flexify_dashboard_analytics_cache_' . $name );
			$expires = get_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
			if ( false === $value || ! isset( $value ) || ! isset( $expires ) ) {
				return false;
			}
			if ( $expires < time() ) {
				delete_option( '_flexify_dashboard_analytics_cache_' . $name );
				delete_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
				return false;
			} else {
				return $value;
			}
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 */
		public static function clear_cache() {
			global $wpdb;
			$sqlquery = $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '%%flexify_dashboard_analytics_cache_%%'" );
		}

		public static function delete_expired_cache() {
			global $wpdb, $wp_version;
			if ( wp_using_ext_object_cache() ) {
				return;
			}
			if ( version_compare( $wp_version, '4.0.0', '>=' ) ) {
				$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
				WHERE a.option_name LIKE %s
				AND a.option_name NOT LIKE %s
				AND b.option_name = CONCAT( '_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 13 ) )
				AND b.option_value < %d", $wpdb->esc_like( '_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				if ( ! is_multisite() ) {
					// Single site stores site transients in the options table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
					WHERE a.option_name LIKE %s
					AND a.option_name NOT LIKE %s
					AND b.option_name = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 18 ) )
					AND b.option_value < %d", $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				} elseif ( is_multisite() && is_main_site() && is_main_network() ) {
					// Multisite stores site transients in the sitemeta table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->sitemeta} a, {$wpdb->sitemeta} b
					WHERE a.meta_key LIKE %s
					AND a.meta_key NOT LIKE %s
					AND b.meta_key = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.meta_key, 18 ) )
					AND b.meta_value < %d", $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				}
			} else {
				$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
				WHERE a.option_name LIKE %s
				AND a.option_name NOT LIKE %s
				AND b.option_name = CONCAT( '_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 13 ) )
				AND b.option_value < %d", like_escape( '_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				if ( ! is_multisite() ) {
					// Single site stores site transients in the options table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
					WHERE a.option_name LIKE %s
					AND a.option_name NOT LIKE %s
					AND b.option_name = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 18 ) )
					AND b.option_value < %d", like_escape( '_site_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				} elseif ( is_multisite() && is_main_site() && is_main_network() ) {
					// Multisite stores site transients in the sitemeta table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->sitemeta} a, {$wpdb->sitemeta} b
					WHERE a.meta_key LIKE %s
					AND a.meta_key NOT LIKE %s
					AND b.meta_key = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.meta_key, 18 ) )
					AND b.meta_value < %d", like_escape( '_site_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				}
			}
		}

		public static function get_sites( $args ) { // Use wp_get_sites() if WP version is lower than 4.6.0
			global $wp_version;
			if ( version_compare( $wp_version, '4.6.0', '<' ) ) {
				return wp_get_sites( $args );
			} else {
				foreach ( get_sites( $args ) as $blog ) {
					$blogs[] = (array) $blog; // Convert WP_Site object to array
				}
				return $blogs;
			}
		}

		/**
		 * Loads a view file
		 *
		 * $data parameter will be available in the template file as $data['value']
		 *
		 * @param string $template - Template file to load
		 * @param array $data - data to pass along to the template
		 * @return boolean - If template file was found
		 **/
		public static function load_view( $path, $data = array(), $globalsitetag = 0 ) {
			if ( file_exists( FLEXIFY_DASHBOARD_MODULES_DIR . $path ) ) {
				require ( FLEXIFY_DASHBOARD_MODULES_DIR . $path );
				return true;
			}
			
			return false;
		}

		public static function doing_it_wrong( $function, $message, $version ) {
			if ( WP_DEBUG && apply_filters( 'doing_it_wrong_trigger_error', true ) ) {
				if ( is_null( $version ) ) {
					$version = '';
				} else {
					/* translators: %s: version number */
					$version = sprintf( __( 'This message was added in version %s.', 'flexify-dashboard' ), $version );
				}
				/* translators: Developer debugging message. 1: PHP function name, 2: Explanatory message, 3: Version information message */
				trigger_error( sprintf( __( '%1$s was called <strong>incorrectly</strong>. %2$s %3$s', 'flexify-dashboard' ), $function, $message, $version ) );
			}
		}

		public static function get_dom_from_content( $content ) {
			$libxml_previous_state = libxml_use_internal_errors( true );
			if ( class_exists( 'DOMDocument' ) ) {
				$dom = new DOMDocument();
				$result = $dom->loadHTML( '<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8"></head><body>' . $content . '</body></html>' );
				libxml_clear_errors();
				libxml_use_internal_errors( $libxml_previous_state );
				if ( ! $result ) {
					return false;
				}
				return $dom;
			} else {
				self::set_error( __( 'DOM is disabled or libxml PHP extension is missing. Contact your hosting provider. Automatic tracking of events for AMP pages is not possible.', 'flexify-dashboard' ), 24 * 60 * 60 );
				return false;
			}
		}

		public static function get_content_from_dom( $dom ) {
			$out = '';
			$body = $dom->getElementsByTagName( 'body' )->item( 0 );
			foreach ( $body->childNodes as $node ) {
				$out .= $dom->saveXML( $node );
			}
			return $out;
		}

		public static function array_keys_rename( $options, $keys ) {
			foreach ( $keys as $key => $newkey ) {
				if ( isset( $options[$key] ) ) {
					$options[$newkey] = $options[$key];
					unset( $options[$key] );
				}
			}
			return $options;
		}

		public static function set_error( $e, $timeout, $ajax = false ) {
			if ( $ajax ) {
				self::set_cache( 'ajax_errors', esc_html( print_r( $e, true ) ), $timeout );
			} else {
				if ( is_object( $e ) ) {
					if ( method_exists( $e, 'get_error_code' ) && method_exists( $e, 'get_error_message' ) ) {
						$error_code = $e->get_error_code();
						if ( 500 == $error_code || 503 == $error_code ) {
							$timeout = 60;
						}
						self::set_cache( 'api_errors', array( $e->get_error_code(), $e->get_error_message(), $e->get_error_data() ), $timeout );
					} else {
						self::set_cache( 'api_errors', array( 600, array(), esc_html( print_r( $e, true ) ) ), $timeout );
					}
				} else if ( is_array( $e ) ) {
					self::set_cache( 'api_errors', array( 601, array(), esc_html( print_r( $e, true ) ) ), $timeout );
				} else {
					self::set_cache( 'api_errors', array( 602, array(), esc_html( print_r( $e, true ) ) ), $timeout );
				}
				// Count Errors until midnight
				$midnight = strtotime( "tomorrow 00:00:00" ); // UTC midnight
				$midnight = $midnight + 8 * 3600; // UTC 8 AM
				$tomidnight = $midnight - time();
				$errors_count = self::get_cache( 'errors_count' );
				$errors_count = (int) $errors_count + 1;
				self::set_cache( 'errors_count', $errors_count, $tomidnight );
			}
		}

		public static function anonymize_options( $options ) {
			global $wp_version;
			$options['wp_version'] = $wp_version;
			$options['flexify_dashboard_analytics_version'] = FLEXIFY_DASHBOARD_VERSION;
			if ( $options['token'] && ( ! WP_DEBUG || ( is_multisite() && ! current_user_can( 'manage_network_options' ) ) ) ) {
				$options['token'] = 'HIDDEN';
			} else {
				$options['token'] = (array) $options['token'];
				unset( $options['token']['challenge'] );
			}
			if ( $options['client_secret'] ) {
				$options['client_secret'] = 'HIDDEN';
			}
			return $options;
		}

		public static function system_info() {
			$info = '';
			// Server Software
			$server_soft = "-";
			if ( isset( $_SERVER['SERVER_SOFTWARE'] ) ) {
				$server_soft = $_SERVER['SERVER_SOFTWARE'];
			}
			$info .= 'Server Info: ' . sanitize_text_field( $server_soft ) . "\n";
			// PHP version
			if ( defined( 'PHP_VERSION' ) ) {
				$info .= 'PHP Version: ' . PHP_VERSION . "\n";
			} else if ( defined( 'HHVM_VERSION' ) ) {
				$info .= 'HHVM Version: ' . HHVM_VERSION . "\n";
			} else {
				$info .= 'Other Version: ' . '-' . "\n";
			}
			// cURL Info
			if ( function_exists( 'curl_version' ) && function_exists( 'curl_exec' ) ) {
				$curl_version = curl_version();
				if ( ! empty( $curl_version ) ) {
					$curl_ver = $curl_version['version'] . " " . $curl_version['ssl_version'];
				} else {
					$curl_ver = '-';
				}
			} else {
				$curl_ver = '-';
			}
			$info .= 'cURL Info: ' . $curl_ver . "\n";
			// Gzip
			if ( is_callable( 'gzopen' ) ) {
				$gzip = true;
			} else {
				$gzip = false;
			}
			$gzip_status = ( $gzip ) ? 'Yes' : 'No';
			$info .= 'Gzip: ' . $gzip_status . "\n";
			return $info;
		}

		/**
		 * Follows the SCRIPT_DEBUG settings
		 * @param string $script
		 * @return string
		 */
		public static function script_debug_suffix() {
			if ( defined( 'SCRIPT_DEBUG' ) and SCRIPT_DEBUG ) {
				return '';
			} else {
				return '.min';
			}
		}

		/**
		 * Dimensions and metric mapping from GA3 to GA4
		 * @param string $value
		 * @return string
		 */
		public static function ga3_ga4_mapping( $value ) {
			$value = str_replace( 'ga:', '', $value );
			$list = [ 'users' => 'totalUsers', 'sessionDuration' => 'userEngagementDuration', 'fullReferrer' => 'pageReferrer', 'source' => 'sessionSource', 'medium' => 'sessionMedium', 'dataSource' => 'platform',
				// 'pagePath' => 'pagePathPlusQueryString',
				'pageviews' => 'screenPageViews', 'pageviewsPerSession' => 'screenPageViewsPerSession', 'timeOnPage' => 'userEngagementDuration', 'channelGrouping' => 'sessionDefaultChannelGrouping', 'dayOfWeekName' => 'dayOfWeek', 'visitBounceRate' => 'bounceRate', 'organicSearches' => 'engagedSessions', 'socialNetwork' => 'language', 'visitorType' => 'newVsReturning', 'uniquePageviews' => 'sessions' ];
			if ( isset( $list[$value] ) ) {
				return $list[$value];
			} else {
				return $value;
			}
		}

		public static function secondstohms( $value ) {
			$value = (float) $value;
			$hours = floor( $value / 3600 );
			$hours = $hours < 10 ? '0' . $hours : (string) $hours;
			$minutes = floor( (int) ( $value / 60 ) % 60 );
			$minutes = $minutes < 10 ? '0' . $minutes : (string) $minutes;
			$seconds = floor( (int)$value % 60 );
			$seconds = $seconds < 10 ? '0' . $seconds : (string) $seconds;
			return $hours . ':' . $minutes . ':' . $seconds;
		}

		public static function is_amp() {
			if ( is_singular( 'web-story' ) ) {
				return true;
			}
			return function_exists( 'is_amp_endpoint' ) && is_amp_endpoint();
		}

		public function generate_random( $length = 10 ) {
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen( $characters );
			$randomString = '';
			for ( $i = 0; $i < $length; $i++ ) {
				$randomString .= $characters[random_int( 0, $charactersLength - 1 )];
			}
			return $randomString;
		}

		public static function report_errors() {
			if ( Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ) ) {
				$info = Flexify_Dashboard_Analytics_Tools::system_info();
				$info .= 'Flexify_Dashboard_Analytics Version: ' . FLEXIFY_DASHBOARD_VERSION;
				$sep = "\n---------------------------\n";
				$error_report = $sep . print_r( Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ), true );
				$error_report .= $sep . Flexify_Dashboard_Analytics_Tools::get_cache( 'errors_count' );
				$error_report .= $sep . $info;
				$error_report = urldecode( $error_report );
				$url = Flexify_Dashboard_Analytics_ENDPOINT_URL . 'flexify_dashboard_analytics-report.php';
				
		$response = wp_remote_post( $url, array(
		 'method' => 'POST',
		 'timeout' => 45,
		 'redirection' => 5,
		 'httpversion' => '1.0',
		 'blocking' => true,
		 'headers' => array(),
		 'body' => array( 'error_report' => esc_html( $error_report ) ),
		 'cookies' => array()
		 )
		 );
		
		 }
		}

		/** Keeps compatibility with WP < 5.3.0
		 *
		 * @return string
		 */
		public static function timezone_string() {
			$timezone_string = get_option( 'timezone_string' );

			if ( $timezone_string ) {
				return $timezone_string;
			}

			$offset  = (float) get_option( 'gmt_offset' );
			$hours   = (int) $offset;
			$minutes = ( $offset - $hours );

			$sign      = ( $offset < 0 ) ? '-' : '+';
			$abs_hour  = abs( $hours );
			$abs_mins  = abs( $minutes * 60 );
			$tz_offset = sprintf( '%s%02d:%02d', $sign, $abs_hour, $abs_mins );

			return $tz_offset;
		}


		/**
		 * Get country codes array
		 * ISO 3166 alpha-2 country codes
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public static function get_countrycodes() {
			return array(
				'none' => esc_html( 'Nenhum', 'flexify-dashboard' ),
				'AF' => esc_html( 'Afghanistan', 'flexify-dashboard' ),
				'AL' => esc_html( 'Albania', 'flexify-dashboard' ),
				'DZ' => esc_html( 'Algeria', 'flexify-dashboard' ),
				'AS' => esc_html( 'American Samoa', 'flexify-dashboard' ),
				'AD' => esc_html( 'Andorra', 'flexify-dashboard' ),
				'AO' => esc_html( 'Angola', 'flexify-dashboard' ),
				'AI' => esc_html( 'Anguilla', 'flexify-dashboard' ),
				'AQ' => esc_html( 'Antarctica', 'flexify-dashboard' ),
				'AG' => esc_html( 'Antigua and Barbuda', 'flexify-dashboard' ),
				'AR' => esc_html( 'Argentina', 'flexify-dashboard' ),
				'AM' => esc_html( 'Armenia', 'flexify-dashboard' ),
				'AW' => esc_html( 'Aruba', 'flexify-dashboard' ),
				'AU' => esc_html( 'Australia', 'flexify-dashboard' ),
				'AT' => esc_html( 'Austria', 'flexify-dashboard' ),
				'AZ' => esc_html( 'Azerbaijan', 'flexify-dashboard' ),
				'BS' => esc_html( 'Bahamas', 'flexify-dashboard' ),
				'BH' => esc_html( 'Bahrain', 'flexify-dashboard' ),
				'BD' => esc_html( 'Bangladesh', 'flexify-dashboard' ),
				'BB' => esc_html( 'Barbados', 'flexify-dashboard' ),
				'BY' => esc_html( 'Belarus', 'flexify-dashboard' ),
				'BE' => esc_html( 'Belgium', 'flexify-dashboard' ),
				'BZ' => esc_html( 'Belize', 'flexify-dashboard' ),
				'BJ' => esc_html( 'Benin', 'flexify-dashboard' ),
				'BM' => esc_html( 'Bermuda', 'flexify-dashboard' ),
				'BT' => esc_html( 'Bhutan', 'flexify-dashboard' ),
				'BO' => esc_html( 'Bolivia', 'flexify-dashboard' ),
				'BQ' => esc_html( 'Bonaire, Sint Eustatius and Saba', 'flexify-dashboard' ),
				'BA' => esc_html( 'Bosnia and Herzegovina', 'flexify-dashboard' ),
				'BW' => esc_html( 'Botswana', 'flexify-dashboard' ),
				'BV' => esc_html( 'Bouvet Island', 'flexify-dashboard' ),
				'BR' => esc_html( 'Brasil', 'flexify-dashboard' ),
				'IO' => esc_html( 'British Indian Ocean Territory', 'flexify-dashboard' ),
				'BN' => esc_html( 'Brunei Darussalam', 'flexify-dashboard' ),
				'BG' => esc_html( 'Bulgaria', 'flexify-dashboard' ),
				'BF' => esc_html( 'Burkina Faso', 'flexify-dashboard' ),
				'BI' => esc_html( 'Burundi', 'flexify-dashboard' ),
				'CV' => esc_html( 'Cabo Verde', 'flexify-dashboard' ),
				'KH' => esc_html( 'Cambodia', 'flexify-dashboard' ),
				'CM' => esc_html( 'Cameroon', 'flexify-dashboard' ),
				'CA' => esc_html( 'Canada', 'flexify-dashboard' ),
				'KY' => esc_html( 'Cayman Islands', 'flexify-dashboard' ),
				'CF' => esc_html( 'Central African Republic', 'flexify-dashboard' ),
				'TD' => esc_html( 'Chad', 'flexify-dashboard' ),
				'CL' => esc_html( 'Chile', 'flexify-dashboard' ),
				'CN' => esc_html( 'China', 'flexify-dashboard' ),
				'CX' => esc_html( 'Christmas Island', 'flexify-dashboard' ),
				'CC' => esc_html( 'Cocos (Keeling) Islands', 'flexify-dashboard' ),
				'CO' => esc_html( 'Colombia', 'flexify-dashboard' ),
				'KM' => esc_html( 'Comoros', 'flexify-dashboard' ),
				'CD' => esc_html( 'Democratic Republic of the Congo', 'flexify-dashboard' ),
				'CG' => esc_html( 'Republic of the Congo', 'flexify-dashboard' ),
				'CK' => esc_html( 'Cook Islands', 'flexify-dashboard' ),
				'CR' => esc_html( 'Costa Rica', 'flexify-dashboard' ),
				'HR' => esc_html( 'Croatia', 'flexify-dashboard' ),
				'CU' => esc_html( 'Cuba', 'flexify-dashboard' ),
				'CW' => esc_html( 'Curaçao', 'flexify-dashboard' ),
				'CY' => esc_html( 'Cyprus', 'flexify-dashboard' ),
				'CZ' => esc_html( 'Czechia', 'flexify-dashboard' ),
				'CI' => esc_html( 'Côte d`Ivoire', 'flexify-dashboard' ),
				'DK' => esc_html( 'Denmark', 'flexify-dashboard' ),
				'DJ' => esc_html( 'Djibouti', 'flexify-dashboard' ),
				'DM' => esc_html( 'Dominica', 'flexify-dashboard' ),
				'DO' => esc_html( 'Dominican Republic', 'flexify-dashboard' ),
				'EC' => esc_html( 'Ecuador', 'flexify-dashboard' ),
				'EG' => esc_html( 'Egypt', 'flexify-dashboard' ),
				'SV' => esc_html( 'El Salvador', 'flexify-dashboard' ),
				'GQ' => esc_html( 'Equatorial Guinea', 'flexify-dashboard' ),
				'ER' => esc_html( 'Eritrea', 'flexify-dashboard' ),
				'EE' => esc_html( 'Estonia', 'flexify-dashboard' ),
				'SZ' => esc_html( 'Eswatini', 'flexify-dashboard' ),
				'ET' => esc_html( 'Ethiopia', 'flexify-dashboard' ),
				'FK' => esc_html( 'Falkland Islands [Malvinas]', 'flexify-dashboard' ),
				'FO' => esc_html( 'Faroe Islands', 'flexify-dashboard' ),
				'FJ' => esc_html( 'Fiji', 'flexify-dashboard' ),
				'FI' => esc_html( 'Finland', 'flexify-dashboard' ),
				'FR' => esc_html( 'France', 'flexify-dashboard' ),
				'GF' => esc_html( 'French Guiana', 'flexify-dashboard' ),
				'PF' => esc_html( 'French Polynesia', 'flexify-dashboard' ),
				'TF' => esc_html( 'French Southern Territories', 'flexify-dashboard' ),
				'GA' => esc_html( 'Gabon', 'flexify-dashboard' ),
				'GM' => esc_html( 'Gambia', 'flexify-dashboard' ),
				'GE' => esc_html( 'Georgia', 'flexify-dashboard' ),
				'DE' => esc_html( 'Germany', 'flexify-dashboard' ),
				'GH' => esc_html( 'Ghana', 'flexify-dashboard' ),
				'GI' => esc_html( 'Gibraltar', 'flexify-dashboard' ),
				'GR' => esc_html( 'Greece', 'flexify-dashboard' ),
				'GL' => esc_html( 'Greenland', 'flexify-dashboard' ),
				'GD' => esc_html( 'Grenada', 'flexify-dashboard' ),
				'GP' => esc_html( 'Guadeloupe', 'flexify-dashboard' ),
				'GU' => esc_html( 'Guam', 'flexify-dashboard' ),
				'GT' => esc_html( 'Guatemala', 'flexify-dashboard' ),
				'GG' => esc_html( 'Guernsey', 'flexify-dashboard' ),
				'GN' => esc_html( 'Guinea', 'flexify-dashboard' ),
				'GW' => esc_html( 'Guinea-Bissau', 'flexify-dashboard' ),
				'GY' => esc_html( 'Guyana', 'flexify-dashboard' ),
				'HT' => esc_html( 'Haiti', 'flexify-dashboard' ),
				'HM' => esc_html( 'Heard Island and McDonald Islands', 'flexify-dashboard' ),
				'VA' => esc_html( 'Holy See', 'flexify-dashboard' ),
				'HN' => esc_html( 'Honduras', 'flexify-dashboard' ),
				'HK' => esc_html( 'Hong Kong', 'flexify-dashboard' ),
				'HU' => esc_html( 'Hungary', 'flexify-dashboard' ),
				'IS' => esc_html( 'Iceland', 'flexify-dashboard' ),
				'IN' => esc_html( 'India', 'flexify-dashboard' ),
				'ID' => esc_html( 'Indonesia', 'flexify-dashboard' ),
				'IR' => esc_html( 'Iran', 'flexify-dashboard' ),
				'IQ' => esc_html( 'Iraq', 'flexify-dashboard' ),
				'IE' => esc_html( 'Ireland', 'flexify-dashboard' ),
				'IM' => esc_html( 'Isle of Man', 'flexify-dashboard' ),
				'IL' => esc_html( 'Israel', 'flexify-dashboard' ),
				'IT' => esc_html( 'Italy', 'flexify-dashboard' ),
				'JM' => esc_html( 'Jamaica', 'flexify-dashboard' ),
				'JP' => esc_html( 'Japan', 'flexify-dashboard' ),
				'JE' => esc_html( 'Jersey', 'flexify-dashboard' ),
				'JO' => esc_html( 'Jordan', 'flexify-dashboard' ),
				'KZ' => esc_html( 'Kazakhstan', 'flexify-dashboard' ),
				'KE' => esc_html( 'Kenya', 'flexify-dashboard' ),
				'KI' => esc_html( 'Kiribati', 'flexify-dashboard' ),
				'KP' => esc_html( 'Democratic Peoples Republic of Korea', 'flexify-dashboard' ),
				'KR' => esc_html( 'Republic of Korea', 'flexify-dashboard' ),
				'KW' => esc_html( 'Kuwait', 'flexify-dashboard' ),
				'KG' => esc_html( 'Kyrgyzstan', 'flexify-dashboard' ),
				'LA' => esc_html( 'Lao', 'flexify-dashboard' ),
				'LV' => esc_html( 'Latvia', 'flexify-dashboard' ),
				'LB' => esc_html( 'Lebanon', 'flexify-dashboard' ),
				'LS' => esc_html( 'Lesotho', 'flexify-dashboard' ),
				'LR' => esc_html( 'Liberia', 'flexify-dashboard' ),
				'LY' => esc_html( 'Libya', 'flexify-dashboard' ),
				'LI' => esc_html( 'Liechtenstein', 'flexify-dashboard' ),
				'LT' => esc_html( 'Lithuania', 'flexify-dashboard' ),
				'LU' => esc_html( 'Luxembourg', 'flexify-dashboard' ),
				'MO' => esc_html( 'Macao', 'flexify-dashboard' ),
				'MG' => esc_html( 'Madagascar', 'flexify-dashboard' ),
				'MW' => esc_html( 'Malawi', 'flexify-dashboard' ),
				'MY' => esc_html( 'Malaysia', 'flexify-dashboard' ),
				'MV' => esc_html( 'Maldives', 'flexify-dashboard' ),
				'ML' => esc_html( 'Mali', 'flexify-dashboard' ),
				'MT' => esc_html( 'Malta', 'flexify-dashboard' ),
				'MH' => esc_html( 'Marshall Islands', 'flexify-dashboard' ),
				'MQ' => esc_html( 'Martinique', 'flexify-dashboard' ),
				'MR' => esc_html( 'Mauritania', 'flexify-dashboard' ),
				'MU' => esc_html( 'Mauritius', 'flexify-dashboard' ),
				'YT' => esc_html( 'Mayotte', 'flexify-dashboard' ),
				'MX' => esc_html( 'Mexico', 'flexify-dashboard' ),
				'FM' => esc_html( 'Micronesia', 'flexify-dashboard' ),
				'MD' => esc_html( 'Moldova', 'flexify-dashboard' ),
				'MC' => esc_html( 'Monaco', 'flexify-dashboard' ),
				'MN' => esc_html( 'Mongolia', 'flexify-dashboard' ),
				'ME' => esc_html( 'Montenegro', 'flexify-dashboard' ),
				'MS' => esc_html( 'Montserrat', 'flexify-dashboard' ),
				'MA' => esc_html( 'Morocco', 'flexify-dashboard' ),
				'MZ' => esc_html( 'Mozambique', 'flexify-dashboard' ),
				'MM' => esc_html( 'Myanmar', 'flexify-dashboard' ),
				'NA' => esc_html( 'Namibia', 'flexify-dashboard' ),
				'NR' => esc_html( 'Nauru', 'flexify-dashboard' ),
				'NP' => esc_html( 'Nepal', 'flexify-dashboard' ),
				'NL' => esc_html( 'Netherlands', 'flexify-dashboard' ),
				'NC' => esc_html( 'New Caledonia', 'flexify-dashboard' ),
				'NZ' => esc_html( 'New Zealand', 'flexify-dashboard' ),
				'NI' => esc_html( 'Nicaragua', 'flexify-dashboard' ),
				'NE' => esc_html( 'Niger', 'flexify-dashboard' ),
				'NG' => esc_html( 'Nigeria', 'flexify-dashboard' ),
				'NU' => esc_html( 'Niue', 'flexify-dashboard' ),
				'NF' => esc_html( 'Norfolk Island', 'flexify-dashboard' ),
				'MP' => esc_html( 'Northern Mariana Islands', 'flexify-dashboard' ),
				'NO' => esc_html( 'Norway', 'flexify-dashboard' ),
				'OM' => esc_html( 'Oman', 'flexify-dashboard' ),
				'PK' => esc_html( 'Pakistan', 'flexify-dashboard' ),
				'PW' => esc_html( 'Palau', 'flexify-dashboard' ),
				'PS' => esc_html( 'Palestine, State of Israel', 'flexify-dashboard' ),
				'PA' => esc_html( 'Panama', 'flexify-dashboard' ),
				'PG' => esc_html( 'Papua New Guinea', 'flexify-dashboard' ),
				'PY' => esc_html( 'Paraguay', 'flexify-dashboard' ),
				'PE' => esc_html( 'Peru', 'flexify-dashboard' ),
				'PH' => esc_html( 'Philippines', 'flexify-dashboard' ),
				'PN' => esc_html( 'Pitcairn', 'flexify-dashboard' ),
				'PL' => esc_html( 'Poland', 'flexify-dashboard' ),
				'PT' => esc_html( 'Portugal', 'flexify-dashboard' ),
				'PR' => esc_html( 'Puerto Rico', 'flexify-dashboard' ),
				'QA' => esc_html( 'Qatar', 'flexify-dashboard' ),
				'MK' => esc_html( 'Republic of North Macedonia', 'flexify-dashboard' ),
				'RO' => esc_html( 'Romania', 'flexify-dashboard' ),
				'RU' => esc_html( 'Russian Federation', 'flexify-dashboard' ),
				'RW' => esc_html( 'Rwanda', 'flexify-dashboard' ),
				'RE' => esc_html( 'Réunion', 'flexify-dashboard' ),
				'BL' => esc_html( 'Saint Barthélemy', 'flexify-dashboard' ),
				'SH' => esc_html( 'Saint Helena, Ascension and Tristan da Cunha', 'flexify-dashboard' ),
				'KN' => esc_html( 'Saint Kitts and Nevis', 'flexify-dashboard' ),
				'LC' => esc_html( 'Saint Lucia', 'flexify-dashboard' ),
				'MF' => esc_html( 'Saint Martin', 'flexify-dashboard' ),
				'PM' => esc_html( 'Saint Pierre and Miquelon', 'flexify-dashboard' ),
				'VC' => esc_html( 'Saint Vincent and the Grenadines', 'flexify-dashboard' ),
				'WS' => esc_html( 'Samoa', 'flexify-dashboard' ),
				'SM' => esc_html( 'San Marino', 'flexify-dashboard' ),
				'ST' => esc_html( 'Sao Tome and Principe', 'flexify-dashboard' ),
				'SA' => esc_html( 'Saudi Arabia', 'flexify-dashboard' ),
				'SN' => esc_html( 'Senegal', 'flexify-dashboard' ),
				'RS' => esc_html( 'Serbia', 'flexify-dashboard' ),
				'SC' => esc_html( 'Seychelles', 'flexify-dashboard' ),
				'SL' => esc_html( 'Sierra Leone', 'flexify-dashboard' ),
				'SG' => esc_html( 'Singapore', 'flexify-dashboard' ),
				'SX' => esc_html( 'Sint Maarten', 'flexify-dashboard' ),
				'SK' => esc_html( 'Slovakia', 'flexify-dashboard' ),
				'SI' => esc_html( 'Slovenia', 'flexify-dashboard' ),
				'SB' => esc_html( 'Solomon Islands', 'flexify-dashboard' ),
				'SO' => esc_html( 'Somalia', 'flexify-dashboard' ),
				'ZA' => esc_html( 'South Africa', 'flexify-dashboard' ),
				'GS' => esc_html( 'South Georgia and the South Sandwich Islands', 'flexify-dashboard' ),
				'SS' => esc_html( 'South Sudan', 'flexify-dashboard' ),
				'ES' => esc_html( 'Spain', 'flexify-dashboard' ),
				'LK' => esc_html( 'Sri Lanka', 'flexify-dashboard' ),
				'SD' => esc_html( 'Sudan', 'flexify-dashboard' ),
				'SR' => esc_html( 'Suriname', 'flexify-dashboard' ),
				'SJ' => esc_html( 'Svalbard and Jan Mayen', 'flexify-dashboard' ),
				'SE' => esc_html( 'Sweden', 'flexify-dashboard' ),
				'CH' => esc_html( 'Switzerland', 'flexify-dashboard' ),
				'SY' => esc_html( 'Syrian Arab Republic', 'flexify-dashboard' ),
				'TW' => esc_html( 'Taiwan', 'flexify-dashboard' ),
				'TJ' => esc_html( 'Tajikistan', 'flexify-dashboard' ),
				'TZ' => esc_html( 'Tanzania, United Republic of Tanganyika', 'flexify-dashboard' ),
				'TH' => esc_html( 'Thailand', 'flexify-dashboard' ),
				'TL' => esc_html( 'Timor-Leste', 'flexify-dashboard' ),
				'TG' => esc_html( 'Togo', 'flexify-dashboard' ),
				'TK' => esc_html( 'Tokelau', 'flexify-dashboard' ),
				'TO' => esc_html( 'Tonga', 'flexify-dashboard' ),
				'TT' => esc_html( 'Trinidad and Tobago', 'flexify-dashboard' ),
				'TN' => esc_html( 'Tunisia', 'flexify-dashboard' ),
				'TR' => esc_html( 'Turkey', 'flexify-dashboard' ),
				'TM' => esc_html( 'Turkmenistan', 'flexify-dashboard' ),
				'TC' => esc_html( 'Turks and Caicos Islands', 'flexify-dashboard' ),
				'TV' => esc_html( 'Tuvalu', 'flexify-dashboard' ),
				'UG' => esc_html( 'Uganda', 'flexify-dashboard' ),
				'UA' => esc_html( 'Ukraine', 'flexify-dashboard' ),
				'AE' => esc_html( 'United Arab Emirates', 'flexify-dashboard' ),
				'GB' => esc_html( 'United Kingdom of Great Britain and Northern Ireland', 'flexify-dashboard' ),
				'UM' => esc_html( 'United States Minor Outlying Islands', 'flexify-dashboard' ),
				'US' => esc_html( 'United States of America', 'flexify-dashboard' ),
				'UY' => esc_html( 'Uruguay', 'flexify-dashboard' ),
				'UZ' => esc_html( 'Uzbekistan', 'flexify-dashboard' ),
				'VU' => esc_html( 'Vanuatu', 'flexify-dashboard' ),
				'VE' => esc_html( 'Venezuela', 'flexify-dashboard' ),
				'VN' => esc_html( 'Viet Nam', 'flexify-dashboard' ),
				'VG' => esc_html( 'Virgin Islands (British)', 'flexify-dashboard' ),
				'VI' => esc_html( 'Virgin Islands (U.S.)', 'flexify-dashboard' ),
				'WF' => esc_html( 'Wallis and Futuna', 'flexify-dashboard' ),
				'EH' => esc_html( 'Western Sahara', 'flexify-dashboard' ),
				'YE' => esc_html( 'Yemen', 'flexify-dashboard' ),
				'ZM' => esc_html( 'Zambia', 'flexify-dashboard' ),
				'ZW' => esc_html( 'Zimbabwe', 'flexify-dashboard' ),
				'AX' => esc_html( 'Åland Islands', 'flexify-dashboard' ),
			);
		}

	}
}
