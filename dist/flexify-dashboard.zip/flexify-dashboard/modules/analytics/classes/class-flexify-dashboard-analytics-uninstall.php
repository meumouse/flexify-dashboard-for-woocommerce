<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;


class Flexify_Dashboard_Analytics_Uninstall {

	public static function uninstall() {
		global $wpdb;
		$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
		if ( null === $flexify_dashboard_analytics->gapi_controller ) {
			$flexify_dashboard_analytics->gapi_controller = new Flexify_Dashboard_Analytics_GAPI_Controller();
		}
		try {
			$flexify_dashboard_analytics->gapi_controller->reset_token( true, true );
		} catch ( Exception $e ) {
		}
		if ( is_multisite() ) { // Cleanup Network install
			foreach ( Flexify_Dashboard_Analytics_Tools::get_sites( array( 'number' => apply_filters( 'flexify_dashboard_analytics_sites_limit', 100 ) ) ) as $blog ) {
				switch_to_blog( $blog['blog_id'] );
				$sqlquery = $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '%%flexify_dashboard_analytics_cache_%%'" );
				delete_option( 'flexify_dashboard_analytics_options' );
				restore_current_blog();
			}
			delete_site_option( 'flexify_dashboard_analytics_network_options' );
		} else { // Cleanup Single install
			$sqlquery = $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '%%flexify_dashboard_analytics_cache_%%'" );
			delete_option( 'flexify_dashboard_analytics_options' );
		}
		Flexify_Dashboard_Analytics_Tools::unset_cookie( 'default_metric' );
		Flexify_Dashboard_Analytics_Tools::unset_cookie( 'default_dimension' );
		Flexify_Dashboard_Analytics_Tools::unset_cookie( 'default_view' );
		Flexify_Dashboard_Analytics_Tools::unset_cookie( 'default_swmetric' );

		$timestamp = wp_next_scheduled( 'flexify_dashboard_analytics_expired_cache_hook' );
		wp_unschedule_event( $timestamp, 'flexify_dashboard_analytics_expired_cache_hook' );

	}
}
