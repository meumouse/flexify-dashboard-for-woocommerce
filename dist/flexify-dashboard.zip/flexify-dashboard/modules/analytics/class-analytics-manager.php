<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Manager' ) ) {

	final class Flexify_Dashboard_Analytics_Manager {

		private static $instance = null;
		public $config = null;
		public $frontend_actions = null;
		public $common_actions = null;
		public $backend_actions = null;
		public $tracking = null;
		public $frontend_item_reports = null;
		public $backend_setup = null;
		public $frontend_setup = null;
		public $backend_widgets = null;
		public $backend_item_reports = null;
		public $gapi_controller = null;

		/**
		 * Construct forbidden
		 */
		private function __construct() {
			if ( null !== self::$instance ) {
				_doing_it_wrong( __FUNCTION__, __( "This is not allowed, read the documentation!", 'flexify-dashboard' ), '4.6' );
			}
		}

		/**
		 * Clone warning
		 */
		private function __clone() {
			_doing_it_wrong( __FUNCTION__, __( "This is not allowed, read the documentation!", 'flexify-dashboard' ), '4.6' );
		}

		/**
		 * Wakeup warning
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, __( "This is not allowed, read the documentation!", 'flexify-dashboard' ), '4.6' );
		}

		/**
		 * Creates a single instance for Flexify_Dashboard_Analytics and makes sure only one instance is present in memory.
		 *
		 * @return Flexify_Dashboard_Analytics_Manager
		 */
		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
				self::$instance->setup();
				self::$instance->config = new Flexify_Dashboard_Analytics_Config();
			}
			return self::$instance;
		}

		/**
		 * Defines constants and loads required resources
		 */
		private function setup() {
			/*
			 * Load Tools class
			 */
			include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/classes/class-flexify-dashboard-analytics-tools.php' );
			/*
			 * Load Config class
			 */
			include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/classes/class-flexify-dashboard-analytics-config.php' );
			/*
			 * Load GAPI Controller class
			 */
			include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/classes/class-flexify-dashboard-analytics-gapi-controller.php' );

			/*
			 * Plugin Init
			 */
			add_action( 'init', array( self::$instance, 'load' ) );
			/*
			 * Include Install
			 */
			include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/classes/class-flexify-dashboard-analytics-install.php' );
			register_activation_hook( FLEXIFY_DASHBOARD_FILE, array( 'Flexify_Dashboard_Analytics_Install', 'install' ) );
			/*
			 * Include Uninstall
			 */
			include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/classes/class-flexify-dashboard-analytics-uninstall.php' );
			register_uninstall_hook( FLEXIFY_DASHBOARD_FILE, array( 'Flexify_Dashboard_Analytics_Uninstall', 'uninstall' ) );
		}


		/**
		 * Conditional load
		 */
		public function load() {
			if ( is_admin() ) {
				if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
					if ( Flexify_Dashboard_Analytics_Tools::check_roles( self::$instance->config->options['access_back'] ) ) {
						/*
						 * Load Backend ajax actions
						 */
						include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/admin/ajax-actions.php' );
						self::$instance->backend_actions = new Flexify_Dashboard_Analytics_Backend_Ajax();
					}

					/*
					 * Load Common ajax actions
					 */
					include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/common/ajax-actions.php' );
					self::$instance->common_actions = new Flexify_Dashboard_Analytics_Common_Ajax();
				} 	else if ( Flexify_Dashboard_Analytics_Tools::check_roles( self::$instance->config->options['access_back'] ) ) {
						/*
						* Load Backend Setup
						*/
						include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/admin/setup.php' );
						self::$instance->backend_setup = new Flexify_Dashboard_Analytics_Backend_Setup();
						
						if ( self::$instance->config->options['dashboard_widget'] ) {
							/*
							* Load Backend Widget
							*/
							include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/admin/widgets.php' );
							self::$instance->backend_widgets = new Flexify_Dashboard_Analytics_Backend_Widgets();
						}
					}
			} else {
				include_once ( FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/front/tracking.php' );
				self::$instance->tracking = new Flexify_Dashboard_Analytics_Tracking();
			}
		}
	}
}

/**
 * Returns a unique instance of Flexify_Dashboard_Analytics
 */
function Flexify_Dashboard_Analytics() {
	return Flexify_Dashboard_Analytics_Manager::instance();
}

/*
 * Start Flexify_Dashboard_Analytics
 */
Flexify_Dashboard_Analytics();