<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Frontend_Setup' ) ) {

	final class Flexify_Dashboard_Analytics_Frontend_Setup {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			// Styles & Scripts
			add_action( 'wp_enqueue_scripts', array( $this, 'load_styles_scripts' ) );
		}

		/**
		 * Styles & Scripts conditional loading
		 *
		 * @param
		 *            $hook
		 */
		public function load_styles_scripts() {
			if ( Flexify_Dashboard_Analytics_Tools::is_amp() ){
				return;
			}

			$lang = get_bloginfo( 'language' );
			$lang = explode( '-', $lang );
			$lang = $lang[0];
			/*
			 * Item reports Styles & Scripts
			 */
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_front'] ) && $this->flexify_dashboard_analytics->config->options['frontend_item_reports'] ) {
				wp_enqueue_style( 'flexify_dashboard_analytics-nprogress', Flexify_Dashboard_Analytics_URL . 'common/nprogress/nprogress' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.css', null, FLEXIFY_DASHBOARD_VERSION );
				wp_enqueue_style( 'flexify_dashboard_analytics-frontend-item-reports', Flexify_Dashboard_Analytics_URL . 'front/css/item-reports' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.css', null, FLEXIFY_DASHBOARD_VERSION );
				$country_codes = Flexify_Dashboard_Analytics_Tools::get_countrycodes();
				$country_codes = array_flip($country_codes);
				if ( 'None' !== $this->flexify_dashboard_analytics->config->options['ga_target_geomap'] && isset( $country_codes[$this->flexify_dashboard_analytics->config->options['ga_target_geomap']] ) ) {
					$region = sanitize_text_field($country_codes[$this->flexify_dashboard_analytics->config->options['ga_target_geomap']]);
				} else {
					$region = false;
				}
				wp_enqueue_style( "wp-jquery-ui-dialog" );
				wp_register_script( 'googlecharts', 'https://www.gstatic.com/charts/loader.js', array(), null );
				wp_enqueue_script( 'flexify_dashboard_analytics-nprogress', Flexify_Dashboard_Analytics_URL . 'common/nprogress/nprogress' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.js', array( 'jquery' ), FLEXIFY_DASHBOARD_VERSION );
				wp_enqueue_script( 'flexify_dashboard_analytics-frontend-item-reports', Flexify_Dashboard_Analytics_URL . 'common/js/analytics-request' . Flexify_Dashboard_Analytics_Tools::script_debug_suffix() . '.js', array( 'flexify_dashboard_analytics-nprogress', 'googlecharts', 'jquery', 'jquery-ui-dialog' ), FLEXIFY_DASHBOARD_VERSION, true );
				
			}
		}
	}
}
