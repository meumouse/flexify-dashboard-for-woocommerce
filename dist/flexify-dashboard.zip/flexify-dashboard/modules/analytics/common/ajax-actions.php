<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Common_Ajax' ) ) {

	final class Flexify_Dashboard_Analytics_Common_Ajax {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) || Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_front'] ) ) {
				add_action( 'wp_ajax_flexify_dashboard_analytics_set_error', array( $this, 'ajax_set_error' ) );
			}
		}

		/**
		 * Ajax handler for storing JavaScript Errors
		 *
		 * @return json|int
		 */
		public function ajax_set_error() {
			if ( ! isset( $_POST['flexify_dashboard_analytics_security_set_error'] ) || ! ( wp_verify_nonce( $_POST['flexify_dashboard_analytics_security_set_error'], 'flexify_dashboard_analytics_backend_item_reports' ) || wp_verify_nonce( $_POST['flexify_dashboard_analytics_security_set_error'], 'flexify_dashboard_analytics_frontend_item_reports' ) ) ) {
				wp_die( 640 );
			}

			$timeout = 24 * 60 * 60;

			Flexify_Dashboard_Analytics_Tools::set_error( $_POST['response'], $timeout, true );

			wp_die();
		}
	}
}
