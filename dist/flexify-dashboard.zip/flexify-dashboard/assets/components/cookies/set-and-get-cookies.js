/**
 * Get cookie from name
 * 
 * @since 1.5.0
 * @param {string} name | Cookie name
 * @returns 
 */
function get_cookie(name) {
    let cookie_array = document.cookie.split(";");

    for ( let i = 0; i < cookie_array.length; i++ ) {
        let cookiePair = cookie_array[i].split("=");

        if (name === cookiePair[0].trim()) {
            return decodeURIComponent(cookiePair[1]);
        }
    }

    return null;
}

/**
 * Set cookie name from save state on browser
 * 
 * @since 1.5.0
 * @param {string} name | Cookie name
 * @param {string} value | Cookie value
 * @param {string} days | Expire date cookie
 */
function set_cookie(name, value, days) {
    let expires = "";

    if (days) {
        let date = new Date();
        
        date.setTime( date.getTime() + (days * 24 * 60 * 60 * 1000) );
        expires = "; expires=" + date.toUTCString();
    }

    document.cookie = name + "=" + encodeURIComponent(value) + expires + "; path=/";
}