/**
 * Load data for dashboard widgets in AJAX
 * 
 * @since 1.5.0
 * @package MeuMouse.com
 */
jQuery(document).ready( function($) {
    /**
     * Load last orders from WooCommerce in AJAX
     * 
     * @since 1.5.0
     * @return void
     */
    function load_last_woocommerce_orders() {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_last_orders',
                nonce: fd_widgets_params.last_orders_nonce,
            },
            success: function(response) {
                if (response.success) {
                    display_orders(response.data);
                }
            },
            error: function(error) {
                console.error('Error fetching orders:', error);
            }
        });
    }

    /**
     * Display orders table
     * 
     * @since 1.5.0
     * @param {array} orders | Response orders
     */
    function display_orders(orders) {
        let orders_table = `<div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">${fd_widgets_params.origin_title}</th>
                    <th scope="col">${fd_widgets_params.order_id_title}</th>
                    <th scope="col">${fd_widgets_params.customer_title}</th>
                    <th scope="col">${fd_widgets_params.order_total_title}</th>
                </tr>
            </thead>
            <tbody>`;

        orders.forEach(order => {
            orders_table += `
                <tr>
                    <td>
                        <button class="btn btn-link" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="${order.origin_label}">
                            <i class="${order.origin_icon}"></i>
                        </button>
                    </td>
                    <td class="align-middle">
                        <a href="${order.order_edit_url}">${order.order_id}</a>
                    </td>
                    <td class="align-middle">
                        <p class="mb-0">${order.customer_name}</p>
                    </td>
                    <td class="align-middle">
                        <p class="mb-0">${fd_widgets_params.currency_symbol} ${order.order_total}</p>
                    </td>
                </tr>`;
        });

        orders_table += `
                    </tbody>
                </table>
            </div>`;

        $('#orders-widget-container').html(orders_table);

        // Initialize Bootstrap tooltips again
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    }

    // Load orders on page load
    load_last_woocommerce_orders();
});


/**
 * Display billing charts with period filter
 * 
 * @since 1.5.0
 * @package MeuMouse.com
 */
jQuery(document).ready( function($) {
    var chart;

    /**
     * Load billing data on AJAX call
     * 
     * @since 1.5.0
     * @param {int} period | Period for filter
     */
    function load_billing_data(period) {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_billing_data',
                nonce: fd_widgets_params.billing_nonce,
                period: period,
            },
            success: function(response) {
                if (response.success) {
                    if (!chart) {
                        render_billing_chart(response.data);
                    } else {
                        update_billing_chart(response.data);
                    }
                    $('#flexify_dashboard_billing_store_chart').children('.placeholder-content').remove();
                    $('#flexify_dashboard_billing_store_chart').children('.apexcharts-canvas').removeClass('placeholder-content');
                }
            },
            error: function(error) {
                console.error('Error fetching billing data:', error);
            }
        });
    }

    /**
     * Render Apexchart with billing data
     * 
     * @since 1.5.0
     * @param {array} data | Response data
     */
    function render_billing_chart(data) {
        var options = {
            chart: {
                type: 'line',
            },
            stroke: {
                curve: 'smooth',
            },
            series: data.series,
            xaxis: {
                categories: data.labels
            },
            yaxis: {
                labels: {
                    formatter: function(value) {
                        // Format the value as currency with comma as decimal separator
                        return fd_widgets_params.currency_symbol + parseFloat(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                    }
                }
            }
        };

        chart = new ApexCharts(document.getElementById('flexify_dashboard_billing_store_chart'), options);
        chart.render();
    }

    /**
     * Update Apexchart with new billing data
     * 
     * @since 1.5.0
     * @param {array} data | Response data
     */
    function update_billing_chart(data) {
        chart.updateSeries(data.series);
        chart.updateOptions({
            xaxis: {
                categories: data.labels
            }
        });
    }

    // Load billing data on page load with default or cookie period
    var saved_period = get_cookie('billing_period') || 12;
    var saved_period_title = get_cookie('billing_period_title') || $('#flexify_dashboard_set_billing_period option:selected').text();

    $('#flexify_dashboard_set_billing_period').val(saved_period);
    $('.billing-period-title').text(saved_period_title);
    load_billing_data(saved_period);

    // Load billing data when period changes
    $('#flexify_dashboard_set_billing_period').on('change', function() {
        var period = $(this).val();
        var period_title = $('#flexify_dashboard_set_billing_period option:selected').text();
        
        // Save the selected period in cookies
        set_cookie('billing_period', period, 7);
        set_cookie('billing_period_title', period_title, 7);

        $('.billing-period-title').text(period_title);
        $('#flexify_dashboard_billing_store_chart').children('.apexcharts-canvas').addClass('placeholder-content');
        load_billing_data(period);
    });

     /**
     * Load average ticket data on AJAX call
     * 
     * @since 1.5.0
     * @param {int} period | Period for filter
     */
    function load_average_ticket_data(period) {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_average_ticket',
                nonce: fd_widgets_params.average_tickets_nonce,
                period: period,
            },
            success: function(response) {
                if (response.success) {
                    $('#average-ticket-amount').html(response.data.average_ticket);
                }
            },
            error: function(error) {
                console.error('Error fetching average ticket data:', error);
            }
        });
    }

    // Load average ticket data on page load with default or cookie period
    var saved_period = get_cookie('average_ticket_period') || 12;
    var saved_ticket_value = get_cookie('average_ticket_value') || '<div class="placeholder-content" style="height: 50px; width: 100px"></div>';

    $('#flexify_dashboard_set_average_ticket_period').val(saved_period);
    $('#average-ticket-amount').html(saved_ticket_value);

    load_average_ticket_data(saved_period);

    // Load average ticket data when period changes
    $('#flexify_dashboard_set_average_ticket_period').on('change', function() {
        var period = $(this).val();

        $('#average-ticket-amount').html('<div class="placeholder-content" style="height: 50px; width: 100px"></div>');

        // Save the selected period in cookies
        set_cookie('average_ticket_period', period, 7);
        load_average_ticket_data(period);
    });


    /**
     * Load total users data on AJAX call
     * 
     * @since 1.5.0
     */
    function load_total_users_data() {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_total_users',
                nonce: fd_widgets_params.total_users,
            },
            success: function(response) {
                if (response.success) {
                    $('#flexify_dashboard_get_total_users').html(response.data.total_users);
                }
            },
            error: function(error) {
                console.error('Error fetching total users data:', error);
            }
        });
    }

    // Load total users data on page load
    load_total_users_data();

    /**
     * Load total products data on AJAX call
     * 
     * @since 1.5.0
     */
    function load_total_products_data() {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_total_products',
                nonce: fd_widgets_params.total_products,
            },
            success: function(response) {
                if (response.success) {
                    $('#flexify_dashboard_get_total_products').html(response.data.total_products);
                }
            },
            error: function(error) {
                console.error('Error fetching total products data:', error);
            }
        });
    }

    // Load total products data on page load
    load_total_products_data();

    /**
     * Load total WooCommerce orders data on AJAX call
     * 
     * @since 1.5.0
     */
    function load_total_orders_data() {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_total_orders',
                nonce: fd_widgets_params.total_orders,
            },
            success: function(response) {
                if (response.success) {
                    $('#flexify_dashboard_get_total_orders').html(response.data.total_orders);
                }
            },
            error: function(error) {
                console.error('Error fetching total orders data:', error);
            }
        });
    }

    // Load total orders data on page load
    load_total_orders_data();

    /**
     * Load best-selling products data on AJAX call
     * 
     * @since 1.5.0
     */
    function load_best_selling_products() {
        $.ajax({
            url: fd_widgets_params.ajax_url,
            method: 'POST',
            data: {
                action: 'get_best_selling_products',
                nonce: fd_widgets_params.best_selling_products,
            },
            success: function(response) {
                if (response.success) {
                    $('#best-selling-products-widget').html(response.data);
                } else {
                    $('#best-selling-products-widget').html('<p>' + response.data + '</p>');
                }
            },
            error: function(error) {
                console.error('Error fetching best-selling products:', error);
            }
        });
    }

    // Load best-selling products data on page load
    load_best_selling_products();
});
