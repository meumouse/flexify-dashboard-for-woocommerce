/**
 * Navbar search in AJAX
 * 
 * @since 1.0.0
 * @version 1.5.0
 */
jQuery(document).ready( function($) {
    var timeout;
    var spinner = false;

    $('#flexify_dashboard_search').on('input', function() {
        clearTimeout(timeout);
        
        var search_term = $(this).val();

        if (search_term.length >= 3) {
            if ( spinner === false ) {
                $('#flexify_dashboard_search').after('<span class="search-ajax-products spinner-border"></span>');
                spinner = true;
            }

            timeout = setTimeout( function() {
                get_search_results(search_term);
            }, 500);
        } else {
            $('#flexify-dashboard-search-results').empty();
            $('.search-ajax-products').remove();
            spinner = false;
        }
    });

    /**
     * Get search in AJAX
     * 
     * @since 1.0.0
     * @version 1.5.0
     * @param {string} search_term | Search query
     */
    function get_search_results(search_term) {
        $.ajax({
            url: fd_search_params.ajax_url,
            type: 'POST',
            data: {
                action: 'flexify_dashboard_search',
                search_term: search_term,
            },
            success: function(response) {
                $('#flexify-dashboard-search-results').html(response);
                $('.search-ajax-products').remove();
                spinner = false;
            }
        });
    }
});