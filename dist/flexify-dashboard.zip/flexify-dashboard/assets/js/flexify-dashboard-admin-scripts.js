( function($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let get_tab_index = localStorage.getItem('flexify_dashboard_tab_index');

		if (get_tab_index === null) {
			// If it is null, activate the general tab
			$('.flexify-dashboard-wrapper a.nav-tab[href="#general"]').click();
		} else {
			$('.flexify-dashboard-wrapper a.nav-tab').eq(get_tab_index).click();
		}
	});
	  
	$(document).on('click', '.flexify-dashboard-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tab_index = $(this).index();
		localStorage.setItem('flexify_dashboard_tab_index', tab_index);
		
		let attrHref = $(this).attr('href');
		
		$('.flexify-dashboard-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.flexify-dashboard-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.flexify-dashboard-form').find(attrHref).addClass('active');
		
		return false;
	});


	/**
	 * Send options to backend in AJAX
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 * @package MeuMouse.com
	 */
	jQuery(document).ready( function($) {
		let settings_form = $('form[name="flexify-dashboard"]');
		let original_values = settings_form.serialize();
		var notification_delay;
		var debounce_timeout;

		/**
		 * Save options in AJAX
		 * 
		 * @since 1.0.0
		 * @version 1.5.0
		 */
		function ajax_save_options() {
			$.ajax({
				url: flexify_dashboard_admin_params.ajax_url,
				type: 'POST',
				data: {
					action: 'flexify_dashboard_ajax_save_options',
					form_data: settings_form.serialize(),
				},
				success: function(response) {
					try {
						if ( response.status === 'success' ) {
							original_values = settings_form.serialize();
							
							$('.flexify-dashboard-wrapper').before(`<div class="toast toast-save-options toast-success show">
								<div class="toast-header bg-success text-white">
									<svg class="icon icon-white me-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#ffffff"><g stroke-width="0"/><g stroke-linecap="round" stroke-linejoin="round"/><g><path d="M10.5 15.25C10.307 15.2353 10.1276 15.1455 9.99998 15L6.99998 12C6.93314 11.8601 6.91133 11.7029 6.93756 11.55C6.96379 11.3971 7.03676 11.2562 7.14643 11.1465C7.2561 11.0368 7.39707 10.9638 7.54993 10.9376C7.70279 10.9114 7.86003 10.9332 7.99998 11L10.47 13.47L19 5.00004C19.1399 4.9332 19.2972 4.91139 19.45 4.93762C19.6029 4.96385 19.7439 5.03682 19.8535 5.14649C19.9632 5.25616 20.0362 5.39713 20.0624 5.54999C20.0886 5.70286 20.0668 5.86009 20 6.00004L11 15C10.8724 15.1455 10.6929 15.2353 10.5 15.25Z" fill="#ffffff"/><path d="M12 21C10.3915 20.9974 8.813 20.5638 7.42891 19.7443C6.04481 18.9247 4.90566 17.7492 4.12999 16.34C3.54037 15.29 3.17596 14.1287 3.05999 12.93C2.87697 11.1721 3.2156 9.39921 4.03363 7.83249C4.85167 6.26578 6.1129 4.9746 7.65999 4.12003C8.71001 3.53041 9.87134 3.166 11.07 3.05003C12.2641 2.92157 13.4719 3.03725 14.62 3.39003C14.7224 3.4105 14.8195 3.45215 14.9049 3.51232C14.9903 3.57248 15.0622 3.64983 15.116 3.73941C15.1698 3.82898 15.2043 3.92881 15.2173 4.03249C15.2302 4.13616 15.2214 4.2414 15.1913 4.34146C15.1612 4.44152 15.1105 4.53419 15.0425 4.61352C14.9745 4.69286 14.8907 4.75712 14.7965 4.80217C14.7022 4.84723 14.5995 4.87209 14.4951 4.87516C14.3907 4.87824 14.2867 4.85946 14.19 4.82003C13.2186 4.52795 12.1987 4.43275 11.19 4.54003C10.193 4.64212 9.22694 4.94485 8.34999 5.43003C7.50512 5.89613 6.75813 6.52088 6.14999 7.27003C5.52385 8.03319 5.05628 8.91361 4.77467 9.85974C4.49307 10.8059 4.40308 11.7987 4.50999 12.78C4.61208 13.777 4.91482 14.7431 5.39999 15.62C5.86609 16.4649 6.49084 17.2119 7.23999 17.82C8.00315 18.4462 8.88357 18.9137 9.8297 19.1953C10.7758 19.4769 11.7686 19.5669 12.75 19.46C13.747 19.3579 14.713 19.0552 15.59 18.57C16.4349 18.1039 17.1818 17.4792 17.79 16.73C18.4161 15.9669 18.8837 15.0864 19.1653 14.1403C19.4469 13.1942 19.5369 12.2014 19.43 11.22C19.4201 11.1169 19.4307 11.0129 19.461 10.9139C19.4914 10.8149 19.5409 10.7228 19.6069 10.643C19.6728 10.5631 19.7538 10.497 19.8453 10.4485C19.9368 10.3999 20.0369 10.3699 20.14 10.36C20.2431 10.3502 20.3471 10.3607 20.4461 10.3911C20.5451 10.4214 20.6372 10.471 20.717 10.5369C20.7969 10.6028 20.863 10.6839 20.9115 10.7753C20.9601 10.8668 20.9901 10.9669 21 11.07C21.1821 12.829 20.842 14.6026 20.0221 16.1695C19.2022 17.7363 17.9389 19.0269 16.39 19.88C15.3288 20.4938 14.1495 20.8755 12.93 21C12.62 21 12.3 21 12 21Z" fill="#ffffff"/></g></svg>
									<span class="me-auto">${response.toast_header_title}</span>
									<button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
								</div>
								<div class="toast-body">${response.toast_body_title}</div>
							</div>`);
	
							// clear notification time on var
							if (notification_delay) {
								clearTimeout(notification_delay);
							}
	
							// set notification 3 seconds on var
							notification_delay = setTimeout( function() {
								$('.toast-save-options').fadeOut('fast', function() {
									$('.toast-save-options').remove();
								});
							}, 3000);
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}

		/**
		 * Monitor changes in the form
		 * 
		 * @since 1.5.0
		 */
		settings_form.on('change input', 'input, select, textarea', function() {
			if (settings_form.serialize() !== original_values) {
				if (debounce_timeout) {
					clearTimeout(debounce_timeout);
				}
	
				debounce_timeout = setTimeout(ajax_save_options, 500); // debounce delay of 500ms
			}
		});
	});


    /**
	 * Display loader and hide span on click
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.button-loading').on('click', function() {
			let btn = $(this);
			let btn_html = btn.html();
			let btn_width = btn.width();
			let btn_height = btn.height();

			// keep original width and height
			btn.width(btn_width);
			btn.height(btn_height);

			// Add spinner inside button
			btn.html('<span class="spinner-border spinner-border-sm"></span>');
		});

		// Prevent keypress enter
		$('.form-control').keypress( function(event) {
			if (event.keyCode === 13) {
				event.preventDefault();
			}
		});
	});


	/**
	 * Change container visibility
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 */
	jQuery(document).ready( function() {
		visibility_controller('#enable_ga_integration', '.ga-required');
		visibility_controller('#enable_recaptcha_admin_login', '.recaptcha-required');
		visibility_controller('#enable_last_orders_widget', '.require-last-orders-widget');
		visibility_controller('#enable_custom_heartbeat_control', '.require-enabled-heartbeat-control');
		visibility_controller('#enable_widget_best_selling_products', '.require-best-selling-widget');
	});


	/**
	 * Open WordPress midia library popup on click
	 * 
	 * @since 1.0.0
	 * @version 1.2.5
	 */
	jQuery(document).ready( function($) {
		var file_frame;
	
		/**
		 * Handler WordPress media upload
		 * 
		 * @since 1.2.5
		 * @param {string} title 
		 * @param {string} input 
		 * @returns object
		 */
		function open_media_uploader(title, input) {
			// If the media frame already exists, reopen it
			if (file_frame) {
				file_frame.open();
				return;
			}
	
			// Create media frame
			file_frame = wp.media.frames.file_frame = wp.media({
				title: title,
				button: {
					text: flexify_dashboard_admin_params.use_this_image,
				},
				multiple: false
			});
	
			// When an image is selected, execute the callback function
			file_frame.on('select', function() {
				var attachment = file_frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.url;
	
				// Update the input value with the URL of the selected image
				$('input[name="' + input + '"]').val(imageUrl).trigger('change'); // Force change
			});
	
			file_frame.open();
		}
	
		$('#flexify_dashboard_logo_sidebar').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.sidebar_logo_title, 'dashboard_logo');
		});
	
		$('#flexify_dashboard_admin_login_image').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.admin_login_title, 'admin_login_image');
		});

		$('#search_admin_login_logo').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.admin_login_logo_title, 'admin_login_logo');
		});
	});
	

	/**
	 * Check visibility toast
	 * 
	 * @since 1.0.0
	 * @version 1.5.0
	 */
	jQuery(document).ready( function($) {
		$(document).on('click', '.hide-toast', function() {
			$('.updated-option-success, .update-notice-flexify-checkout, .toast').fadeOut('fast');
		});

		setTimeout( function() {
			$('.update-notice-flexify-checkout').fadeOut('fast');
		}, 3000);
	});
	

	/**
	 * Process upload alternative license
	 * 
	 * @since 1.3.0
	 */
	jQuery(document).ready( function($) {
		// Add event handlers for dragover and dragleave
		$('#license_key_zone').on('dragover dragleave', function(e) {
			e.preventDefault();
			
			$(this).toggleClass('drag-over', e.type === 'dragover');
		});
	
		// Add event handlers for drop
		$('#license_key_zone').on('drop', function(e) {
			e.preventDefault();
			var file = e.originalEvent.dataTransfer.files[0];

			if ( ! $(this).hasClass('file-uploaded') ) {
				handle_file(file, $(this));
			}
		});
	
		// Adds a change event handler to the input file
		$('#upload_license_key').on('change', function(e) {
			var file = e.target.files[0];
			var fileName = file.name;
			console.log('Nome do arquivo:', fileName);

			handle_file(file, $(this).parents('.dropzone-license'));
		});
	
		/**
		 * Handle sent file
		 * 
		 * @since 1.3.0
		 * @param {string} file | File
		 * @param {string} dropzone | Dropzone div
		 * @returns void
		 */
		function handle_file(file, dropzone) {
			if (file) {
				var filename = file.name;
				var hook_toast = $('.flexify-dashboard-wrapper');
				var formData = new FormData();

				formData.append('action', 'fd_alternative_activation_license');
				formData.append('file', file);

				dropzone.children('.file-list').removeClass('d-none').text(filename);
				dropzone.addClass('file-processing');
				dropzone.append('<div class="spinner-border"></div>');
				dropzone.children('.drag-text').addClass('d-none');
				dropzone.children('.drag-and-drop-file').addClass('d-none');
				dropzone.children('.upload-license-key').addClass('d-none');
	
				$.ajax({
					url: flexify_dashboard_admin_params.ajax_url,
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(response) {
						try {
							if (response.status === 'success') {
								dropzone.addClass('file-uploaded').removeClass('file-processing');
								dropzone.children('.spinner-border').remove();
								dropzone.append('<div class="upload-notice d-flex flex-collumn align-items-center"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="#22c55e" d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z"></path><path fill="#22c55e" d="M9.999 13.587 7.7 11.292l-1.412 1.416 3.713 3.705 6.706-6.706-1.414-1.414z"></path></svg><span>'+ response.message +'</span></div>');
								dropzone.children('.file-list').addClass('d-none');

								setTimeout( function() {
									location.reload();
								}, 1000);
							} else {
								hook_toast.before(`<div id="toast_danger_alternative_license" class="toast toast-danger show">
									<div class="toast-header bg-danger text-white">
										<i class="bx bx-check-circle fs-lg me-2"></i>
										<span class="me-auto">${flexify_dashboard_admin_params.toast_error}</span>
										<button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
									</div>
									<div class="toast-body">${response.message}</div>
								</div>`);

								setTimeout( function() {
									$('#toast_danger_alternative_license').fadeOut('fast');
								}, 3000);

								setTimeout( function() {
									$('#toast_danger_alternative_license').remove();
								}, 3500);

								dropzone.addClass('invalid-file').removeClass('file-processing');
								dropzone.children('.spinner-border').remove();
								dropzone.children('.drag-text').removeClass('d-none');
								dropzone.children('.drag-and-drop-file').removeClass('d-none');
								dropzone.children('.upload-license-key').removeClass('d-none');
								dropzone.children('.file-list').addClass('d-none');
							}
						} catch (error) {
							console.log(error);
						}
					},
					error: function(xhr, status, error) {
						dropzone.addClass('fail-upload').removeClass('file-processing');
						console.log('Erro ao enviar o arquivo');
						console.log(xhr.responseText);
					}
				});
			}
		}
	});


	/**
	 * Helper color selector
	 * 
	 * @since 1.3.0
	 */
	jQuery(document).ready( function($) {
		$('.get-color-selected').on('input', function() {
			var color_value = $(this).val();
	
			$(this).closest('.color-container').find('.form-control-color').val(color_value);
		});
	
		$('.form-control-color').on('input', function() {
			var color_value = $(this).val();
	
			$(this).closest('.color-container').find('.get-color-selected').val(color_value);
		});

		$('.reset-color').on('click', function(e) {
			e.preventDefault();
			var color_value = $(this).data('color');

			$(this).closest('.color-container').find('.form-control-color').val(color_value);
			$(this).closest('.color-container').find('.get-color-selected').val(color_value).change();
		});
	});
})(jQuery);