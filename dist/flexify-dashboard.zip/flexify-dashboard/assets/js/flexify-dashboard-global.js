/**
 * Display screen options on navbar
 * 
 * @since 1.0.0
 * @version 1.5.0
 */
jQuery(document).ready( function($) {
    /**
     * Check if current screen has widgets
     * 
     * @since 1.5.0
     */
    function current_screen_widgets() {
        var message = `<span class="d-flex align-items-center p-3 fs-6 text-muted" id="no-widgets-message"><i class="bx bx-info-circle me-2 fs-lg"></i>${fd_global_params.empty_widgets}</span>`;

        if ($('#adv-settings .metabox-prefs').length < 1 && $('#no-widgets-message').length === 0) {
            $('#flexify-dashboard-screen-widgets').find('#adv-settings').after(message);
        }
    }

    // call function on load page
    current_screen_widgets();

    const trigger = $('#flexify-dashboard-screen-widgets > .screen-options');
    const container = $('#flexify-dashboard-screen-widgets > .screen-options-container');

    // display modal for screen widgets
    trigger.on('click', function(e) {
        e.preventDefault();
        container.toggleClass('show');
        e.stopPropagation();

        current_screen_widgets();
    });

    // hide modal if click out
    $(document).on('click', function(e) {
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            container.removeClass('show');
        }
    });

    $(document).on('click', '#reorder-widgets', function() {
        $('.postbox-header').toggleClass('d-flex');
        $('.postbox-header').toggleClass('active');
        $('.empty-container').toggleClass('reorder');
    });
});


/**
 * Display sidebar on mobile
 * 
 * @since 1.2.0
 * @version 1.3.0
 */
jQuery(document).ready( function($) {
    $(document).on('click', '#display-sidebar', function(e) {
        e.preventDefault();
        
        $('#adminmenuwrap').addClass('active');
        $('#adminmenu').addClass('active');
    });
    
    $(document).on('click', '#close_sidebar', function(e) {
        e.preventDefault();
        
        $('#adminmenuwrap').removeClass('active');
        $('#adminmenu').removeClass('active');
    });
});

/**
 * Change visibility from navbar and save state on Cookie browser
 * 
 * @since 1.5.0
 * @package MeuMouse.com
 */
jQuery(document).ready( function($) {
    // Restore class state on page load
    if ( get_cookie('navbar-collapsed') === 'true' ) {
        $('#flexify-dashboard-navbar').addClass('navbar-collapsed');
        $('.navbar-collapse-menu').addClass('show');
    }

    // Toggle classes and save state to cookies on click
    $(document).on('click', '.navbar-collapse', function(e) {
        e.preventDefault();
        
        $('#flexify-dashboard-navbar').toggleClass('navbar-collapsed');
        $('.navbar-collapse-menu').toggleClass('show');
        
        // Save class state in cookies
        set_cookie('navbar-collapsed', $('#flexify-dashboard-navbar').hasClass('navbar-collapsed'), 7);
        set_cookie('navbar-collapse-menu', $('.navbar-collapse-menu').hasClass('show'), 7);
    });
});

/**
 * Init Bootstrap tooltips
 * 
 * @since 1.5.0
 */
jQuery(document).ready( function($) {
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
});

/**
 * Prevent reload page for Bootstrap modals
 * 
 * @since 1.5.0
 */
jQuery(document).ready( function($) {
    $('button[data-bs-toggle="modal"]').on('click', function(e) {
        e.preventDefault();
    });
});