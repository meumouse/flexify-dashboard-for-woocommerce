<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Get monthly revenue data from WooCommece
 * 
 * @since 1.0.0
 * @return array
 */
function get_monthly_revenue_data() {
    // Try to get the cached data
    $cached_data = get_transient('monthly_revenue_data');

    // If data is not cached, query the database and cache it
    if ( $cached_data === false ) {
        // Gets all orders with complete and processing status
        $args = array(
            'post_type' => 'shop_order',
            'post_status' => array('wc-completed', 'wc-processing'),
            'posts_per_page' => -1,
        );

        $orders = get_posts($args);

        // Stores monthly billing, number of completed and processing orders in an array
        $monthly_data = array();

        foreach ( $orders as $order ) {
            $order_id = $order->ID;
            $order_date = strtotime( $order->post_date );
            $order_month = date('m/Y', $order_date);
        
            // Fetch the order object
            $order_object = wc_get_order( $order_id );
        
            // Check if the order object is valid
            if ( $order_object ) {
                $order_total = $order_object->get_total();
                $order_discounts = $order_object->get_total_discount();
        
                // Initializes the month key to zero if it does not already exist
                if ( !isset( $monthly_data[$order_month] ) ) {
                    $monthly_data[$order_month] = array(
                        'revenue_gross' => 0,
                        'revenue_net' => 0,
                        'order_count_completed' => 0,
                        'order_count_processing' => 0,
                    );
                }
        
                // Adds the total to the array corresponding to the month
                $monthly_data[$order_month]['revenue_gross'] += ($order_total + $order_discounts);
                $monthly_data[$order_month]['revenue_net'] += $order_total;
        
                // Counts the order as completed or in process
                if ($order->post_status === 'wc-completed') {
                    $monthly_data[$order_month]['order_count_completed'] += 1;
                } elseif ($order->post_status === 'wc-processing') {
                    $monthly_data[$order_month]['order_count_processing'] += 1;
                }
            }
        }

        // Fill the array with zeros for months with no data
        $last_12_months = array_map( function($i) {
            return date('m/Y', strtotime("-$i months"));
        }, range(0, 11));

        $monthly_data = array_merge( array_fill_keys( $last_12_months, array('revenue_gross' => 0, 'revenue_net' => 0, 'order_count_completed' => 0, 'order_count_processing' => 0 ) ), $monthly_data );

        // Sort the array according to the keys
        uksort( $monthly_data, function($a, $b) {
            $dateA = DateTime::createFromFormat('m/Y', $a);
            $dateB = DateTime::createFromFormat('m/Y', $b);

            return $dateA <=> $dateB;
        });

        // Calculate the average ticket
        foreach ( $monthly_data as &$data ) {
            if ($data['order_count_completed'] > 0) {
                $data['average_ticket'] = $data['revenue_gross'] / $data['order_count_completed'];
            } else {
                $data['average_ticket'] = 0;
            }
        }

        // Caches data for 1 day
        set_transient('monthly_revenue_data', $monthly_data, DAY_IN_SECONDS);
    } else {
        // If data is cached, use it directly
        $monthly_data = $cached_data;
    }

    return $monthly_data;
}