<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use MeuMouse\Flexify_Dashboard_Analytics\Google\Service\Exception as GoogleServiceException;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Init {

    public $responseObj;
    public $licenseMessage;
    public $showMessage = false;
    public $activateLicense = false;
    public $deactivateLicense = false;

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        // set default tabs options
        add_action( 'admin_init', array( $this, 'flexify_dashboard_set_default_options' ) );

        // init API class after plugins loaded
        add_action( 'admin_init', array( $this, 'flexify_dashboard_api_connection' ) );
    }


    /**
     * Set default options
     * 
     * @since 1.0.0
     * @return array
     */
    public function set_default_data_options() {
        $options = array(
            'enable_total_users_widget' => 'yes',
            'enable_products_registered_widget' => 'yes',
            'enable_average_ticket_widget' => 'yes',
            'enable_anual_billing_widget' => 'yes',
            'enable_technology_ga_widget' => 'yes',
            'enable_orders_number_widget' => 'yes',
            'enable_visitor_type_widget' => 'yes',
            'enable_apexcharts_toolbar' => 'no',
            'enable_admin_search_posts' => 'yes',
            'enable_dark_mode' => 'yes',
            'dashboard_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-light.png' ),
            'admin_login_image' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/flexify-dashboard-login.jpg' ),
            'primary_color' => '#008aff',
            'success_color' => '#22c55e',
            'warning_color' => '#ffba08',
            'danger_color' => '#ef4444',
            'info_color' => '#4c82f7',
            'enable_recaptcha_admin_login' => 'no',
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'enable_ga_integration' => 'no',
            'ga_client_id' => '',
            'ga_client_secret' => '',
            'ga_map_target_country' => 'BR',
            'ga_google_maps_api_key' => '',
            'enable_meta_pixel_integration' => 'no',
            'enable_admin_bar' => 'no',
            'enable_flexify_dashboard_login_page' => 'yes',
            'admin_login_logo' => esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/logo-single.png' ),
        );

        return $options;
    }


    /**
     * Gets the items from the array and inserts them into the option if it is empty,
     * or adds new items with default value to the option
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_set_default_options() {
        $get_options = $this->set_default_data_options();
        $default_options = get_option('flexify_dashboard_data_options', array());
        $default_options = maybe_unserialize($default_options);
    
        if ( empty( $default_options ) ) {
            $options = $get_options;
            update_option('flexify_dashboard_data_options', maybe_serialize($options));
        } else {
            $options = $default_options;
    
            foreach ( $get_options as $key => $value ) {
                if ( !isset( $options[$key] ) ) {
                    $options[$key] = $value;
                }
            }
    
            update_option('flexify_dashboard_data_options', maybe_serialize($options));
        }
    }


    /**
	 * Checks if the option exists and returns the indicated array item
	 * 
	 * @since 1.0.0
     * @param $key | Array key
     * @return mixed | string or false
	 */
    public static function get_setting( $key ) {
        $default_options = get_option('flexify_dashboard_data_options', array());
        $default_options = maybe_unserialize( $default_options );

        // check if array key exists and return key
        if ( isset( $default_options[$key] ) ) {
            return $default_options[$key];
        }

        return false;
    }


    /**
     * Load API settings
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_api_connection() {
        if ( current_user_can('manage_options') ) {
            $this->responseObj = new stdClass();
            $message = '';
            $license_key = get_option( 'flexify_dashboard_license_key', '' );
        
            // Save settings on active license
            if (  isset( $_POST['flexify_dashboard_active_license'] ) ) {
                delete_transient('flexify_dashboard_api_request_cache');
                delete_transient('flexify_dashboard_api_response_cache');
                
                update_option( 'flexify_dashboard_license_key', $_POST );
                $license_key = !empty( $_POST['flexify_dashboard_license_key'] ) ? $_POST['flexify_dashboard_license_key'] : '';
                update_option( 'flexify_dashboard_license_key', $license_key ) || add_option('flexify_dashboard_license_key', $license_key );
            }

            if ( ! self::license_valid() ) {
                update_option( 'flexify_dashboard_license_status', 'invalid' );
            }
        
            // Check on the server if the license is valid and update responses and options
            if ( Flexify_Dashboard_Api::CheckWPPlugin( $license_key, $this->licenseMessage, $this->responseObj, FLEXIFY_DASHBOARD_FILE ) ) {
                if ( $this->responseObj && $this->responseObj->is_valid ) {
                    update_option('flexify_dashboard_license_status', 'valid');
                } else {
                    update_option('flexify_dashboard_license_status', 'invalid');
                }

                if ( isset( $_POST['flexify_dashboard_active_license'] ) && self::license_valid() ) {
                    $this->activateLicense = true;
                }
            } else {
                if ( !empty( $license_key ) && !empty( $this->licenseMessage ) ) {
                    $this->showMessage = true;
                }
            }

            // Save settings on deactive license, or remove license status if it is invalid
            if ( isset( $_POST['flexify_dashboard_deactive_license'] ) ) {
                if ( Flexify_Dashboard_Api::RemoveLicenseKey( FLEXIFY_DASHBOARD_FILE, $message ) ) {
                    update_option('flexify_dashboard_license_status', 'invalid');
                    delete_option('flexify_dashboard_license_key');

                    $this->deactivateLicense = true;
                }
            }

            if ( isset( $_POST['flexify_dashboard_clear_activation_cache'] ) || ! self::license_valid() ) {
                delete_transient('flexify_dashboard_api_request_cache');
                delete_transient('flexify_dashboard_api_response_cache');
                delete_option('flexify_dashboard_license_response_object');
            }
        }
    }


    /**
     * Check if license is valid
     * 
     * @since 1.2.5
     * @return bool
     */
    public static function license_valid() {
        $object_query = get_option('flexify_dashboard_license_response_object');

        // clear api request and response cache if object is empty
        if ( empty( $object_query ) ) {
            delete_transient('flexify_dashboard_api_request_cache');
            delete_transient('flexify_dashboard_api_response_cache');
        }

        if ( ! empty( $object_query ) && isset( $object_query->is_valid )  ) {
            return true;
        } elseif ( empty( $object_query->status ) ) {
            delete_option('flexify_dashboard_license_response_object');
            
            return false;
        } else {
            update_option( 'flexify_dashboard_license_key', '' );

            return false;
        }
    }


    /**
     * Get license title
     * 
     * @since 1.2.5
     * @return string
     */
    public static function license_title() {
        $object_query = get_option('flexify_dashboard_license_response_object');

        if ( ! empty( $object_query ) && isset( $object_query->license_title ) ) {
            return $object_query->license_title;
        } else {
            return esc_html__(  'Não disponível', 'flexify-dashboard-for-woocommerce' );
        }
    }


    /**
     * Get license expire date
     * 
     * @since 1.2.5
     * @return string
     */
    public static function license_expire() {
        $object_query = get_option('flexify_dashboard_license_response_object');

        if ( ! empty( $object_query ) && isset( $object_query->expire_date ) ) {
            if ( $object_query->expire_date === 'No expiry' ) {
                return esc_html__( 'Nunca expira', 'flexify-dashboard-for-woocommerce' );
            } else {
                if ( strtotime( $object_query->expire_date ) < time() ) {
                    update_option( 'flexify_dashboard_license_status', 'invalid' );
                    delete_option('flexify_dashboard_license_response_object');

                    return esc_html__( 'Licença expirada', 'flexify-dashboard-for-woocommerce' );
                }

                // get wordpress date format setting
                $date_format = get_option('date_format');

                return date( $date_format, strtotime( $object_query->expire_date ) );
            }
        }
    }
}

new Flexify_Dashboard_Init();