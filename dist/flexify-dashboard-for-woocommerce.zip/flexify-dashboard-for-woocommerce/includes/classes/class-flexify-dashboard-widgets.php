<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Widgets {

    private $flexify_dashboard_analytics;

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        global $pagenow;

        $this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();

        if ( $pagenow === 'index.php' ) {
            if ( Flexify_Dashboard_Init::get_setting('enable_total_users_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_users_total_widget' ) );
            }

            if ( Flexify_Dashboard_Init::get_setting('enable_products_registered_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_products_total_widget' ) );
            }

            if ( Flexify_Dashboard_Init::get_setting('enable_average_ticket_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_average_ticket_widget' ) );
            }

            if ( Flexify_Dashboard_Init::get_setting('enable_anual_billing_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_billing_last_year_widget' ) );
            }

            if ( Flexify_Dashboard_Init::get_setting('enable_orders_number_widget') === 'yes' ) {
                add_action( 'wp_dashboard_setup', array( $this, 'add_woocommerce_orders_widget' ) );
            }

            if ( Flexify_Dashboard_Init::get_setting('enable_ga_integration') === 'yes' && $this->flexify_dashboard_analytics->config->options['token'] !== false ) {
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_analytics_sessions_widget' ) );
                add_action( 'wp_dashboard_setup', array( $this, 'flexify_dashboard_sessions_pageviews_stats' ) );
            }
        }
    }


    /**
     * Add users total widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_users_total_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_total_users_widget', // ID
            esc_html( 'Usuários totais', 'flexify-dashboard-for-woocommerce' ), // widget display name
            array( $this, 'render_users_total_widget' ), // render content
        );
    }


    /**
     * Render HTML content for total users widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_users_total_widget() {
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-user"></i>
            </div>
            <span class="fw-bold fs-4 mt-2 mb-1"><?php echo esc_html( count_users()['total_users'] ); ?></span>
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html( 'Usuários totais', 'flexify-dashboard-for-woocommerce' ); ?></span>
            </div>
        </div>
        <?php
    }


    /**
     * Add products total widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_products_total_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_total_products_widget', // ID
            esc_html( 'Produtos cadastrados', 'flexify-dashboard-for-woocommerce' ), // widget display name
            array( $this, 'render_products_total_widget' ), // render content
        );
    }


    /**
     * Render HTML content for total products widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_products_total_widget() {
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-purchase-tag"></i>
            </div>
            <span class="fw-bold fs-4 mt-2 mb-1"><?php echo esc_html( wp_count_posts('product')->publish ); ?></span>
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html( 'Produtos cadastrados', 'flexify-dashboard-for-woocommerce' ); ?></span>
            </div>
        </div>
        <?php
    }


    /**
     * Add average ticket widget to WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_average_ticket_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_average_ticket_widget', // ID
            esc_html( 'Ticket médio', 'flexify-dashboard-for-woocommerce' ), // widget display name
            array( $this, 'render_average_ticket_widget' ), // render content
        );
    }

    /**
     * Register orders total WooCommerce widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function add_woocommerce_orders_widget() {
        wp_add_dashboard_widget(
            'woocommerce_orders_widget', // ID
            esc_html__( 'Pedidos do WooCommerce', 'flexify-dashboard-for-woocommerce' ), // widget display name
            array( $this, 'render_woocommerce_orders_widget' ), // render content
        );
    }


    /**
     * Render orders total WooCommerce widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_woocommerce_orders_widget() {
        // Check if the transient exists
        $order_count = get_transient('flexify_dashboard_get_order_count');
    
        // If transient doesn't exist, make the database query
        if (false === $order_count) {
            global $wpdb;
            $total_order_count = $wpdb->get_var("
                SELECT COUNT(ID)
                FROM {$wpdb->prefix}posts
                WHERE post_type = 'shop_order'
                AND post_status IN ('wc-processing', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed', 'wc-on-hold')
            ");
    
            // Cache the result for 1 day
            set_transient('flexify_dashboard_get_order_count', $total_order_count, DAY_IN_SECONDS);
        } else {
            // Use the cached result
            $total_order_count = $order_count;
        }
    
        ?>
        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-cart"></i>
            </div>
            <span class="fw-bold fs-4 mt-2 mb-1"><?php echo esc_html( $total_order_count ); ?></span>
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html( 'Pedidos recebidos', 'flexify-dashboard-for-woocommerce' ); ?></span>
            </div>
        </div>
        <?php
    }    

    
    /**
     * Render content for average ticket widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_average_ticket_widget() {
        $get_data = get_monthly_revenue_data();
        $total_gross = 0;
        $total_orders = 0;

        foreach ( $get_data as $month_data ) {
            $total_gross += $month_data['revenue_gross'];
            $total_orders += $month_data['order_count_completed'];
        }

        // Calculate the overall average ticket
        $average_ticket = $total_orders > 0 ? $total_gross / $total_orders : 0; ?>

        <div class="d-grid">
            <div class="widget-icon">
                <i class="bx bx-cart"></i>
            </div>
            <span class="fw-bold fs-4 mt-2 mb-1"><?php echo wc_price( $average_ticket ); ?></span>
            <div class="d-flex justify-content-between">
                <span class="fs-6 text-body-secondary"><?php echo esc_html('Ticket médio', 'flexify-dashboard-for-woocommerce'); ?></span>
            </div>
        </div>
        <?php
    }


    /**
     * Add billing last year screen widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_billing_last_year_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_billing_last_year', // ID
            esc_html( 'Faturamento do último ano', 'flexify-dashboard-for-woocommerce' ), // label
            array( $this, 'render_billing_last_year' ), // render function
        );
    }
    

    /**
     * Render content for billing last year screen widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_billing_last_year() {
        // Get monthly billing data
        $monthly_revenue = get_monthly_revenue_data();
    
        // Extract the last 12 months
        $last_12_months = array_slice( array_keys( $monthly_revenue ), -12 );
    
        // Filter data only for the last 12 months - Gross and Net Revenue
        $filtered_chart_data = array(
            'labels' => array_values( $last_12_months ),
            'series' => array(
                array(
                    'name' => esc_html('Faturamento bruto do mês', 'flexify-dashboard-for-woocommerce'),
                    'data' => array_column( array_values( array_intersect_key( $monthly_revenue, array_flip( $last_12_months ) ) ), 'revenue_gross'),
                ),
                array(
                    'name' => esc_html('Faturamento líquido do mês', 'flexify-dashboard-for-woocommerce'),
                    'data' => array_column( array_values( array_intersect_key( $monthly_revenue, array_flip( $last_12_months ) ) ), 'revenue_net'),
                ),
            ),
        );
    
        // Sort the months in ascending order
        ksort( $filtered_chart_data['labels'] );
    
        // Locate the scripts with the required data
        wp_localize_script('apexcharts', 'chartData', array(
            'labels' => $filtered_chart_data['labels'],
            'series' => $filtered_chart_data['series'],
            'currencySymbol' => get_woocommerce_currency_symbol(),
        )); ?>
    
        <div class="billing-year-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html('Faturamento', 'flexify-dashboard-for-woocommerce'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo esc_html('Últimos 12 meses', 'flexify-dashboard-for-woocommerce'); ?></span>
        </div>
    
        <div id="billing-last-year-chart"></div>
    
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var options = {
                    chart: {
                        type: 'line',
                    },
                    stroke: {
                        curve: 'smooth',
                    },
                    series: chartData.series,
                    xaxis: {
                        categories: chartData.labels
                    },
                    yaxis: {
                        labels: {
                            formatter: function (value) {
                                // Format the value as currency with comma as decimal separator
                                return chartData.currencySymbol + parseFloat(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
                            }
                        }
                    }
                };
    
                var chart = new ApexCharts(document.getElementById('billing-last-year-chart'), options);
                chart.render();
            });
        </script>
        <?php
    }


    /**
     * Add Analytics sessions widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_analytics_sessions_widget() {
        wp_add_dashboard_widget(
            'flexify_dashboard_analytics_sessions',
            __( 'Sessões de usuários', 'flexify-dashboard-for-woocommerce' ),
            array( $this, 'render_flexify_dashboard_analytics_chart' ),
        );
    }


    /**
     * Render analytics sessions widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_flexify_dashboard_analytics_chart() {
        // get data from Analytics option
        $chart_data = get_option('flexify_dashboard_analytics_areachart', array());

        // Extract labels and data series from chart
        $labels = array();
        $series = array();

        foreach ($chart_data as $data) {
            if ($data[0] !== 'Data') {
                $labels[] = $data[0];
                $series[] = $data[1];
            }
        }

        // Build the chart data
        $chart_data = array(
            'labels' => $labels,
            'series' => array(
                array(
                    'name' => esc_html('Sessões', 'flexify-dashboard-for-woocommerce'),
                    'data' => $series,
                ),
            ),
        );

        // send data from JS variable
        wp_localize_script('apexcharts', 'flexifyAnalyticsChartData', $chart_data); ?>

        <div class="monthly-sessions-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html('Visitas ao site', 'flexify-dashboard-for-woocommerce'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo esc_html('Últimos 30 dias', 'flexify-dashboard-for-woocommerce'); ?></span>
        </div>
        <div id="flexify_dashboard_month_sessions"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var options = {
                    chart: {
                        type: 'bar',
                        height: 350,
                        stacked: false,
                        zoom: {
                            enabled: true
                        },
                        toolbar: {
                            show: true
                        }
                    },
                    dataLabels: {
                        enabled: false
                    },
                    stroke: {
                        curve: 'smooth'
                    },
                    series: flexifyAnalyticsChartData.series,
                    xaxis: {
                        categories: flexifyAnalyticsChartData.labels,
                        labels: {
                            show: false,
                        }
                    },
                    tooltip: {
                        x: {
                            format: 'dd/MM/yy'
                        },
                    }
                };

                var chart = new ApexCharts(document.getElementById('flexify_dashboard_month_sessions'), options);
                chart.render();
            });
        </script>
        <?php
    }


    /**
     * Register sessions and pageviews stats widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_sessions_pageviews_stats() {
        wp_add_dashboard_widget(
            'flexify_dashboard_bottom_stats_donut', // ID
            esc_html( 'Estatísticas de sessões', 'flexify-dashboard-for-woocommerce' ), // label
            array( $this, 'render_sessions_pageviews_stats' ) // render function
        );
    }
    

    /**
     * Render sessions and pageviews stats widget
     * 
     * @since 1.0.0
     * @return void
     */
    public function render_sessions_pageviews_stats() {
        // Get the option data
        $bottom_stats_data = get_option('flexify_dashboard_analytics_bottom_stats');

        // Extract the data for sessions and page views
        $sessions = $bottom_stats_data[0];
        $page_views = $bottom_stats_data[2];

        // Prepare translated labels for the chart
        $labels = array(
            esc_html('Sessões', 'flexify-dashboard-for-woocommerce'),
            esc_html('Page views', 'flexify-dashboard-for-woocommerce')
        ); ?>

        <div class="monthly-sessions-title mb-3">
            <span class="fs-5 fw-semibold"><?php echo esc_html('Sessões vs Page views', 'flexify-dashboard-for-woocommerce'); ?></span>
            <span class="fs-6 text-body-secondary mt-2 d-block"><?php echo esc_html('Últimos 30 dias', 'flexify-dashboard-for-woocommerce'); ?></span>
        </div>
        <div id="flexify_dashboard_session_vs_pageviews"></div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var options = {
                    series: [<?php echo $sessions; ?>, <?php echo $page_views; ?>],
                    chart: {
                        width: 380,
                        type: 'donut',
                    },
                    dataLabels: {
                        enabled: false
                    },
                    responsive: [{
                        breakpoint: 480,
                        options: {
                            chart: {
                                width: 200
                            },
                            legend: {
                                show: false
                            }
                        }
                    }],
                    legend: {
                        position: 'right',
                        offsetY: 0,
                        height: 230,
                    },
                    labels: <?php echo json_encode($labels); ?>
                };

                var chart = new ApexCharts(document.getElementById('flexify_dashboard_session_vs_pageviews'), options);
                chart.render();
            });
        </script>
        <?php
    }
    
}

new Flexify_Dashboard_Widgets();