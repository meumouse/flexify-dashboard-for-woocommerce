<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Load dependencies and scripts
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Assets {
    
    private $flexify_dashboard_analytics;

    /**
     * Construc function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'flexify_dashboard_dependencies' ) );
        add_action( 'admin_head', array( $this, 'flexify_dashboard_change_loader_icon' ) );
        add_action( 'login_enqueue_scripts', array( $this, 'flexify_dashboard_login_icons' ) );

        // show or hide apexcharts toolbox 
        if ( Flexify_Dashboard_Init::get_setting('enable_apexcharts_toolbar') !== 'yes' ) {
            add_action( 'admin_head', array( $this, 'show_apexcharts_toolbox' ) );
        }

        // scrollbar styles
        $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true );

        if ( isset( $theme_mode_state ) && $theme_mode_state === 'yes' ) {
            add_action( 'admin_head', array( $this, 'scrollbar_dark_styles' ) );
        }
    }


    /**
     * Enqueue dependencies
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_dependencies() {
        wp_enqueue_style( 'flexify-dashboard-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-styles.css', array(), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_script( 'flexify-dashboard-scripts', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-scripts.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        wp_enqueue_style( 'bootstrap-styles', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css', array(), '5.3.2' );
        wp_enqueue_script( 'bootstrap-bundle', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array('jquery'), '5.3.2' );
        wp_enqueue_style( 'boxicons', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
        wp_enqueue_script( 'apexcharts', 'https://cdn.jsdelivr.net/npm/apexcharts', array('jquery'), '3.45.2', true );

        $screen = get_current_screen();

        // load dark styles
        if ( Flexify_Dashboard_Init::get_setting('enable_dark_mode') === 'yes' && ! in_array( $screen->id, array('post', 'product', 'page') ) ) {
            wp_enqueue_style( 'flexify-dashboard-dark-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-dark-styles.css', array(), FLEXIFY_DASHBOARD_VERSION );
            wp_enqueue_script( 'flexify-dashboard-theme-mode', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-theme-mode.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        }

        // load navbar search script
        if ( Flexify_Dashboard_Init::get_setting('enable_admin_search_posts') === 'yes' ) {
            wp_enqueue_script( 'flexify-dashboard-search', FLEXIFY_DASHBOARD_ASSETS_URL . 'js/flexify-dashboard-ajax-search.js', array('jquery'), FLEXIFY_DASHBOARD_VERSION );
        }
    }


    /**
     * Change default loader
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_change_loader_icon() {
        $icon = FLEXIFY_DASHBOARD_ASSETS_URL . 'img/loader.gif';
    
        echo '<style>
            .spinner {
                background: url(' . esc_url( $icon ) . ') no-repeat;
                background-size: 4rem;
                width: 4rem;
                height: 4rem;
            }
        </style>';
    }


    /**
     * Hide Apexcharts toolbox
     * 
     * @since 1.0.0
     * @return void
     */
    public function show_apexcharts_toolbox() {
        echo '<style>
            .apexcharts-toolbar {
                display: none !important;
            }
        </style>';
    }


    /**
     * Add scrollbar dark styles
     * 
     * @since 1.0.0
     * @return void
     */
    public function scrollbar_dark_styles() {
        echo '<style>
            ::-webkit-scrollbar-track {
                background-color: #6C757D !important; 
            }
            
            ::-webkit-scrollbar-thumb {
                background-color: var(--flexify-dashboard-border-dark) !important;
                border-radius: 50px;
            }
        </style>';
    }


    /**
     * Load Boxicons on login page
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_icons() {
        wp_enqueue_style( 'boxicons', FLEXIFY_DASHBOARD_ASSETS_URL . 'vendor/boxicons/css/boxicons.min.css', array(), '2.1.4' );
    }
}

if ( get_option('flexify_dashboard_license_status') === 'valid' ) {
    new Flexify_Dashboard_Assets();
}