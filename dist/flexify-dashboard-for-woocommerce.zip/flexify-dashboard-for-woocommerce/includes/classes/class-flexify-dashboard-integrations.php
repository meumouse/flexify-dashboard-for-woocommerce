<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Integrations class
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Integrations {

    /**
     * Construc function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        add_action( 'login_enqueue_scripts', array( $this, 'add_recaptcha_to_login' ) );
        add_action( 'login_form', array( $this, 'add_recaptcha_field' ) );
    }


    /**
     * Add prevent bots service reCaptcha
     * 
     * @since 1.0.0
     * @return void
     */
    public function add_recaptcha_to_login() {
        echo '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
    }

    
    /**
     * 
     */
    public function add_recaptcha_field() {
        echo '<div class="g-recaptcha" data-sitekey="6LdkmWEpAAAAABBNY1x5Y4U22h5POY4tbTBLbIzN"></div>';
    }
}

new Flexify_Dashboard_Integrations();