<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Initialize plugin class
 * 
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard_Core {

    /**
     * Construct function
     * 
     * @since 1.0.0
     * @return void
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'replace_menu_header_template' ) );

        if ( !empty( Flexify_Dashboard_Init::get_setting('dashboard_logo') ) ) {
            add_action( 'flexify_dashboard_before_menu', array( $this, 'flexify_dashboard_sidebar_logo' ) );
        }

        add_filter( 'admin_body_class', array( $this, 'flexify_dashboard_theme_mode_state' ) );
        add_action( 'wp_ajax_save_theme_mode_state', array( $this, 'save_theme_mode_state_callback' ) );
        add_action( 'wp_ajax_flexify_dashboard_search', array( $this, 'flexify_dashboard_search_callback' ) );
        add_action( 'in_admin_header', array( $this, 'flexify_dashboard_navbar' ) );

        if ( Flexify_Dashboard_Init::get_setting('enable_flexify_dashboard_login_page') === 'yes' ) {
            add_action( 'login_footer', array( $this, 'flexify_dashboard_copyright_login' ) );
            add_filter( 'login_headerurl', array( $this, 'flexify_dashboard_login_logo_url' ) );
            add_filter( 'login_headertext', array( $this, 'flexify_dashboard_login_logo_text' ) );
            add_action( 'login_enqueue_scripts', array( $this, 'flexify_dashboard_login_styles' ) );
        }

        if ( !empty( Flexify_Dashboard_Init::get_setting('admin_login_image') ) ) {
            add_action( 'login_enqueue_scripts', array( $this, 'flexify_dashboard_login_image' ) );
        }

        if ( !empty( Flexify_Dashboard_Init::get_setting('admin_login_logo') ) ) {
            add_action( 'login_head', array( $this, 'flexify_dashboard_admin_login_logo' ) );
        }
        
        add_action( 'woocommerce_new_order', array( $this, 'clear_monthly_revenue_cache_on_order' ) );
    }

    
    /**
     * Replace original menu header archive from WordPress
     * 
     * @since 1.0.0
     * @return void
     */
    public function replace_menu_header_template() {
        $wp_menu_header = ABSPATH . 'wp-admin/menu-header.php';
        $flexify_dashboard_menu_header = FLEXIFY_DASHBOARD_INC_DIR . 'admin/parts/menu-header.php';
    
        // Checks if the modified file exists
        if ( file_exists( $flexify_dashboard_menu_header ) ) {
            // Copies the contents of the modified file to the original file
            copy( $flexify_dashboard_menu_header, $wp_menu_header );
        }
    }


    /**
     * Load navbar template
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_navbar() {
        $screen = get_current_screen();

        if ( in_array( $screen->id, array('post', 'page') ) ) {
            return;
        }
    
        include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/parts/navbar.php';
    }


    /**
     * Load sidebar logo
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_sidebar_logo() {
        ?>
        <div class="flexify-dashboard-menu-logo px-4 py-3">
            <a href="<?php echo admin_url(); ?>">
                <img class="logo" src="<?php echo esc_url( Flexify_Dashboard_Init::get_setting('dashboard_logo') ); ?>">
            </a>
        </div>
        <?php
    }
    

    /**
     * Add class 'dark-mode' to body on change theme mode
     * 
     * @since 1.0.0
     * @return array
     */
    public function flexify_dashboard_theme_mode_state( $classes ) {
        $theme_mode_state = get_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', true );

        if ( isset( $theme_mode_state ) && $theme_mode_state === 'yes' ) {
            $classes .= 'dark-mode';
        }

        return $classes;
    }


    /**
     * Save theme mode state in AJAX
     * 
     * @since 1.0.0
     * @return void
     */
    public function save_theme_mode_state_callback() {
        $theme_mode_state = sanitize_text_field( $_POST['theme_mode_state'] );

        // update user option
        update_user_meta( get_current_user_id(), 'flexify_dashboard_theme_mode', $theme_mode_state );
        
        $response = array(
            'status' => 'success',
        );
        
        echo wp_json_encode( $response ); // Send JSON response
        
        wp_die();
    }


    /**
     * Search posts of blog, produts and pages in AJAX
     * 
     * @since 1.0.0
     * @return void
     */
    function flexify_dashboard_search_callback() {
        $search_term = sanitize_text_field( $_POST['search_term'] );

        // query post type product
        $product_query = new WP_Query(array(
            'post_type' => 'product',
            's' => $search_term,
        ));
    
        // query post type page
        $page_query = new WP_Query(array(
            'post_type' => 'page',
            's' => $search_term,
        ));
    
        // query posts of blog
        $blog_query = new WP_Query(array(
            'post_type' => 'post',
            's' => $search_term,
        ));
    
        // init HTML container
        $output = '';
    
        // get products
        if ( $product_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Produtos:', 'flexify-dashboard-for-woocommerce') . '</h4>';
            $output .= '<ul class="product-list">';
            
            while ($product_query->have_posts()) {
                $product_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';

                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard-for-woocommerce') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // get pages
        if ( $page_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Páginas:', 'flexify-dashboard-for-woocommerce') . '</h4>';
            $output .= '<ul class="page-list">';

            while ($page_query->have_posts()) {
                $page_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';

                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard-for-woocommerce') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // get posts of blog
        if ( $blog_query->have_posts() ) {
            $output .= '<h4 class="bg-faded-primary text-primary py-2 px-3 rounded-pill fs-md mb-2">' . esc_html__('Postagens do blog:', 'flexify-dashboard-for-woocommerce') . '</h4>';
            $output .= '<ul class="blog-post-list">';
            
            while ($blog_query->have_posts()) {
                $blog_query->the_post();
                $output .= '<li>';
                $output .= '<a class="edit-link" href="' . get_edit_post_link() . '" target="_blank">';
                
                if ( has_post_thumbnail() ) {
                    $output .= get_the_post_thumbnail(null, 'thumbnail');
                } else {
                    $output .= '<img class="empty-post-image" src="'. esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/empty-image.svg' ) .'">';
                }

                $output .= get_the_title() . '</a>';
                $output .= '<a class="view-link btn btn-sm btn-outline-primary" href="' . get_permalink() . '" target="_blank">' . __('Visualizar', 'flexify-dashboard-for-woocommerce') . '</a>';
                $output .= '</li>';
            }

            $output .= '</ul>';
        }
    
        // Restore global post information
        wp_reset_postdata();
    
        // Send output as response to AJAX
        echo $output;
    
        wp_die(); // end AJAX call
    }


    /**
     * Add copyright message to admin login footer
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_copyright_login() {
        echo '<div id="flexify-dashboard-login-image"></div>';
        echo '<p class="flexify-dashboard-copyright">'. sprintf( __( '&copy; %s %s. Todos os direitos reservados.', 'flexify-dashboard-for-woocommerce' ), date('Y'), get_bloginfo('name') ) .'</p>';
    }

    
    /**
     * Replace admin login logo URL
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_logo_url() {
        return home_url('/');
    }

    
    /**
     * Replace admin login logo alt name
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_logo_text() {
        return get_bloginfo('name');
    }

    
    /**
     * Add admin login styles
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_styles() {
        wp_enqueue_style( 'flexify-dashboard-login-styles', FLEXIFY_DASHBOARD_ASSETS_URL . 'css/flexify-dashboard-login.css', array(), FLEXIFY_DASHBOARD_VERSION );
    }

    
    /**
     * Add admin login image on container
     * 
     * @since 1.0.0
     * @return void
     */
    public function flexify_dashboard_login_image() { 
        ?>
        <style type="text/css">
            @media screen and (min-width: 992px) {
                #flexify-dashboard-login-image {
                    background-image: url(<?php echo esc_url( Flexify_Dashboard_Init::get_setting('admin_login_image') ); ?>);
                    background-repeat: no-repeat;
                    background-position: right;
                    background-size: cover;
                    height: 100vh;
                    width: 50%;
                }
            }
        </style>
        <?php
    }


    /**
     * Replace default logo on admin login page
     * 
     * @since 1.2.5
     * @return void
     */
    public function flexify_dashboard_admin_login_logo() {
        echo '<style type="text/css">
                .login h1 a {
                    background-image: url("'. esc_url( Flexify_Dashboard_Init::get_setting('admin_login_logo') ) .'") !important;
                    background-color: #F8F9FA;
                    padding: 0.5rem;
                    border-radius: 100%;
                    background-position: center center;
                }
            </style>';
    }


    /**
     * Clean cache when new order
     * 
     * @since 1.0.0
     * @return void
     */
    public function clear_monthly_revenue_cache_on_order( $order_id ) {
        delete_transient('monthly_revenue_data');
        delete_transient('flexify_dashboard_get_order_count');
    }
}

if ( get_option('flexify_dashboard_license_status') === 'valid' ) {
    new Flexify_Dashboard_Core();
}