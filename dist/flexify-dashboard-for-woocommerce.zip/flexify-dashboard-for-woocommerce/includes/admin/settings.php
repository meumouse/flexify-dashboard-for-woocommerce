<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<h1 class="flexify-dashboard-admin-section-tile"><?php echo get_admin_page_title() ?></h1>

<div class="flexify-dashboard-admin-title-description">
    <p><?php echo esc_html__( 'Extensão que adiciona uma nova interface de usuário moderna e de simples uso. Se precisar de ajuda para configurar, acesse nossa', 'flexify-dashboard-for-woocommerce' ) ?>
        <a class="fancy-link" href="<?php echo FLEXIFY_DASHBOARD_DOCS_LINK ?>" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'flexify-dashboard-for-woocommerce' ) ?></a>
    </p>
</div>

<div class="toast toast-success update-notice-flexify-dashboard">
    <div class="toast-header bg-success text-white">
        <i class="bx bx-check-circle fs-lg me-2"></i>
        <span class="me-auto"><?php _e( 'Salvo com sucesso', 'flexify-dashboard-for-woocommerce' ); ?></span>
        <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'flexify-dashboard-for-woocommerce' ); ?></div>
</div>

<?php 

if ( $this->activateLicense === true ) {
    echo '<div class="toast toast-success show">
        <div class="toast-header bg-success text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'Licença ativada com sucesso!', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( 'Todos os recursos agora estão ativados!', 'flexify-dashboard-for-woocommerce' ) .'</div>
    </div>';
}
    
if ( $this->deactivateLicense === true ) {
    echo '<div class="toast toast-warning show">
        <div class="toast-header bg-warning text-white">
            <i class="bx bx-check-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'A licença foi desativada', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( 'Todos os recursos agora estão desativados!', 'flexify-dashboard-for-woocommerce' ) .'</div>
    </div>';
}

if (  $this->showMessage && !empty( $this->licenseMessage ) ) {
    echo '<div class="toast toast-danger show">
        <div class="toast-header bg-danger text-white">
            <i class="bx bx-info-circle fs-lg me-2"></i>
            <span class="me-auto">'. esc_html( 'Ops! Ocorreu um erro.', 'flexify-dashboard-for-woocommerce' ) .'</span>
            <button class="btn-close btn-close-white ms-2 hide-toast" type="button" aria-label="Fechar"></button>
        </div>
        <div class="toast-body">'. esc_html( $this->licenseMessage, 'flexify-dashboard-for-woocommerce' ) .'</div>
    </div>';
}

settings_errors();

if ( get_option( 'flexify_dashboard_license_status' ) === 'valid' ) {
    ?>
    <div class="flexify-dashboard-wrapper">
        <div class="nav-tab-wrapper flexify-dashboard-tab-wrapper">
            <a href="#general" class="nav-tab ">
                <i class="bx bx-slider-alt fs-xg me-2"></i>
                <?php echo esc_html( 'Geral', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#integrations" class="nav-tab ">
                <i class="bx bx-plug fs-xg me-2"></i>
                <?php echo esc_html( 'Integrações', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#widgets" class="nav-tab ">
                <i class="bx bx-extension fs-xg me-2"></i>
                <?php echo esc_html( 'Widgets', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#styles" class="nav-tab ">
                <i class="bx bx-palette fs-xg me-2"></i>
                <?php echo esc_html( 'Estilos', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
            <a href="#about" class="nav-tab ">
                <i class="bx bx-info-circle fs-xg me-2"></i>
                <?php echo esc_html( 'Sobre', 'flexify-dashboard-for-woocommerce' ) ?>
            </a>
        </div>

        <form method="post" action="" class="flexify-dashboard-form" name="flexify-dashboard">
            <input type="hidden" name="flexify-dashboard" value="1"/>

            <?php
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/options.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/integrations.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/widgets.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/design.php';
            include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/tabs/about.php'; ?>
        </form>
    </div>
    <?php
} else {
    ?>
    <div>
        <form method="post" action="" class="flexify-dashboard-form-license" name="flexify-dashboard-form-license">
        <input type="hidden" name="flexify-dashboard-form-license" value="1"/>
            <table class="insert-license">
                <tr>
                    <td class="d-grid">
                        <a class="btn btn-primary my-4 d-flex align-items-center py-3 px-4" href="https://meumouse.com/plugins/flexify-dashboard-para-woocommerce/?utm_source=wordpress&utm_medium=activate_tab&utm_campaign=flexify_dashboard" target="_blank">
                            <i class="bx bx-key fs-lg me-2"></i>
                            <span><?php _e(  'Comprar licença', 'flexify-dashboard-for-woocommerce' );?></span>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td class="w-75">
                        <span class="d-block bg-translucent-success rounded-3 py-2 px-3 mb-3"><?php echo esc_html__( 'Informe sua licença abaixo para desbloquear todos os recursos.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                        <span class="form-label d-block mt-2"><?php echo esc_html__( 'Código da licença', 'flexify-dashboard-for-woocommerce' ) ?></span>
                        <div class="input-group" style="width: 550px;">
                            <input class="form-control" type="text" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" id="flexify_dashboard_license_key" name="flexify_dashboard_license_key" size="50" value="<?php echo get_option( 'flexify_dashboard_license_key' ) ?>" />
                            <button id="flexify_dashboard_active_license" name="flexify_dashboard_active_license" class="btn btn-primary button-loading" type="submit">
                                <span class="span-inside-button-loader"><?php esc_attr_e( 'Ativar licença', 'flexify-dashboard-for-woocommerce' ); ?></span>
                            </button>
                        </div>
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php
}