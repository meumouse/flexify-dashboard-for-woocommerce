<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="general" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar caixa de ferramentas para gráficos', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar as ferramentas para análise de gráficos.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_apexcharts_toolbar" name="enable_apexcharts_toolbar" value="yes" <?php checked( $this->get_setting('enable_apexcharts_toolbar') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar pesquisa de posts', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar a caixa de pesquisa de posts na barra superior.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_admin_search_posts" name="enable_admin_search_posts" value="yes" <?php checked( $this->get_setting('enable_admin_search_posts') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar modo escuro', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o seletor de modo escuro.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_dark_mode" name="enable_dark_mode" value="yes" <?php checked( $this->get_setting('enable_dark_mode') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar barra de administração', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar a barra de administração superior.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_admin_bar" name="enable_admin_bar" value="yes" <?php checked( $this->get_setting('enable_admin_bar') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar página de login administrativo', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para carregar os estilos da página de login administrativo.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_flexify_dashboard_login_page" name="enable_flexify_dashboard_login_page" value="yes" <?php checked( $this->get_setting('enable_flexify_dashboard_login_page') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
   </table>
</div>