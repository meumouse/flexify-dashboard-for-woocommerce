<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="widgets" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de usuários totais', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de usuários totais registrados.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_total_users_widget" name="enable_total_users_widget" value="yes" <?php checked( $this->get_setting('enable_total_users_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de produtos cadastrados', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de produtos cadastrados do WooCommerce.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_products_registered_widget" name="enable_products_registered_widget" value="yes" <?php checked( $this->get_setting('enable_products_registered_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de faturamento anual', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de faturamento anual bruto e líquido do WooCommerce.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_anual_billing_widget" name="enable_anual_billing_widget" value="yes" <?php checked( $this->get_setting('enable_anual_billing_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de ticket médio', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de ticket médio de pedidos do WooCommerce.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_average_ticket_widget" name="enable_average_ticket_widget" value="yes" <?php checked( $this->get_setting('enable_average_ticket_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar widget de quantidade de pedidos', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de quantidade de pedidos do WooCommerce.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_orders_number_widget" name="enable_orders_number_widget" value="yes" <?php checked( $this->get_setting('enable_orders_number_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr class="enable-ga-integration d-none <?php echo ( $this->get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
         <th>
            <?php echo esc_html__( 'Ativar widget de tecnologia dos visitantes', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de tecnologia dos visitantes do site.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_technology_ga_widget" name="enable_technology_ga_widget" value="yes" <?php checked( $this->get_setting('enable_technology_ga_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr class="enable-ga-integration d-none <?php echo ( $this->get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
         <th>
            <?php echo esc_html__( 'Ativar widget de tipo de visitante', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para mostrar o widget de tela de tipo de visitante do site.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_visitor_type_widget" name="enable_visitor_type_widget" value="yes" <?php checked( $this->get_setting('enable_visitor_type_widget') === 'yes' ); ?> />
            </div>
         </td>
      </tr>
   </table>
</div>