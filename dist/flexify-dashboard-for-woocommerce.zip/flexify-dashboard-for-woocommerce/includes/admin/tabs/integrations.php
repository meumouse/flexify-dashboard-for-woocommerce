<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
$options = Flexify_Dashboard_Analytics_Settings::update_options( 'general' );

if ( null === $flexify_dashboard_analytics->gapi_controller ) {
   $flexify_dashboard_analytics->gapi_controller = new Flexify_Dashboard_Analytics_GAPI_Controller();
}

if ( isset( $_REQUEST['flexify_dashboard_analytics_access_code'] ) || isset( $_REQUEST['code'] ) ) {
   if ( isset( $_REQUEST['state'] ) && wp_verify_nonce( $_REQUEST['state'], 'flexify_dashboard_analytics_state' ) ) {
      if ( isset( $_REQUEST['code'] ) ){
         $flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['code'] );
      } else {
         $flexify_dashboard_analytics_access_code = sanitize_text_field( $_REQUEST['flexify_dashboard_analytics_access_code'] );
      }

      Flexify_Dashboard_Analytics_Tools::delete_cache( 'api_errors' );
      Flexify_Dashboard_Analytics_Tools::delete_cache( 'ajax_errors' );

      $token = $flexify_dashboard_analytics->gapi_controller->authenticate( $flexify_dashboard_analytics_access_code );
      $flexify_dashboard_analytics->config->options['token'] = $token;
      $flexify_dashboard_analytics->config->set_plugin_options();
      $options = Flexify_Dashboard_Analytics_Settings::update_options( 'general' );

      if ( $flexify_dashboard_analytics->config->options['token'] ) {
         $webstreams = $flexify_dashboard_analytics->gapi_controller->refresh_profiles_ga4();
         
         if ( is_array( $webstreams ) && ! empty( $webstreams ) ) {
            $flexify_dashboard_analytics->config->options['ga4_webstreams_list'] = $webstreams;
            
            if ( ! $flexify_dashboard_analytics->config->options['webstream_jail'] ) {
               $property = Flexify_Dashboard_Analytics_Tools::guess_default_domain( $webstreams, 2 );
               $flexify_dashboard_analytics->config->options['webstream_jail'] = $property;
            }

            $flexify_dashboard_analytics->config->set_plugin_options();
            $options = Flexify_Dashboard_Analytics_Settings::update_options( 'general' );

            // Redirect to prevent the connection from being disconnected when loading the page with the token in the URL
            if ( function_exists( 'wp_redirect' ) ) {
               wp_redirect( admin_url( 'admin.php?page=flexify-dashboard-for-woocommerce' ) );
               exit;
            }
         }
      }
   }
}

if ( isset( $_POST['Clear'] ) ) {
   Flexify_Dashboard_Analytics_Tools::clear_cache();

   echo '<div class="toast toast-success show">
            <div class="toast-header bg-success text-white">
               <i class="bx bx-check-circle fs-lg me-2"></i>
               <span class="me-auto">'. esc_html( 'Cache limpo com sucesso!', 'flexify-dashboard-for-woocommerce' ) .'</span>
               <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
            </div>
            <div class="toast-body">'. esc_html( 'Os dados de de conexão em cache foram limpos.', 'flexify-dashboard-for-woocommerce' ) .'</div>
         </div>';
}

if ( isset( $_POST['Reset'] ) ) {
   $flexify_dashboard_analytics->gapi_controller->reset_token( true, true );
   Flexify_Dashboard_Analytics_Tools::clear_cache();
   $options = Flexify_Dashboard_Analytics_Settings::update_options( 'Reset' );

   echo '<div class="toast toast-success show">
            <div class="toast-header bg-success text-white">
               <i class="bx bx-check-circle fs-lg me-2"></i>
               <span class="me-auto">'. esc_html( 'Conexão revogada com sucesso!', 'flexify-dashboard-for-woocommerce' ) .'</span>
               <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Fechar"></button>
            </div>
            <div class="toast-body">'. esc_html( 'A conexão com o Google Analytics foi revogada.', 'flexify-dashboard-for-woocommerce' ) .'</div>
         </div>';
}

?>

<div id="integrations" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar integração com Google Analytics', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para realizar a integração com o Google Analytics API.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td class="d-flex align-items-center">
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_ga_integration" name="enable_ga_integration" value="yes" <?php checked( self::get_setting('enable_ga_integration') === 'yes' ); ?> />
            </div>
            <button type="button" class="btn btn-outline-primary ms-3 ga-required" data-bs-toggle="modal" data-bs-target="#analytics_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard-for-woocommerce' ) ?></button>

            <div class="modal fade" id="analytics_modal" tabindex="-1" aria-labelledby="analyticsLabel" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered modal-lg">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h1 class="modal-title fs-5" id="analyticsLabel"><?php echo esc_html__( 'Configurar integração com Google Analytics', 'flexify-dashboard-for-woocommerce' ) ?></h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_html__( 'Fechar', 'flexify-dashboard-for-woocommerce' ) ?>"></button>
                     </div>
                     <div class="modal-body">
                        <table class="modal-table">
                           <?php
                              if ( $options['token'] === false ) {
                                 ?>
                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'ID do cliente', 'flexify-dashboard-for-woocommerce' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__('Informe aqui o ID do cliente relacionado a API do Google Analytics.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                                    </th>
                                    <td>
                                       <div class="form-check form-switch">
                                          <input type="text" class="form-control input-control-wd-20" id="ga_client_id" name="ga_client_id" value="<?php echo self::get_setting('ga_client_id'); ?>"/>
                                       </div>
                                    </td>
                                 </tr>
                                 <tr>
                                    <th>
                                       <?php echo esc_html__( 'Chave secreta do cliente', 'flexify-dashboard-for-woocommerce' ) ?>
                                       <span class="flexify-dashboard-description"><?php echo esc_html__('Informe aqui a chave secreta do cliente relacionado a API do Google Analytics.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                                    </th>
                                    <td>
                                       <div class="form-check form-switch">
                                          <input type="text" class="form-control input-control-wd-20" id="ga_client_secret" name="ga_client_secret" value="<?php echo self::get_setting('ga_client_secret'); ?>"/>
                                       </div>
                                    </td>
                                 </tr>
                                 <?php
                              }
                           ?>
                        </table>
                     </div>
                     <div class="modal-footer justify-content-start">
                        <table class="modal-table">
                           <?php
                           if ( $options['token'] === false && !empty( self::get_setting('ga_client_id') ) && !empty( self::get_setting('ga_client_secret') ) ) {
                              ?>
                              <tr>
                                 <td class="px-0">
                                    <?php
                                    $gapi_instance = new Flexify_Dashboard_Analytics_GAPI_Controller();
                                    $auth = $gapi_instance->createAuthUrl(); ?>

                                    <div class="d-flex align-items-center">
                                       <button type="submit" class="btn btn-primary me-3 button-loading d-flex align-items-center justify-content-center" formaction="<?php echo esc_url_raw( $auth ); ?>">
                                          <i class="bx bx-transfer-alt fs-xg me-2"></i>
                                          <?php _e( 'Autorizar conexão', 'flexify-dashboard-for-woocommerce' ); ?>
                                       </button>
                                       <button type="submit" name="Clear" class="btn btn-outline-primary button-loading"><?php _e( 'Limpar cache', 'flexify-dashboard-for-woocommerce' ); ?></button>
                                    </div>
                                 </td>
                              </tr>
                              <?php
                           }

                           if ( $options['token'] !== false && self::get_setting('enable_ga_integration') === 'yes' ) {
                              ?>
                              <tr class="ga-required <?php echo ( self::get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
                                 <th>
                                    <?php echo esc_html__( 'Fluxo de dados do Google Analytics 4', 'flexify-dashboard-for-woocommerce' ) ?>
                                    <span class="flexify-dashboard-description"><?php echo esc_html__('Selecione o fluxo de dados que deseja obter métricas.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                                 </th>
                                 <td>
                                    <select id="webstream_jail" <?php disabled(empty($options['ga4_webstreams_list']) || 1 == count($options['ga4_webstreams_list']), true); ?> name="options[webstream_jail]">
                                       <?php
                                       if ( ! empty( $options['ga4_webstreams_list'] ) ) {
                                          foreach ( $options['ga4_webstreams_list'] as $items ) {
                                             if ( $items[2] ) {
                                                ?>
                                                <option value="<?php echo esc_attr( $items[1] ); ?>" <?php selected( $items[1], $options['webstream_jail'] ); ?> title="<?php _e( 'Nome do fluxo de dados:', 'flexify-dashboard-for-woocommerce' ); ?> <?php echo esc_attr( $items[0] ); ?>">
                                                   <?php echo esc_html( Flexify_Dashboard_Analytics_Tools::strip_protocol( $items[2] ) )?> &#8658; <?php echo esc_attr( $items[0] ); ?>
                                                </option>
                                                <?php 
                                             }
                                          }
                                       }
                                       ?>
                                    </select>
                                 </td>
                              </tr>
                              <?php
                           }

                           if ( $options['token'] !== false && self::get_setting('enable_ga_integration') === 'yes' ) {
                              ?>
                              <tr class="ga-required <?php echo ( self::get_setting('enable_ga_integration') !== 'yes' ) ? 'd-none' : ''; ?>">
                                 <th>
                                    <?php echo esc_html__( 'País alvo', 'flexify-dashboard-for-woocommerce' ) ?>
                                    <span class="flexify-dashboard-description"><?php echo esc_html__( 'Selecione o país principal que será exibido métricas de acesso.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                                 </th>
                                 <td>
                                    <select name="ga_map_target_country" class="form-select">
                                       <?php $country_code = Flexify_Dashboard_Analytics_Tools::get_countrycodes();
                        
                                       foreach ( $country_code as $key => $value ) {
                                          $selected = ( self::get_setting( 'ga_map_target_country' ) == $key ) ? "selected=selected" : "";
                        
                                          echo '<option value="'. esc_attr( $key ) .'" '. $selected .'>'. $value .'</option>';
                                       }
                                       ?>
                                    </select>
                                 </td>
                              </tr>
                              <tr class="d-none">
                                 <th>
                                    <?php echo esc_html__( 'Chave de API do Google Maps', 'flexify-dashboard-for-woocommerce' ) ?>
                                    <span class="flexify-dashboard-description"><?php echo esc_html__('Informe aqui a chave de API relacionado a API do Google Maps, para exibir métricas em mapas.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                                 </th>
                                 <td>
                                    <div class="form-check form-switch">
                                       <input type="text" class="form-control input-control-wd-20" id="ga_google_maps_api_key" name="ga_google_maps_api_key" value="<?php echo self::get_setting('ga_google_maps_api_key'); ?>"/>
                                    </div>
                                 </td>
                              </tr>
                              <tr class="mt-3">
                                 <td class="px-0">
                                    <div class="card d-flex flex-row align-items-center justify-content-between p-3 border mb-4">
                                       <div class="p-2 border rounded-3 me-3">
                                          <img class="ga4-logo logo-card" src="<?php echo esc_url( FLEXIFY_DASHBOARD_ASSETS_URL . 'img/ga4-logo.svg' ) ?>">
                                       </div>
                                       <div class="d-flex flex-column me-4">
                                          <h4 class="mt-0"><?php echo esc_html__( 'Google Analytics 4', 'flexify-dashboard-for-woocommerce' ) ?></h4>
                                          <?php $webstream_info = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $flexify_dashboard_analytics->config->options['webstream_jail'] ); ?>
                                          <span class="fw-semibold text-muted fs-md"><?php echo isset( $webstream_info[3] ) ? esc_html( $webstream_info[3] ) : '' ?></span>
                                       </div>
                                       <div class="d-flex flex-row align-items-center badge bg-translucent-success fs-md rounded-pill py-2 px-3">
                                          <i class="bx bx-check-circle fs-lg me-1"></i>
                                          <?php echo esc_html__( 'Conectado', 'flexify-dashboard-for-woocommerce' ) ?>
                                       </div>
                                    </div>
                                    <div class="mb-4">
                                       <?php
                                       if ( isset( $options['webstream_jail'] ) && !empty( $flexify_dashboard_analytics->config->options['ga4_webstreams_list'] ) ) {
                                          ?>
                                             <?php $webstream_info[5] = isset( $webstream_info[5] ) ? $webstream_info[5] : '' ?>
                                             <pre><?php echo __( 'Nome do fluxo de dados:', 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[0] ) . "<br />" . __( 'ID do fluxo de dados:', 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[1] ) . "<br />" . __( 'URL do fluxo de dados:', 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[2] ) . "<br />" . __( 'ID da métrica:', 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[3] ) . "<br />" . __( 'Fuso horário:', 'flexify-dashboard-for-woocommerce' ) . "\t" . esc_html( $webstream_info[5] );?></pre>
                                          <?php 
                                       }
                                       ?>
                                    </div>
                                    <button type="submit" name="Reset" class="btn btn-sm btn-outline-warning me-2 button-loading" <?php echo $options['network_mode']?'disabled="disabled"':''; ?>><?php _e( 'Desfazer conexão', 'flexify-dashboard-for-woocommerce' ); ?></button>
                                    <button type="submit" name="Clear" class="btn btn-sm btn-outline-primary button-loading"><?php _e( 'Limpar cache', 'flexify-dashboard-for-woocommerce' ); ?></button>
                                 </td>
                              </tr>
                              <?php
                           }
                           ?>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </td>
      </tr>
      <tr>
         <td class="container-separator"></td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar reCAPTCHA para login na área administrativa', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para adicionar uma camada de segurança no login da área administrativa.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td class="d-flex align-items-center">
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_recaptcha_admin_login" name="enable_recaptcha_admin_login" value="yes" <?php checked( self::get_setting('enable_recaptcha_admin_login') === 'yes' ); ?> />
            </div>
            <button type="button" class="btn btn-outline-primary ms-3 recaptcha-required" data-bs-toggle="modal" data-bs-target="#recaptcha_modal"><?php echo esc_html__( 'Configurar', 'flexify-dashboard-for-woocommerce' ) ?></button>

            <div class="modal fade" id="recaptcha_modal" tabindex="-1" aria-labelledby="recaptchaLabel" aria-hidden="true">
               <div class="modal-dialog modal-dialog-centered modal-lg">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h1 class="modal-title fs-5" id="recaptchaLabel"><?php echo esc_html__( 'Configurar integração com Google reCAPTCHA', 'flexify-dashboard-for-woocommerce' ) ?></h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_html__( 'Fechar', 'flexify-dashboard-for-woocommerce' ) ?>"></button>
                     </div>
                     <div class="modal-body">
                        <table class="modal-table">
                           <tr>
                              <th>
                                 <?php echo esc_html__( 'Consultar credenciais', 'flexify-dashboard-for-woocommerce' ) ?>
                                 <span class="flexify-dashboard-description"><?php echo esc_html__('Acesse o link ao lado para consultar suas chaves de integração para o reCAPTCHA.', 'flexify-dashboard-for-woocommerce' ) ?></span>
                              </th>
                              <td>
                              <a class="fancy-link" href="https://www.google.com/recaptcha/admin/" target="_blank"><?php echo esc_html__( 'Google reCAPTCHA', 'flexify-dashboard-for-woocommerce' ) ?></a>
                              </td>
                           <tr>
                           <tr>
                              <th>
                                 <?php echo esc_html__( 'Chave do site', 'flexify-dashboard-for-woocommerce' ) ?>
                                 <span class="flexify-dashboard-description"><?php echo esc_html__('Informe aqui a chave do site relacionado a API do Google reCAPTCHA (Caixa de verificação v2).', 'flexify-dashboard-for-woocommerce' ) ?></span>
                              </th>
                              <td>
                                 <div class="form-check form-switch">
                                    <input type="text" class="form-control input-control-wd-20" id="recaptcha_site_key" name="recaptcha_site_key" value="<?php echo self::get_setting('recaptcha_site_key'); ?>"/>
                                 </div>
                              </td>
                           </tr>
                           <tr>
                              <th>
                                 <?php echo esc_html__( 'Chave secreta', 'flexify-dashboard-for-woocommerce' ) ?>
                                 <span class="flexify-dashboard-description"><?php echo esc_html__('Informe aqui a chave secreta relacionado a API do Google reCAPTCHA (Caixa de verificação v2).', 'flexify-dashboard-for-woocommerce' ) ?></span>
                              </th>
                              <td>
                                 <div class="form-check form-switch">
                                    <input type="text" class="form-control input-control-wd-20" id="recaptcha_secret_key" name="recaptcha_secret_key" value="<?php echo self::get_setting('recaptcha_secret_key'); ?>"/>
                                 </div>
                              </td>
                           </tr>
                        </table>
                     </div>
                     <div class="modal-footer align-content-start flex-column">
                        <?php
                        if ( Flexify_Dashboard_Init::get_setting('enable_recaptcha_admin_login') === 'yes' ) {
                           wp_enqueue_script('flexify_dashboard_recaptcha_google_api');
                           Flexify_Dashboard_Recaptcha::recaptcha_form();
                        }
                        ?>
                        <div class="d-block mt-4">
                           <h5 class="fs-6"><?php echo esc_html__( 'Observações importantes!', 'flexify-dashboard-for-woocommerce' ) ?></h5>
                           <ul>
                              <li><?php echo esc_html__( '1. Se você estiver vendo alguma mensagem de erro. Verifique suas credenciais antes de continuar.', 'flexify-dashboard-for-woocommerce' ) ?></li>
                              <li><?php echo esc_html__( '2. Se o reCAPTCHA apareceu corretamente, verifique os seguintes pontos:', 'flexify-dashboard-for-woocommerce' ) ?>
                                 <ul>
                                    <li><?php echo esc_html__( 'Abra seu site em uma guia anônima.', 'flexify-dashboard-for-woocommerce' ) ?></li>
                                    <li><?php echo esc_html__( 'Tente fazer login como administrador.', 'flexify-dashboard-for-woocommerce' ) ?></li>
                                 </ul>
                              </li>
                              <li><?php echo esc_html__( '3. Só feche essa janela após verificar que consegue fazer login perfeitamente.', 'flexify-dashboard-for-woocommerce' ) ?></li>
                              <li><?php echo esc_html__( '4. Se não conseguir fazer login como administrador em uma guia anônima, desative esse recurso. Do contrário você pode não conseguir entrar mais no painel.', 'flexify-dashboard-for-woocommerce' ) ?></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </td>
      </tr>
      <tr>
         <td class="container-separator"></td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar integração com Meta Pixel (Facebook)', 'flexify-dashboard-for-woocommerce' ) ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Ative esta opção para realizar a integração com o Google Analytics API.', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td class="d-flex align-items-center">
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_meta_pixel_integration" name="enable_meta_pixel_integration" disabled value="yes" <?php checked( self::get_setting('enable_meta_pixel_integration') === 'yes' ); ?> />
            </div>
            <span class="badge bg-primary-subtle text-primary rounded-pill py-2 px-3 fs-md ms-2"><?php echo esc_html__( 'Em breve', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </td>
      </tr>
   </table>
</div>