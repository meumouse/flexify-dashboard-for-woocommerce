<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="styles" class="nav-content">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html( 'Logo da barra lateral', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar como logo da barra lateral, ou deixe em branco para não exibir. Tamanho recomendado: 300 x 140 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="dashboard_logo" class="form-control" value="<?php echo $this->get_setting( 'dashboard_logo' ) ?>"/>
               <button id="flexify_dashboard_logo" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html( 'Imagem da página de login administrativo', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar na área lateral da página de login administrativo, ou deixe em branco para não exibir. Tamanho recomendado: 2200 x 2160 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="admin_login_image" class="form-control" value="<?php echo $this->get_setting( 'admin_login_image' ) ?>"/>
               <button id="flexify_dashboard_admin_login_image" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html( 'Logo da página de login administrativo', 'flexify-dashboard-for-woocommerce' ); ?>
            <span class="flexify-dashboard-description"><?php echo esc_html__( 'Escolha uma imagem para usar como logo da página de login administrativo, ou deixe em branco para não exibir. Tamanho recomendado: 512 x 512 pixels', 'flexify-dashboard-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="admin_login_logo" class="form-control" value="<?php echo $this->get_setting( 'admin_login_logo' ) ?>"/>
               <button id="search_admin_login_logo" class="input-group-button btn btn-outline-primary"><?php echo esc_html( 'Procurar', 'flexify-dashboard-for-woocommerce' ) ?></button>
            </div>
         </td>
      </tr>
   </table>
</div>