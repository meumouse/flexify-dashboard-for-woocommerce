/*-
 * Author: Alin Marcu Author 
 * URI: https://deconf.com 
 * Copyright 2013 Alin Marcu 
 * License: GPLv2 or later 
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

jQuery(function () {
      jQuery('#flexify_dashboard_analytics-widget *').tooltip({
		  items: "[data-flexify_dashboard_analytics]",
          content: function () {
              return jQuery(this).attr("data-flexify_dashboard_analytics");
          }
      });
  });
