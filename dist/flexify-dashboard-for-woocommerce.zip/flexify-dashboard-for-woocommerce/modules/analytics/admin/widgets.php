<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Backend_Widgets' ) ) {

	class Flexify_Dashboard_Analytics_Backend_Widgets {

		private $flexify_dashboard_analytics;

		public function __construct() {
		/*	$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) && ( 1 == $this->flexify_dashboard_analytics->config->options['dashboard_widget'] ) ) {
				add_action( 'wp_dashboard_setup', array( $this, 'add_widget' ) );
			}*/
		}

		public function add_widget() {
			wp_add_dashboard_widget( 'flexify_dashboard_analytics-widget', __( "Analytics Insights", 'flexify-dashboard-for-woocommerce' ), array( $this, 'dashboard_widget' ), $control_callback = null );
		}

		public function dashboard_widget() {
			$projectId = 0;
			if ( empty( $this->flexify_dashboard_analytics->config->options['token'] ) ) {
				echo '<p>' . __( "This plugin needs an authorization:", 'flexify-dashboard-for-woocommerce' ) . '</p><form action="' . menu_page_url( 'flexify_dashboard_analytics_settings', false ) . '" method="POST">' . get_submit_button( __( "Authorize Plugin", 'flexify-dashboard-for-woocommerce' ), 'secondary' ) . '</form>';
				return;
			}
			if ( $this->flexify_dashboard_analytics->config->options['webstream_jail'] ) {
				$projectId = $this->flexify_dashboard_analytics->config->options['webstream_jail'];
			} else {
				echo '<p>' . __( "An admin should asign a default Google Analytics property.", 'flexify-dashboard-for-woocommerce' ) . '</p><form action="' . menu_page_url( 'flexify_dashboard_analytics_settings', false ) . '" method="POST">' . get_submit_button( __( "Select Domain", 'flexify-dashboard-for-woocommerce' ), 'secondary' ) . '</form>';
				return;
			}
			if ( ! ( $projectId ) ) {
				echo '<p>' . __( "Something went wrong while retrieving property data. You need to create and properly configure a Google Analytics account:", 'flexify-dashboard-for-woocommerce' ) . '</p> <form action="https://deconf.com/how-to-set-up-google-analytics-on-your-website/" method="POST">' . get_submit_button( __( "Find out more!", 'flexify-dashboard-for-woocommerce' ), 'secondary' ) . '</form>';
				return;
			}
			?>
			<div id="flexify_dashboard_analytics-window-1"></div>
			<?php
		}
	}
}
