<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Backend_Item_Reports' ) ) {

	final class Flexify_Dashboard_Analytics_Backend_Item_Reports {

		private $flexify_dashboard_analytics;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			if ( Flexify_Dashboard_Analytics_Tools::check_roles( $this->flexify_dashboard_analytics->config->options['access_back'] ) && 1 == $this->flexify_dashboard_analytics->config->options['backend_item_reports'] ) {
				// Add custom column in Posts List
				add_filter( 'manage_posts_columns', array( $this, 'add_columns' ), 99 );
				// Populate custom column in Posts List
				add_action( 'manage_posts_custom_column', array( $this, 'add_icons' ), 99, 2 );
				// Add custom column in Pages List
				add_filter( 'manage_pages_columns', array( $this, 'add_columns' ), 99 );
				// Populate custom column in Pages List
				add_action( 'manage_pages_custom_column', array( $this, 'add_icons' ), 99, 2 );
			}
		}

		public function add_icons( $column, $id ) {
			global $wp_version;
			if ( 'flexify_dashboard_analytics_stats' != $column ) {
				return;
			}
			if ( version_compare( $wp_version, '3.8.0', '>=' ) ) {
				echo '<a id="flexify_dashboard_analytics-' . esc_attr( $id ) . '" title="' . get_the_title( $id ) . '" href="#' . esc_attr( $id ) . '" class="flexify_dashboard_analytics-icon dashicons-before dashicons-chart-line">&nbsp;</a>';
			} else {
				echo '<a id="flexify_dashboard_analytics-' . esc_attr( $id ) . '" title="' . get_the_title( $id ) . '" href="#' . esc_attr( $id ) . '"><img class="flexify_dashboard_analytics-icon-oldwp" src="' . Flexify_Dashboard_Analytics_URL . 'admin/images/flexify_dashboard_analytics-icon.png"</a>';
			}
		}

		public function add_columns( $columns ) {
			return array_merge( $columns, array( 'flexify_dashboard_analytics_stats' => '<span class="dashicons dashicons-chart-area" title="Analytics Insights"></span>' ) );
		}
	}
}
