tools = {
	isNumeric : function (string) {
		return !isNaN(parseFloat(string)) && isFinite(string);
	}	
}

jQuery( window ).on("resize",  function () {
	if ( typeof flexify_dashboard_analytics_drawFrontWidgetChart == "function" && typeof flexify_dashboard_analyticsFrontWidgetData !== 'undefined' && !tools.isNumeric( flexify_dashboard_analyticsFrontWidgetData ) ) {
		flexify_dashboard_analytics_drawFrontWidgetChart( flexify_dashboard_analyticsFrontWidgetData );
	}
} );