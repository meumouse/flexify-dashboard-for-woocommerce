<script>
var flexify_dashboard_analyticsDnt = false;
var flexify_dashboard_analyticsProperty = '<?php echo esc_js ( $data['gaid'] )?>';
var flexify_dashboard_analyticsDntFollow = <?php echo $data['gaDntOptout'] ? 'true' : 'false'?>;
var flexify_dashboard_analyticsOptout = <?php echo $data['gaOptout'] ? 'true' : 'false'?>;
var disableStr = 'ga-disable-' + flexify_dashboard_analyticsProperty;

if(flexify_dashboard_analyticsDntFollow && (window.doNotTrack === "1" || navigator.doNotTrack === "1" || navigator.doNotTrack === "yes" || navigator.msDoNotTrack === "1")) {
	flexify_dashboard_analyticsDnt = true;
}

if (flexify_dashboard_analyticsDnt || (document.cookie.indexOf(disableStr + '=true') > -1 && flexify_dashboard_analyticsOptout)) {
	window[disableStr] = true;
}

function gaOptout() {
	var expDate = new Date;
	expDate.setFullYear(expDate.getFullYear( ) + 10);
	document.cookie = disableStr + '=true; expires=' + expDate.toGMTString( ) + '; path=/';
	window[disableStr] = true;
}
</script>