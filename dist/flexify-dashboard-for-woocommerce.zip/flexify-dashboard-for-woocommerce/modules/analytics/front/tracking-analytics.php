<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tracking_Analytics_Base' ) ) {

	class Flexify_Dashboard_Analytics_Tracking_Analytics_Base {

		protected $flexify_dashboard_analytics;
		protected $gaid;
		protected $mid;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			
			if ( $this->flexify_dashboard_analytics->config->options['webstream_jail'] ) {
				$webstream = Flexify_Dashboard_Analytics_Tools::get_selected_profile( $this->flexify_dashboard_analytics->config->options['ga4_webstreams_list'], $this->flexify_dashboard_analytics->config->options['webstream_jail'] );
				if ( isset( $webstream[3] ) ){
					$this->mid = sanitize_text_field( $webstream[3] );
				} else {
					$this->mid = '';
				}
			} else {
				$this->mid = '';
			}

			if( 'ga4tracking' == $this->flexify_dashboard_analytics->config->options ['tracking_type'] ){
				$this->gaid = $this->mid;
			}
		}

		protected function build_custom_dimensions() {
			$custom_dimensions = array();
			
			if ( $this->flexify_dashboard_analytics->config->options['ga_author_dimindex'] && ( is_single() || is_page() ) ) {
				global $post;
				$author_id = $post->post_author;
				$author_name = get_the_author_meta( 'display_name', $author_id );
				$index = (int) $this->flexify_dashboard_analytics->config->options['ga_author_dimindex'];
				$custom_dimensions[$index] = sanitize_text_field( $author_name );
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_pubyear_dimindex'] && is_single() ) {
				global $post;
				$date = get_the_date( 'Y', $post->ID );
				$index = (int) $this->flexify_dashboard_analytics->config->options['ga_pubyear_dimindex'];
				$custom_dimensions[$index] = (int) $date;
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_pubyearmonth_dimindex'] && is_single() ) {
				global $post;
				$date = get_the_date( 'Y-m', $post->ID );
				$index = (int) $this->flexify_dashboard_analytics->config->options['ga_pubyearmonth_dimindex'];
				$custom_dimensions[$index] = sanitize_text_field( $date );
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_category_dimindex'] && is_category() ) {
				$fields = array();
				$index = (int) $this->flexify_dashboard_analytics->config->options['ga_category_dimindex'];
				$custom_dimensions[$index] = sanitize_text_field( single_tag_title( '', false ) );
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_category_dimindex'] && is_single() ) {
				global $post;
				
				$categories = get_the_category( $post->ID );
				
				foreach ( $categories as $category ) {
					$index = (int) $this->flexify_dashboard_analytics->config->options['ga_category_dimindex'];
					$custom_dimensions[$index] = sanitize_text_field( $category->name );
					break;
				}
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_tag_dimindex'] && is_single() ) {
				global $post;
				
				$fields = array();
				$post_tags_list = '';
				$post_tags_array = get_the_tags( $post->ID );
				
				if ( $post_tags_array ) {
					foreach ( $post_tags_array as $tag ) {
						$post_tags_list .= sanitize_text_field( $tag->name ) . ', ';
					}
				}

				$post_tags_list = rtrim( $post_tags_list, ', ' );
				
				if ( $post_tags_list ) {
					$index = (int) $this->flexify_dashboard_analytics->config->options['ga_tag_dimindex'];
					$custom_dimensions[$index] = sanitize_text_field( $post_tags_list );
				}
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_user_dimindex'] ) {
				$fields = array();
				$index = (int) $this->flexify_dashboard_analytics->config->options['ga_user_dimindex'];
				$custom_dimensions[$index] = is_user_logged_in() ? 'registered' : 'guest';
			}

			return $custom_dimensions;
		}

		protected function is_event_tracking( $with_pagescrolldepth = true ) {
			if ( $this->flexify_dashboard_analytics->config->options['ga_event_tracking'] || $this->flexify_dashboard_analytics->config->options['ga_aff_tracking'] || $this->flexify_dashboard_analytics->config->options['ga_hash_tracking'] || $this->flexify_dashboard_analytics->config->options['ga_formsubmit_tracking'] ) {
				return true;
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_pagescrolldepth_tracking'] && $with_pagescrolldepth ) {
				return true;
			}

			return false;
		}
	}
}

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tracking_Analytics_Common' ) ) {

	class Flexify_Dashboard_Analytics_Tracking_Analytics_Common extends Flexify_Dashboard_Analytics_Tracking_Analytics_Base {

		protected $commands;

		public function __construct() {
			parent::__construct();
			
			if ( $this->flexify_dashboard_analytics->config->options['optimize_tracking'] && $this->flexify_dashboard_analytics->config->options['optimize_pagehiding'] && $this->flexify_dashboard_analytics->config->options['optimize_containerid'] ) {
				add_action( 'wp_head', array( $this, 'optimize_output' ), 99 );
			}
		}

		/**
		 * Styles & Scripts load
		 */
		public function load_scripts() {
			if ( $this->is_event_tracking() ) {
				if ( $this->flexify_dashboard_analytics->config->options['amp_tracking_analytics'] && Flexify_Dashboard_Analytics_Tools::is_amp() ) {
					return;
				}

				$root_domain = Flexify_Dashboard_Analytics_Tools::get_root_domain();
				wp_enqueue_script( 'flexify_dashboard_analytics-tracking-analytics-events', FLEXIFY_DASHBOARD_URL . 'modules/analytics/front/js/tracking-analytics-events.js', array( 'jquery' ), FLEXIFY_DASHBOARD_VERSION, $this->flexify_dashboard_analytics->config->options['trackingevents_infooter'] );
				
				if ( $this->flexify_dashboard_analytics->config->options['ga_pagescrolldepth_tracking'] ) {
					wp_enqueue_script( 'flexify_dashboard_analytics-pagescrolldepth-tracking', FLEXIFY_DASHBOARD_URL . 'modules/analytics/front/js/tracking-scrolldepth.js', array( 'jquery' ), FLEXIFY_DASHBOARD_VERSION, $this->flexify_dashboard_analytics->config->options['trackingevents_infooter'] );
				}

				wp_localize_script( 'flexify_dashboard_analytics-tracking-analytics-events', 'flexify_dashboard_analyticsUAEventsData', array(
					'options' => array(
						'event_tracking' => $this->flexify_dashboard_analytics->config->options['ga_event_tracking'],
						'event_downloads' => sanitize_text_field($this->flexify_dashboard_analytics->config->options['ga_event_downloads']),
						'event_bouncerate' => $this->flexify_dashboard_analytics->config->options['ga_event_bouncerate'],
						'aff_tracking' => $this->flexify_dashboard_analytics->config->options['ga_aff_tracking'],
						'event_affiliates' =>  sanitize_text_field($this->flexify_dashboard_analytics->config->options['ga_event_affiliates']),
						'hash_tracking' =>  $this->flexify_dashboard_analytics->config->options ['ga_hash_tracking'],
						'root_domain' => sanitize_text_field( $root_domain ),
						'event_timeout' => apply_filters( 'flexify_dashboard_analytics_analyticsevents_timeout', 100 ),
						'event_precision' => $this->flexify_dashboard_analytics->config->options['ga_event_precision'],
						'event_formsubmit' =>  $this->flexify_dashboard_analytics->config->options ['ga_formsubmit_tracking'],
						'ga_pagescrolldepth_tracking' => $this->flexify_dashboard_analytics->config->options['ga_pagescrolldepth_tracking'],
						'global_site_tag' => 'ga4tracking' == $this->flexify_dashboard_analytics->config->options ['tracking_type'],
					),
				));
			}
		}

		/**
		 * Outputs the Google Optimize tracking code
		 */
		public function optimize_output() {
			Flexify_Dashboard_Analytics_Tools::load_view( 'analytics/front/views/optimize-code.php', array( 'containerid' => $this->flexify_dashboard_analytics->config->options['optimize_containerid'] ) );
		}

		/**
		 * Sanitizes the output of commands in the tracking code
		 * @param string $value
		 * @return string
		 */
		protected function filter( $value, $is_dim = false ) {
			if ( 'true' == $value || 'false' == $value || ( is_numeric( $value ) && ! $is_dim ) ) {
				return $value;
			}
			if ( substr( $value, 0, 1 ) == '[' && substr( $value, - 1 ) == ']' || substr( $value, 0, 1 ) == '{' && substr( $value, - 1 ) == '}' ) {
				return $value;
			}
			return "'" . $value . "'";
		}

		/**
		 * Retrieves the commands
		 */
		public function get() {
			return $this->commands;
		}

		/**
		 * Stores the commands
		 * @param array $commands
		 */
		public function set( $commands ) {
			$this->commands = $commands;
		}

		/**
		 * Formats the command before being added to the commands
		 * @param string $command
		 * @param array $fields
		 * @param string $fieldsobject
		 * @return array
		 */
		public function prepare( $command, $fields, $fieldsobject = null ) {
			return array( 'command' => $command, 'fields' => $fields, 'fieldsobject' => $fieldsobject );
		}

		/**
		 * Adds a formatted command to commands
		 * @param string $command
		 * @param array $fields
		 * @param string $fieldsobject
		 */
		protected function add( $command, $fields, $fieldsobject = null ) {
			$this->commands[] = $this->prepare( $command, $fields, $fieldsobject );
		}
	}
}

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tracking_GlobalSiteTag' ) ) {

	class Flexify_Dashboard_Analytics_Tracking_GlobalSiteTag extends Flexify_Dashboard_Analytics_Tracking_Analytics_Common {

		public function __construct() {
			parent::__construct();

			add_action( 'wp_head', array( $this, 'load_scripts' ), 99 );

			if ( $this->flexify_dashboard_analytics->config->options['trackingcode_infooter'] ) {
				add_action( 'wp_footer', array( $this, 'output' ), 99 );
			} else {
				add_action( 'wp_head', array( $this, 'output' ), 99 );
			}
		}

		/**
		 * Builds the commands based on user's options
		 */
		private function build_commands() {
			$fields = array();
			$fieldsobject = array();
			$fields['trackingId'] = sanitize_text_field( $this->gaid );
			$custom_dimensions = $this->build_custom_dimensions();

			if ( ! empty( $this->flexify_dashboard_analytics->config->options['ga_cookiedomain'] ) ) {
				$fieldsobject['cookie_domain'] = sanitize_text_field( $this->flexify_dashboard_analytics->config->options['ga_cookiedomain'] );
			}
			
			if ( ! empty( $this->flexify_dashboard_analytics->config->options['ga_cookiename'] ) ) {
				$fieldsobject['cookie_name'] = sanitize_text_field( $this->flexify_dashboard_analytics->config->options['ga_cookiename'] );
			}
			
			if ( ! empty( $this->flexify_dashboard_analytics->config->options['ga_cookieexpires'] ) ) {
				$fieldsobject['cookie_expires'] = (int) $this->flexify_dashboard_analytics->config->options['ga_cookieexpires'];
			}
			if ( $this->flexify_dashboard_analytics->config->options['ga_crossdomain_tracking'] && '' != $this->flexify_dashboard_analytics->config->options['ga_crossdomain_list'] ) {
				$domains = '';
				$domains = explode( ',', sanitize_text_field( $this->flexify_dashboard_analytics->config->options['ga_crossdomain_list'] ) );
				$domains = array_map( 'trim', $domains );
				$domains = strip_tags( implode( "','", $domains ) );
				$domains = "['" . $domains . "']";
				$fieldsobject['linker'] = "{ 'domains' : " . $domains . " }";
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_enhanced_links'] ) {
				$fieldsobject['link_attribution'] = 'true';
			}

			if ( $this->flexify_dashboard_analytics->config->options['ga_anonymize_ip'] ) {
				$fieldsobject['anonymize_ip'] = 'true';
			}

			if ( $this->flexify_dashboard_analytics->config->options['optimize_tracking'] && $this->flexify_dashboard_analytics->config->options['optimize_containerid'] ) {
				$fieldsobject['optimize_id'] = sanitize_text_field( $this->flexify_dashboard_analytics->config->options['optimize_containerid'] );
			}

			if ( 100 != $this->flexify_dashboard_analytics->config->options['ga_user_samplerate'] ) {
				$fieldsobject['sample_rate'] = (int) $this->flexify_dashboard_analytics->config->options['ga_user_samplerate'];
			}

			if ( ! empty( $custom_dimensions ) ) {
				$fieldsobject['custom_map'] = "{\n\t\t";
				foreach ( $custom_dimensions as $index => $value ) {
					$fieldsobject['custom_map'] .= "'dimension" . $index . "': '" . "flexify_dashboard_analytics_dim_" . $index . "', \n\t\t";
				}
				$fieldsobject['custom_map'] = rtrim( $fieldsobject['custom_map'], ", \n\t\t" );
				$fieldsobject['custom_map'] .= "\n\t}";
			}

			$this->add( 'config', $fields, $fieldsobject );

			if ( ! empty( $custom_dimensions ) ) {
				$fields = array();
				$fieldsobject = array();
				$fields['event_name'] = 'flexify_dashboard_analytics_dimensions';
				
				foreach ( $custom_dimensions as $index => $value ) {
					$fieldsobject['flexify_dashboard_analytics_dim_' . $index] = esc_js( $value );
				}

				$this->add( 'event', $fields, $fieldsobject );
			}

			do_action( 'flexify_dashboard_analytics_gtag_commands', $this );
		}

		/**
		 * Outputs the Google Analytics tracking code
		 */
		public function output() {

			$this->commands = array();
			$this->build_commands();
			$trackingcode = '';
			foreach ( $this->commands as $set ) {
				$command = $set['command'];
				$fields = '';
				foreach ( $set['fields'] as $fieldkey => $fieldvalue ) {
					$fieldvalue = $this->filter( $fieldvalue );
					$fields .= ", " . $fieldvalue;
				}
				if ( $set['fieldsobject'] ) {
					$fieldsobject = ", {\n\t";
					foreach ( $set['fieldsobject'] as $fieldkey => $fieldvalue ) {
						if ( false === strpos( $fieldkey, 'flexify_dashboard_analytics_' ) ) {
							$fieldvalue = $this->filter( $fieldvalue );
						} else {
							$fieldvalue = $this->filter( $fieldvalue, true );
						}
						$fieldkey = $this->filter( $fieldkey );
						$fieldsobject .= $fieldkey . ": " . $fieldvalue . ", \n\t";
					}
					$fieldsobject = rtrim( $fieldsobject, ", \n\t" );
					$fieldsobject .= "\n  }";
					$trackingcode .= "  gtag('" . $command . "'" . $fields . $fieldsobject . ");\n";
				} else {
					$trackingcode .= "  gtag('" . $command . "'" . $fields . ");\n";
				}
			}
			
			$tracking_script_path = apply_filters( 'flexify_dashboard_analytics_gtag_script_path', 'https://www.googletagmanager.com/gtag/js' );
			
			if ( $this->flexify_dashboard_analytics->config->options['ga_optout'] || $this->flexify_dashboard_analytics->config->options['ga_dnt_optout'] ) {
				Flexify_Dashboard_Analytics_Tools::load_view( '/analytics/front/views/analytics-optout-code.php', array( 'gaid' => $this->gaid, 'gaDntOptout' => $this->flexify_dashboard_analytics->config->options['ga_dnt_optout'], 'gaOptout' => $this->flexify_dashboard_analytics->config->options['ga_optout'] ) );
			}

			Flexify_Dashboard_Analytics_Tools::load_view( '/analytics/front/views/analytics-code.php', array( 'trackingcode' => $trackingcode, 'tracking_script_path' => $tracking_script_path, 'gaid' => $this->gaid ) );
		}
	}
}

//***************************************************************************************************************************


if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tracking_GA4_AMP' ) ) {

	class Flexify_Dashboard_Analytics_Tracking_GA4_AMP extends Flexify_Dashboard_Analytics_Tracking_Analytics_Base {

		private $config;

		public function __construct() {
			parent::__construct();
			add_filter( 'amp_post_template_data', array( $this, 'load_scripts' ) );
			// For all AMP modes, AMP plugin version >=1.3.
			//add_action( 'amp_print_analytics', array( $this, 'output' ) );
			// For AMP Standard and Transitional, AMP plugin version <1.3.
			add_action( 'wp_footer', array( $this, 'output' ) );
			// For AMP Reader, AMP plugin version <1.3.
			add_action( 'amp_post_template_footer', array( $this, 'output' ) );
			add_filter( 'the_content', array( $this, 'add_data_attributes' ), 999, 1 );
		}

		private function get_link_event_data( $link ) {
			if ( empty( $link ) ) {
				return false;
			}
			if ( $this->flexify_dashboard_analytics->config->options['ga_event_tracking'] ) {
				// on changes adjust the substr() length parameter
				if ( substr( $link, 0, 7 ) === "mailto:" ) {
					return array( 'mail', 'send', $link );
				}
				// on changes adjust the substr() length parameter
				if ( substr( $link, 0, 4 ) === "tel:" ) {
					return array( 'telephone', 'call', $link );
				}
				// Add download data-vars
				if ( $this->flexify_dashboard_analytics->config->options['ga_event_downloads'] && preg_match( '/.*\.(' . $this->flexify_dashboard_analytics->config->options['ga_event_downloads'] . ')(\?.*)?$/i', $link, $matches ) ) {
					return array( 'download', 'click', $link );
				}
			}
			if ( $this->flexify_dashboard_analytics->config->options['ga_hash_tracking'] ) {
				// Add hashmark data-vars
				$root_domain = Flexify_Dashboard_Analytics_Tools::get_root_domain();
				if ( $root_domain && ( strpos( $link, $root_domain ) > - 1 || strpos( $link, '://' ) === false ) && strpos( $link, '#' ) > - 1 ) {
					return array( 'hashmark', 'click', $link );
				}
			}
			if ( $this->flexify_dashboard_analytics->config->options['ga_aff_tracking'] ) {
				// Add affiliate data-vars
				if ( strpos( $link, $this->flexify_dashboard_analytics->config->options['ga_event_affiliates'] ) > - 1 ) {
					return array( 'affiliates', 'click', $link );
				}
			}
			if ( $this->flexify_dashboard_analytics->config->options['ga_event_tracking'] ) {
				// Add outbound data-vars
				$root_domain = Flexify_Dashboard_Analytics_Tools::get_root_domain();
				if ( $root_domain && strpos( $link, $root_domain ) === false && strpos( $link, '://' ) > - 1 ) {
					return array( 'outbound', 'click', $link );
				}
			}
			return false;
		}

		public function add_data_attributes( $content ) {
			if ( Flexify_Dashboard_Analytics_Tools::is_amp() && $this->is_event_tracking() ) {
				$dom = Flexify_Dashboard_Analytics_Tools::get_dom_from_content( $content );
				if ( $dom ) {
					$links = $dom->getElementsByTagName( 'a' );
					foreach ( $links as $item ) {
						$data_attributes = $this->get_link_event_data( $item->getAttribute( 'href' ) );
						if ( $data_attributes ) {
							if ( ! $item->hasAttribute( 'data-vars-ga-category' ) ) {
								$item->setAttribute( 'data-vars-ga-category', $data_attributes[0] );
							}
							if ( ! $item->hasAttribute( 'data-vars-ga-action' ) ) {
								$item->setAttribute( 'data-vars-ga-action', $data_attributes[1] );
							}
							if ( ! $item->hasAttribute( 'data-vars-ga-label' ) ) {
								$item->setAttribute( 'data-vars-ga-label', $data_attributes[2] );
							}
						}
					}
					if ( $this->flexify_dashboard_analytics->config->options['ga_formsubmit_tracking'] ) {
						$form_submits = $dom->getElementsByTagName( 'input' );
						foreach ( $form_submits as $item ) {
							if ( $item->getAttribute( 'type' ) == 'submit' ) {
								if ( ! $item->hasAttribute( 'data-vars-ga-category' ) ) {
									$item->setAttribute( 'data-vars-ga-category', 'form' );
								}
								if ( ! $item->hasAttribute( 'data-vars-ga-action' ) ) {
									$item->setAttribute( 'data-vars-ga-action', 'submit' );
								}
								if ( ! $item->hasAttribute( 'data-vars-ga-label' ) ) {
									if ( $item->getAttribute( 'value' ) ) {
										$label = $item->getAttribute( 'value' );
									}
									if ( $item->getAttribute( 'name' ) ) {
										$label = $item->getAttribute( 'name' );
									}
									$item->setAttribute( 'data-vars-ga-label', $label );
								}
							}
						}
					}
					return Flexify_Dashboard_Analytics_Tools::get_content_from_dom( $dom );
				}
			}
			return $content;
		}

		/**
		 * Inserts the Analytics AMP script in the head section
		 */
		public function load_scripts( $data ) {
			if ( ! isset( $data['amp_component_scripts'] ) ) {
				$data['amp_component_scripts'] = array();
			}
			$data['amp_component_scripts']['amp-analytics'] = 'https://cdn.ampproject.org/v0/amp-analytics-0.1.js';
			return $data;
		}

		/**
		 * Retrieves the AMP config array
		 */
		public function get() {
			return $this->config;
		}

		/**
		 * Stores the AMP config array
		 * @param array $config
		 */
		public function set( $config ) {
			$this->config = $config;
		}

		private function build_json() {
			$this->config = array();
			// Set the Tracking ID
			
			$this->config['vars'] = array(
				'GA4_MEASUREMENT_ID' => sanitize_text_field ( $this->mid ),
				'GA4_ENDPOINT_HOSTNAME' => 'www.google-analytics.com',
				'DEFAULT_PAGEVIEW_ENABLED' => true,
				'GOOGLE_CONSENT_ENABLED' => false,
				'WEBVITALS_TRACKING' => false,
				'PERFORMANCE_TIMING_TRACKING' => false,
				'documentLocation' => '${canonicalUrl}',
			);
			$this->config['vars']['config'] = array(
				sanitize_text_field ( $this->mid ) => array( 'groups' => 'default' ),
			);
			/* @formatter:on */
			// Set Custom Dimensions Map
			$custom_dimensions = $this->build_custom_dimensions();
			if ( ! empty( $custom_dimensions ) ) {
				$this->config['triggers']['dimension_event']['on'] = 'visible';
				$this->config['triggers']['dimension_event']['request'] = 'ga4Event';
				$this->config['triggers']['dimension_event']['vars']['ga4_event_name'] = 'flexify_dashboard_analytics_dimensions';
				foreach ( $custom_dimensions as $index => $value ) {
					$dimension = 'dimension' . $index;
					$this->config['vars']['config'][sanitize_text_field ( $this->gaid )]['custom_map'][$dimension] = 'flexify_dashboard_analytics_dim_'.$index;
					$this->config['triggers']['dimension_event']['extraUrlParams']['event__str_'.'flexify_dashboard_analytics_dim_'.$index] = esc_js( $value );
				}
			}
			/* @formatter:on */
			// Set Sampling Rate only if lower than 100%
			if ( 100 != $this->flexify_dashboard_analytics->config->options['ga_user_samplerate'] ) {
				
				$this->config['triggers']['flexify_dashboard_analyticsTrackPageview']['sampleSpec'] = array(
					'sampleOn' => '${clientId}',
					'threshold' => (int) $this->flexify_dashboard_analytics->config->options['ga_user_samplerate'],
				);
				/* @formatter:on */
			}
			// Set Scroll events
			if ( $this->flexify_dashboard_analytics->config->options['ga_pagescrolldepth_tracking'] ) {
				
				$this->config['triggers']['flexify_dashboard_analyticsScrollPings'] = array (
					'on' => 'scroll',
					'scrollSpec' => array(
						'verticalBoundaries' => '&#91;25, 50, 75, 100&#93;',
					),
					'request' => 'ga4Event',
					'vars' => array(
						'ga4_event_name' => 'scroll',
					),
					'extraUrlParams' => array(
						'event__str_percent_scrolled' => '${verticalScrollBoundary}%',
						'ni' => true,
					),
				);
			}
			if ( $this->is_event_tracking( false ) ) {
				// Set downloads, outbound links, affiliate links, hashmarks, e-mails, telephones, form submits events
				
				$this->config['triggers']['flexify_dashboard_analyticsEventTracking'] = array (
					'on' => 'click',
					'selector' => '[data-vars-ga-category][data-vars-ga-action][data-vars-ga-label]',
					'request' => 'ga4Event',
					'vars' => array(
						'ga4_event_name' => '${gaAction}',
					),
					'extraUrlParams' => array(
						'event__str_event_label' => '${gaLabel}',
						'event__str_event_category' => '${gaCategory}',
					),
				);
				/* @formatter:on */
				if ( $this->flexify_dashboard_analytics->config->options['ga_event_bouncerate'] ) {
					$this->config['triggers']['flexify_dashboard_analyticsEventTracking']['extraUrlParams']['ni'] = (bool) $this->flexify_dashboard_analytics->config->options['ga_event_bouncerate'];
				}
			}
			do_action( 'flexify_dashboard_analytics_analytics_amp_config', $this );
		}

		/**
		 * Outputs the Google Analytics tracking code for AMP
		 */
		public function output() {
			$this->build_json();
			if ( version_compare( phpversion(), '5.4.0', '<' ) ) {
				$json = json_encode( $this->config );
			} else {
				$json = json_encode( $this->config, JSON_PRETTY_PRINT );
			}
			$json = str_replace( array( '"&#91;', '&#93;"' ), array( '[', ']' ), $json ); // make verticalBoundaries a JavaScript array
			$data = array( 'json' => $json );

			Flexify_Dashboard_Analytics_Tools::load_view( 'analytics/front/views/analytics-amp-code.php', $data, 2 );

		}
	}
}
