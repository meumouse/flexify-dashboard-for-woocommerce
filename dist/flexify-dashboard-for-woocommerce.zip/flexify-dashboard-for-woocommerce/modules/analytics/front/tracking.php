<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tracking' ) ) {

	class Flexify_Dashboard_Analytics_Tracking {

		private $flexify_dashboard_analytics;
		public $analytics;
		public $analytics_amp;
		public $tagmanager;

		public function __construct() {
			$this->flexify_dashboard_analytics = Flexify_Dashboard_Analytics();
			$this->init();
		}

		public function tracking_code() { // Removed since 5.0
			Flexify_Dashboard_Analytics_Tools::doing_it_wrong( __METHOD__, __( "This method is deprecated, read the documentation!", 'flexify-dashboard-for-woocommerce' ), '5.0' );
		}

		public static function flexify_dashboard_analytics_user_optout( $atts, $content = "" ) {
			if ( ! isset( $atts['html_tag'] ) ) {
				$atts['html_tag'] = 'a';
			}

			if ( 'a' == $atts['html_tag'] ) {
				return '<a href="#" class="flexify_dashboard_analytics_useroptout" onclick="gaOptout()">' . esc_html( $content ) . '</a>';
			} else if ( 'button' == $atts['html_tag'] ) {
				return '<button class="flexify_dashboard_analytics_useroptout" onclick="gaOptout()">' . esc_html( $content ) . '</button>';
			}
		}

		public function init() {
			if ( ( 'ga4tracking' == $this->flexify_dashboard_analytics->config->options['tracking_type'] ) && $this->flexify_dashboard_analytics->config->options['webstream_jail'] ) {
				require_once FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/front/tracking-analytics.php';

				if ( 'ga4tracking' == $this->flexify_dashboard_analytics->config->options['tracking_type'] && $this->flexify_dashboard_analytics->config->options['webstream_jail'] ) {
					// Global Site Tag (gtag.js)
						if ( $this->flexify_dashboard_analytics->config->options['amp_tracking_analytics'] ) {
							$this->analytics_amp = new Flexify_Dashboard_Analytics_Tracking_GA4_AMP();
						}
				}

				$this->analytics = new Flexify_Dashboard_Analytics_Tracking_GlobalSiteTag();
			}

			if ( 'tagmanager' == $this->flexify_dashboard_analytics->config->options['tracking_type'] && $this->flexify_dashboard_analytics->config->options['web_containerid'] ) {
				// Tag Manager
				require_once FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/front/tracking-tagmanager.php';

				if ( $this->flexify_dashboard_analytics->config->options['amp_tracking_tagmanager'] && $this->flexify_dashboard_analytics->config->options['amp_containerid'] ) {
					$this->tagmanager_amp = new Flexify_Dashboard_Analytics_Tracking_TagManager_AMP();
				}

				$this->tagmanager = new Flexify_Dashboard_Analytics_Tracking_TagManager();
			}

			add_shortcode( 'flexify_dashboard_analytics_useroptout', array( $this, 'flexify_dashboard_analytics_user_optout' ) );
		}
	}
}