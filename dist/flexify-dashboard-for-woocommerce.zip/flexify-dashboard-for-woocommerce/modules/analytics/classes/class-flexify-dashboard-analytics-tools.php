<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard_Analytics_Tools' ) ) {

	class Flexify_Dashboard_Analytics_Tools {

		public static function guess_default_domain( $profiles, $index = 3 ) {
			$domain = get_option( 'siteurl' );
			$domain = str_ireplace( array( 'http://', 'https://' ), '', $domain );
			if ( ! empty( $profiles ) ) {
				foreach ( $profiles as $items ) {
					if ( strpos( $items[$index], $domain ) ) {
						return $items[1];
					}
				}
				return $profiles[0][1];
			} else {
				return '';
			}
		}

		public static function get_selected_profile( $profiles, $profile ) {
			if ( ! empty( $profiles ) ) {
				foreach ( $profiles as $item ) {
					if ( isset( $item[1] ) && $item[1] == $profile ) {
						return $item;
					}
				}
			}
		}

		public static function get_root_domain() {
			$url = site_url();
			$root = explode( '/', $url );
			preg_match( '/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', str_ireplace( 'www', '', isset( $root[2] ) ? $root[2] : $url ), $root );
			if ( isset( $root['domain'] ) ) {
				return $root['domain'];
			} else {
				return '';
			}
		}

		public static function strip_protocol( $domain ) {
			return str_replace( array( "https://", "http://", " " ), "", $domain );
		}

		public static function colourVariator( $colour, $per ) {
			$colour = substr( $colour, 1 );
			$rgb = '';
			$per = $per / 100 * 255;
			if ( $per < 0 ) {
				// Darker
				$per = abs( $per );
				for ( $x = 0; $x < 3; $x++ ) {
					$c = hexdec( substr( $colour, ( 2 * $x ), 2 ) ) - $per;
					$c = ( $c < 0 ) ? 0 : dechex( (int) $c );
					$rgb .= ( strlen( $c ) < 2 ) ? '0' . $c : $c;
				}
			} else {
				// Lighter
				for ( $x = 0; $x < 3; $x++ ) {
					$c = hexdec( substr( $colour, ( 2 * $x ), 2 ) ) + $per;
					$c = ( $c > 255 ) ? 'ff' : dechex( (int) $c );
					$rgb .= ( strlen( $c ) < 2 ) ? '0' . $c : $c;
				}
			}
			return '#' . $rgb;
		}

		public static function variations( $base ) {
			$variations[] = $base;
			$variations[] = self::colourVariator( $base, - 10 );
			$variations[] = self::colourVariator( $base, + 10 );
			$variations[] = self::colourVariator( $base, + 20 );
			$variations[] = self::colourVariator( $base, - 20 );
			$variations[] = self::colourVariator( $base, + 30 );
			$variations[] = self::colourVariator( $base, - 30 );
			return $variations;
		}

		public static function check_roles( $access_level, $tracking = false ) {
			if ( is_user_logged_in() && isset( $access_level ) ) {
				$current_user = wp_get_current_user();
				$roles = (array) $current_user->roles;
				if ( ( current_user_can( 'manage_options' ) ) && ! $tracking ) {
					return true;
				}
				if ( count( array_intersect( $roles, $access_level ) ) > 0 ) {
					return true;
				} else {
					return false;
				}
			}
		}

		public static function unset_cookie( $name ) {
			$name = 'flexify_dashboard_analytics_wg_' . $name;
			setcookie( $name, '', time() - 3600, '/' );
			$name = 'flexify_dashboard_analytics_ir_' . $name;
			setcookie( $name, '', time() - 3600, '/' );
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function set_cache( $name, $value, $expiration = 0 ) {
			update_option( '_flexify_dashboard_analytics_cache_' . $name, $value, 'no' );
			if ( $expiration ) {
				update_option( '_flexify_dashboard_analytics_cache_timeout_' . $name, time() + (int) $expiration, 'no' );
			} else {
				update_option( '_flexify_dashboard_analytics_cache_timeout_' . $name, time() + 7 * 24 * 3600, 'no' );
			}
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function delete_cache( $name ) {
			delete_option( '_flexify_dashboard_analytics_cache_' . $name );
			delete_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 * @param string $name
		 * @param mixed $value
		 * @param number $expiration
		 */
		public static function get_cache( $name ) {
			$value = get_option( '_flexify_dashboard_analytics_cache_' . $name );
			$expires = get_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
			if ( false === $value || ! isset( $value ) || ! isset( $expires ) ) {
				return false;
			}
			if ( $expires < time() ) {
				delete_option( '_flexify_dashboard_analytics_cache_' . $name );
				delete_option( '_flexify_dashboard_analytics_cache_timeout_' . $name );
				return false;
			} else {
				return $value;
			}
		}

		/**
		 * Cache Helper function. I don't use transients because cleanup plugins can break their functionality
		 */
		public static function clear_cache() {
			global $wpdb;
			$sqlquery = $wpdb->query( "DELETE FROM $wpdb->options WHERE option_name LIKE '%%flexify_dashboard_analytics_cache_%%'" );
		}

		public static function delete_expired_cache() {
			global $wpdb, $wp_version;
			if ( wp_using_ext_object_cache() ) {
				return;
			}
			if ( version_compare( $wp_version, '4.0.0', '>=' ) ) {
				$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
				WHERE a.option_name LIKE %s
				AND a.option_name NOT LIKE %s
				AND b.option_name = CONCAT( '_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 13 ) )
				AND b.option_value < %d", $wpdb->esc_like( '_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				if ( ! is_multisite() ) {
					// Single site stores site transients in the options table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
					WHERE a.option_name LIKE %s
					AND a.option_name NOT LIKE %s
					AND b.option_name = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 18 ) )
					AND b.option_value < %d", $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				} elseif ( is_multisite() && is_main_site() && is_main_network() ) {
					// Multisite stores site transients in the sitemeta table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->sitemeta} a, {$wpdb->sitemeta} b
					WHERE a.meta_key LIKE %s
					AND a.meta_key NOT LIKE %s
					AND b.meta_key = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.meta_key, 18 ) )
					AND b.meta_value < %d", $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_' ) . '%', $wpdb->esc_like( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				}
			} else {
				$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
				WHERE a.option_name LIKE %s
				AND a.option_name NOT LIKE %s
				AND b.option_name = CONCAT( '_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 13 ) )
				AND b.option_value < %d", like_escape( '_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				if ( ! is_multisite() ) {
					// Single site stores site transients in the options table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
					WHERE a.option_name LIKE %s
					AND a.option_name NOT LIKE %s
					AND b.option_name = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.option_name, 18 ) )
					AND b.option_value < %d", like_escape( '_site_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				} elseif ( is_multisite() && is_main_site() && is_main_network() ) {
					// Multisite stores site transients in the sitemeta table.
					$wpdb->query( $wpdb->prepare( "DELETE a, b FROM {$wpdb->sitemeta} a, {$wpdb->sitemeta} b
					WHERE a.meta_key LIKE %s
					AND a.meta_key NOT LIKE %s
					AND b.meta_key = CONCAT( '_site_flexify_dashboard_analytics_cache_timeout_', SUBSTRING( a.meta_key, 18 ) )
					AND b.meta_value < %d", like_escape( '_site_flexify_dashboard_analytics_cache_' ) . '%', like_escape( '_site_flexify_dashboard_analytics_cache_timeout_' ) . '%', time() ) );
				}
			}
		}

		public static function get_sites( $args ) { // Use wp_get_sites() if WP version is lower than 4.6.0
			global $wp_version;
			if ( version_compare( $wp_version, '4.6.0', '<' ) ) {
				return wp_get_sites( $args );
			} else {
				foreach ( get_sites( $args ) as $blog ) {
					$blogs[] = (array) $blog; // Convert WP_Site object to array
				}
				return $blogs;
			}
		}

		/**
		 * Loads a view file
		 *
		 * $data parameter will be available in the template file as $data['value']
		 *
		 * @param string $template - Template file to load
		 * @param array $data - data to pass along to the template
		 * @return boolean - If template file was found
		 **/
		public static function load_view( $path, $data = array(), $globalsitetag = 0 ) {
			if ( file_exists( FLEXIFY_DASHBOARD_MODULES_DIR . $path ) ) {
				require ( FLEXIFY_DASHBOARD_MODULES_DIR . $path );
				return true;
			}
			
			return false;
		}

		public static function doing_it_wrong( $function, $message, $version ) {
			if ( WP_DEBUG && apply_filters( 'doing_it_wrong_trigger_error', true ) ) {
				if ( is_null( $version ) ) {
					$version = '';
				} else {
					/* translators: %s: version number */
					$version = sprintf( __( 'This message was added in version %s.', 'flexify-dashboard-for-woocommerce' ), $version );
				}
				/* translators: Developer debugging message. 1: PHP function name, 2: Explanatory message, 3: Version information message */
				trigger_error( sprintf( __( '%1$s was called <strong>incorrectly</strong>. %2$s %3$s', 'flexify-dashboard-for-woocommerce' ), $function, $message, $version ) );
			}
		}

		public static function get_dom_from_content( $content ) {
			$libxml_previous_state = libxml_use_internal_errors( true );
			if ( class_exists( 'DOMDocument' ) ) {
				$dom = new DOMDocument();
				$result = $dom->loadHTML( '<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8"></head><body>' . $content . '</body></html>' );
				libxml_clear_errors();
				libxml_use_internal_errors( $libxml_previous_state );
				if ( ! $result ) {
					return false;
				}
				return $dom;
			} else {
				self::set_error( __( 'DOM is disabled or libxml PHP extension is missing. Contact your hosting provider. Automatic tracking of events for AMP pages is not possible.', 'flexify-dashboard-for-woocommerce' ), 24 * 60 * 60 );
				return false;
			}
		}

		public static function get_content_from_dom( $dom ) {
			$out = '';
			$body = $dom->getElementsByTagName( 'body' )->item( 0 );
			foreach ( $body->childNodes as $node ) {
				$out .= $dom->saveXML( $node );
			}
			return $out;
		}

		public static function array_keys_rename( $options, $keys ) {
			foreach ( $keys as $key => $newkey ) {
				if ( isset( $options[$key] ) ) {
					$options[$newkey] = $options[$key];
					unset( $options[$key] );
				}
			}
			return $options;
		}

		public static function set_error( $e, $timeout, $ajax = false ) {
			if ( $ajax ) {
				self::set_cache( 'ajax_errors', esc_html( print_r( $e, true ) ), $timeout );
			} else {
				if ( is_object( $e ) ) {
					if ( method_exists( $e, 'get_error_code' ) && method_exists( $e, 'get_error_message' ) ) {
						$error_code = $e->get_error_code();
						if ( 500 == $error_code || 503 == $error_code ) {
							$timeout = 60;
						}
						self::set_cache( 'api_errors', array( $e->get_error_code(), $e->get_error_message(), $e->get_error_data() ), $timeout );
					} else {
						self::set_cache( 'api_errors', array( 600, array(), esc_html( print_r( $e, true ) ) ), $timeout );
					}
				} else if ( is_array( $e ) ) {
					self::set_cache( 'api_errors', array( 601, array(), esc_html( print_r( $e, true ) ) ), $timeout );
				} else {
					self::set_cache( 'api_errors', array( 602, array(), esc_html( print_r( $e, true ) ) ), $timeout );
				}
				// Count Errors until midnight
				$midnight = strtotime( "tomorrow 00:00:00" ); // UTC midnight
				$midnight = $midnight + 8 * 3600; // UTC 8 AM
				$tomidnight = $midnight - time();
				$errors_count = self::get_cache( 'errors_count' );
				$errors_count = (int) $errors_count + 1;
				self::set_cache( 'errors_count', $errors_count, $tomidnight );
			}
		}

		public static function anonymize_options( $options ) {
			global $wp_version;
			$options['wp_version'] = $wp_version;
			$options['flexify_dashboard_analytics_version'] = FLEXIFY_DASHBOARD_VERSION;
			if ( $options['token'] && ( ! WP_DEBUG || ( is_multisite() && ! current_user_can( 'manage_network_options' ) ) ) ) {
				$options['token'] = 'HIDDEN';
			} else {
				$options['token'] = (array) $options['token'];
				unset( $options['token']['challenge'] );
			}
			if ( $options['client_secret'] ) {
				$options['client_secret'] = 'HIDDEN';
			}
			return $options;
		}

		public static function system_info() {
			$info = '';
			// Server Software
			$server_soft = "-";
			if ( isset( $_SERVER['SERVER_SOFTWARE'] ) ) {
				$server_soft = $_SERVER['SERVER_SOFTWARE'];
			}
			$info .= 'Server Info: ' . sanitize_text_field( $server_soft ) . "\n";
			// PHP version
			if ( defined( 'PHP_VERSION' ) ) {
				$info .= 'PHP Version: ' . PHP_VERSION . "\n";
			} else if ( defined( 'HHVM_VERSION' ) ) {
				$info .= 'HHVM Version: ' . HHVM_VERSION . "\n";
			} else {
				$info .= 'Other Version: ' . '-' . "\n";
			}
			// cURL Info
			if ( function_exists( 'curl_version' ) && function_exists( 'curl_exec' ) ) {
				$curl_version = curl_version();
				if ( ! empty( $curl_version ) ) {
					$curl_ver = $curl_version['version'] . " " . $curl_version['ssl_version'];
				} else {
					$curl_ver = '-';
				}
			} else {
				$curl_ver = '-';
			}
			$info .= 'cURL Info: ' . $curl_ver . "\n";
			// Gzip
			if ( is_callable( 'gzopen' ) ) {
				$gzip = true;
			} else {
				$gzip = false;
			}
			$gzip_status = ( $gzip ) ? 'Yes' : 'No';
			$info .= 'Gzip: ' . $gzip_status . "\n";
			return $info;
		}

		/**
		 * Follows the SCRIPT_DEBUG settings
		 * @param string $script
		 * @return string
		 */
		public static function script_debug_suffix() {
			if ( defined( 'SCRIPT_DEBUG' ) and SCRIPT_DEBUG ) {
				return '';
			} else {
				return '.min';
			}
		}

		/**
		 * Dimensions and metric mapping from GA3 to GA4
		 * @param string $value
		 * @return string
		 */
		public static function ga3_ga4_mapping( $value ) {
			$value = str_replace( 'ga:', '', $value );
			$list = [ 'users' => 'totalUsers', 'sessionDuration' => 'userEngagementDuration', 'fullReferrer' => 'pageReferrer', 'source' => 'sessionSource', 'medium' => 'sessionMedium', 'dataSource' => 'platform',
				// 'pagePath' => 'pagePathPlusQueryString',
				'pageviews' => 'screenPageViews', 'pageviewsPerSession' => 'screenPageViewsPerSession', 'timeOnPage' => 'userEngagementDuration', 'channelGrouping' => 'sessionDefaultChannelGrouping', 'dayOfWeekName' => 'dayOfWeek', 'visitBounceRate' => 'bounceRate', 'organicSearches' => 'engagedSessions', 'socialNetwork' => 'language', 'visitorType' => 'newVsReturning', 'uniquePageviews' => 'sessions' ];
			if ( isset( $list[$value] ) ) {
				return $list[$value];
			} else {
				return $value;
			}
		}

		public static function secondstohms( $value ) {
			$value = (float) $value;
			$hours = floor( $value / 3600 );
			$hours = $hours < 10 ? '0' . $hours : (string) $hours;
			$minutes = floor( (int) ( $value / 60 ) % 60 );
			$minutes = $minutes < 10 ? '0' . $minutes : (string) $minutes;
			$seconds = floor( (int)$value % 60 );
			$seconds = $seconds < 10 ? '0' . $seconds : (string) $seconds;
			return $hours . ':' . $minutes . ':' . $seconds;
		}

		public static function is_amp() {
			if ( is_singular( 'web-story' ) ) {
				return true;
			}
			return function_exists( 'is_amp_endpoint' ) && is_amp_endpoint();
		}

		public function generate_random( $length = 10 ) {
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen( $characters );
			$randomString = '';
			for ( $i = 0; $i < $length; $i++ ) {
				$randomString .= $characters[random_int( 0, $charactersLength - 1 )];
			}
			return $randomString;
		}

		public static function report_errors() {
			if ( Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ) ) {
				$info = Flexify_Dashboard_Analytics_Tools::system_info();
				$info .= 'Flexify_Dashboard_Analytics Version: ' . FLEXIFY_DASHBOARD_VERSION;
				$sep = "\n---------------------------\n";
				$error_report = $sep . print_r( Flexify_Dashboard_Analytics_Tools::get_cache( 'api_errors' ), true );
				$error_report .= $sep . Flexify_Dashboard_Analytics_Tools::get_cache( 'errors_count' );
				$error_report .= $sep . $info;
				$error_report = urldecode( $error_report );
				$url = Flexify_Dashboard_Analytics_ENDPOINT_URL . 'flexify_dashboard_analytics-report.php';
				
		$response = wp_remote_post( $url, array(
		 'method' => 'POST',
		 'timeout' => 45,
		 'redirection' => 5,
		 'httpversion' => '1.0',
		 'blocking' => true,
		 'headers' => array(),
		 'body' => array( 'error_report' => esc_html( $error_report ) ),
		 'cookies' => array()
		 )
		 );
		
		 }
		}

		/** Keeps compatibility with WP < 5.3.0
		 *
		 * @return string
		 */
		public static function timezone_string() {
			$timezone_string = get_option( 'timezone_string' );

			if ( $timezone_string ) {
				return $timezone_string;
			}

			$offset  = (float) get_option( 'gmt_offset' );
			$hours   = (int) $offset;
			$minutes = ( $offset - $hours );

			$sign      = ( $offset < 0 ) ? '-' : '+';
			$abs_hour  = abs( $hours );
			$abs_mins  = abs( $minutes * 60 );
			$tz_offset = sprintf( '%s%02d:%02d', $sign, $abs_hour, $abs_mins );

			return $tz_offset;
		}


		/**
		 * Get country codes array
		 * ISO 3166 alpha-2 country codes
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public static function get_countrycodes() {
			return array(
				'none' => esc_html( 'Nenhum', 'flexify-dashboard-for-woocommerce' ),
				'AF' => esc_html( 'Afghanistan', 'flexify-dashboard-for-woocommerce' ),
				'AL' => esc_html( 'Albania', 'flexify-dashboard-for-woocommerce' ),
				'DZ' => esc_html( 'Algeria', 'flexify-dashboard-for-woocommerce' ),
				'AS' => esc_html( 'American Samoa', 'flexify-dashboard-for-woocommerce' ),
				'AD' => esc_html( 'Andorra', 'flexify-dashboard-for-woocommerce' ),
				'AO' => esc_html( 'Angola', 'flexify-dashboard-for-woocommerce' ),
				'AI' => esc_html( 'Anguilla', 'flexify-dashboard-for-woocommerce' ),
				'AQ' => esc_html( 'Antarctica', 'flexify-dashboard-for-woocommerce' ),
				'AG' => esc_html( 'Antigua and Barbuda', 'flexify-dashboard-for-woocommerce' ),
				'AR' => esc_html( 'Argentina', 'flexify-dashboard-for-woocommerce' ),
				'AM' => esc_html( 'Armenia', 'flexify-dashboard-for-woocommerce' ),
				'AW' => esc_html( 'Aruba', 'flexify-dashboard-for-woocommerce' ),
				'AU' => esc_html( 'Australia', 'flexify-dashboard-for-woocommerce' ),
				'AT' => esc_html( 'Austria', 'flexify-dashboard-for-woocommerce' ),
				'AZ' => esc_html( 'Azerbaijan', 'flexify-dashboard-for-woocommerce' ),
				'BS' => esc_html( 'Bahamas', 'flexify-dashboard-for-woocommerce' ),
				'BH' => esc_html( 'Bahrain', 'flexify-dashboard-for-woocommerce' ),
				'BD' => esc_html( 'Bangladesh', 'flexify-dashboard-for-woocommerce' ),
				'BB' => esc_html( 'Barbados', 'flexify-dashboard-for-woocommerce' ),
				'BY' => esc_html( 'Belarus', 'flexify-dashboard-for-woocommerce' ),
				'BE' => esc_html( 'Belgium', 'flexify-dashboard-for-woocommerce' ),
				'BZ' => esc_html( 'Belize', 'flexify-dashboard-for-woocommerce' ),
				'BJ' => esc_html( 'Benin', 'flexify-dashboard-for-woocommerce' ),
				'BM' => esc_html( 'Bermuda', 'flexify-dashboard-for-woocommerce' ),
				'BT' => esc_html( 'Bhutan', 'flexify-dashboard-for-woocommerce' ),
				'BO' => esc_html( 'Bolivia', 'flexify-dashboard-for-woocommerce' ),
				'BQ' => esc_html( 'Bonaire, Sint Eustatius and Saba', 'flexify-dashboard-for-woocommerce' ),
				'BA' => esc_html( 'Bosnia and Herzegovina', 'flexify-dashboard-for-woocommerce' ),
				'BW' => esc_html( 'Botswana', 'flexify-dashboard-for-woocommerce' ),
				'BV' => esc_html( 'Bouvet Island', 'flexify-dashboard-for-woocommerce' ),
				'BR' => esc_html( 'Brasil', 'flexify-dashboard-for-woocommerce' ),
				'IO' => esc_html( 'British Indian Ocean Territory', 'flexify-dashboard-for-woocommerce' ),
				'BN' => esc_html( 'Brunei Darussalam', 'flexify-dashboard-for-woocommerce' ),
				'BG' => esc_html( 'Bulgaria', 'flexify-dashboard-for-woocommerce' ),
				'BF' => esc_html( 'Burkina Faso', 'flexify-dashboard-for-woocommerce' ),
				'BI' => esc_html( 'Burundi', 'flexify-dashboard-for-woocommerce' ),
				'CV' => esc_html( 'Cabo Verde', 'flexify-dashboard-for-woocommerce' ),
				'KH' => esc_html( 'Cambodia', 'flexify-dashboard-for-woocommerce' ),
				'CM' => esc_html( 'Cameroon', 'flexify-dashboard-for-woocommerce' ),
				'CA' => esc_html( 'Canada', 'flexify-dashboard-for-woocommerce' ),
				'KY' => esc_html( 'Cayman Islands', 'flexify-dashboard-for-woocommerce' ),
				'CF' => esc_html( 'Central African Republic', 'flexify-dashboard-for-woocommerce' ),
				'TD' => esc_html( 'Chad', 'flexify-dashboard-for-woocommerce' ),
				'CL' => esc_html( 'Chile', 'flexify-dashboard-for-woocommerce' ),
				'CN' => esc_html( 'China', 'flexify-dashboard-for-woocommerce' ),
				'CX' => esc_html( 'Christmas Island', 'flexify-dashboard-for-woocommerce' ),
				'CC' => esc_html( 'Cocos (Keeling) Islands', 'flexify-dashboard-for-woocommerce' ),
				'CO' => esc_html( 'Colombia', 'flexify-dashboard-for-woocommerce' ),
				'KM' => esc_html( 'Comoros', 'flexify-dashboard-for-woocommerce' ),
				'CD' => esc_html( 'Democratic Republic of the Congo', 'flexify-dashboard-for-woocommerce' ),
				'CG' => esc_html( 'Republic of the Congo', 'flexify-dashboard-for-woocommerce' ),
				'CK' => esc_html( 'Cook Islands', 'flexify-dashboard-for-woocommerce' ),
				'CR' => esc_html( 'Costa Rica', 'flexify-dashboard-for-woocommerce' ),
				'HR' => esc_html( 'Croatia', 'flexify-dashboard-for-woocommerce' ),
				'CU' => esc_html( 'Cuba', 'flexify-dashboard-for-woocommerce' ),
				'CW' => esc_html( 'Curaçao', 'flexify-dashboard-for-woocommerce' ),
				'CY' => esc_html( 'Cyprus', 'flexify-dashboard-for-woocommerce' ),
				'CZ' => esc_html( 'Czechia', 'flexify-dashboard-for-woocommerce' ),
				'CI' => esc_html( 'Côte d`Ivoire', 'flexify-dashboard-for-woocommerce' ),
				'DK' => esc_html( 'Denmark', 'flexify-dashboard-for-woocommerce' ),
				'DJ' => esc_html( 'Djibouti', 'flexify-dashboard-for-woocommerce' ),
				'DM' => esc_html( 'Dominica', 'flexify-dashboard-for-woocommerce' ),
				'DO' => esc_html( 'Dominican Republic', 'flexify-dashboard-for-woocommerce' ),
				'EC' => esc_html( 'Ecuador', 'flexify-dashboard-for-woocommerce' ),
				'EG' => esc_html( 'Egypt', 'flexify-dashboard-for-woocommerce' ),
				'SV' => esc_html( 'El Salvador', 'flexify-dashboard-for-woocommerce' ),
				'GQ' => esc_html( 'Equatorial Guinea', 'flexify-dashboard-for-woocommerce' ),
				'ER' => esc_html( 'Eritrea', 'flexify-dashboard-for-woocommerce' ),
				'EE' => esc_html( 'Estonia', 'flexify-dashboard-for-woocommerce' ),
				'SZ' => esc_html( 'Eswatini', 'flexify-dashboard-for-woocommerce' ),
				'ET' => esc_html( 'Ethiopia', 'flexify-dashboard-for-woocommerce' ),
				'FK' => esc_html( 'Falkland Islands [Malvinas]', 'flexify-dashboard-for-woocommerce' ),
				'FO' => esc_html( 'Faroe Islands', 'flexify-dashboard-for-woocommerce' ),
				'FJ' => esc_html( 'Fiji', 'flexify-dashboard-for-woocommerce' ),
				'FI' => esc_html( 'Finland', 'flexify-dashboard-for-woocommerce' ),
				'FR' => esc_html( 'France', 'flexify-dashboard-for-woocommerce' ),
				'GF' => esc_html( 'French Guiana', 'flexify-dashboard-for-woocommerce' ),
				'PF' => esc_html( 'French Polynesia', 'flexify-dashboard-for-woocommerce' ),
				'TF' => esc_html( 'French Southern Territories', 'flexify-dashboard-for-woocommerce' ),
				'GA' => esc_html( 'Gabon', 'flexify-dashboard-for-woocommerce' ),
				'GM' => esc_html( 'Gambia', 'flexify-dashboard-for-woocommerce' ),
				'GE' => esc_html( 'Georgia', 'flexify-dashboard-for-woocommerce' ),
				'DE' => esc_html( 'Germany', 'flexify-dashboard-for-woocommerce' ),
				'GH' => esc_html( 'Ghana', 'flexify-dashboard-for-woocommerce' ),
				'GI' => esc_html( 'Gibraltar', 'flexify-dashboard-for-woocommerce' ),
				'GR' => esc_html( 'Greece', 'flexify-dashboard-for-woocommerce' ),
				'GL' => esc_html( 'Greenland', 'flexify-dashboard-for-woocommerce' ),
				'GD' => esc_html( 'Grenada', 'flexify-dashboard-for-woocommerce' ),
				'GP' => esc_html( 'Guadeloupe', 'flexify-dashboard-for-woocommerce' ),
				'GU' => esc_html( 'Guam', 'flexify-dashboard-for-woocommerce' ),
				'GT' => esc_html( 'Guatemala', 'flexify-dashboard-for-woocommerce' ),
				'GG' => esc_html( 'Guernsey', 'flexify-dashboard-for-woocommerce' ),
				'GN' => esc_html( 'Guinea', 'flexify-dashboard-for-woocommerce' ),
				'GW' => esc_html( 'Guinea-Bissau', 'flexify-dashboard-for-woocommerce' ),
				'GY' => esc_html( 'Guyana', 'flexify-dashboard-for-woocommerce' ),
				'HT' => esc_html( 'Haiti', 'flexify-dashboard-for-woocommerce' ),
				'HM' => esc_html( 'Heard Island and McDonald Islands', 'flexify-dashboard-for-woocommerce' ),
				'VA' => esc_html( 'Holy See', 'flexify-dashboard-for-woocommerce' ),
				'HN' => esc_html( 'Honduras', 'flexify-dashboard-for-woocommerce' ),
				'HK' => esc_html( 'Hong Kong', 'flexify-dashboard-for-woocommerce' ),
				'HU' => esc_html( 'Hungary', 'flexify-dashboard-for-woocommerce' ),
				'IS' => esc_html( 'Iceland', 'flexify-dashboard-for-woocommerce' ),
				'IN' => esc_html( 'India', 'flexify-dashboard-for-woocommerce' ),
				'ID' => esc_html( 'Indonesia', 'flexify-dashboard-for-woocommerce' ),
				'IR' => esc_html( 'Iran', 'flexify-dashboard-for-woocommerce' ),
				'IQ' => esc_html( 'Iraq', 'flexify-dashboard-for-woocommerce' ),
				'IE' => esc_html( 'Ireland', 'flexify-dashboard-for-woocommerce' ),
				'IM' => esc_html( 'Isle of Man', 'flexify-dashboard-for-woocommerce' ),
				'IL' => esc_html( 'Israel', 'flexify-dashboard-for-woocommerce' ),
				'IT' => esc_html( 'Italy', 'flexify-dashboard-for-woocommerce' ),
				'JM' => esc_html( 'Jamaica', 'flexify-dashboard-for-woocommerce' ),
				'JP' => esc_html( 'Japan', 'flexify-dashboard-for-woocommerce' ),
				'JE' => esc_html( 'Jersey', 'flexify-dashboard-for-woocommerce' ),
				'JO' => esc_html( 'Jordan', 'flexify-dashboard-for-woocommerce' ),
				'KZ' => esc_html( 'Kazakhstan', 'flexify-dashboard-for-woocommerce' ),
				'KE' => esc_html( 'Kenya', 'flexify-dashboard-for-woocommerce' ),
				'KI' => esc_html( 'Kiribati', 'flexify-dashboard-for-woocommerce' ),
				'KP' => esc_html( 'Democratic Peoples Republic of Korea', 'flexify-dashboard-for-woocommerce' ),
				'KR' => esc_html( 'Republic of Korea', 'flexify-dashboard-for-woocommerce' ),
				'KW' => esc_html( 'Kuwait', 'flexify-dashboard-for-woocommerce' ),
				'KG' => esc_html( 'Kyrgyzstan', 'flexify-dashboard-for-woocommerce' ),
				'LA' => esc_html( 'Lao', 'flexify-dashboard-for-woocommerce' ),
				'LV' => esc_html( 'Latvia', 'flexify-dashboard-for-woocommerce' ),
				'LB' => esc_html( 'Lebanon', 'flexify-dashboard-for-woocommerce' ),
				'LS' => esc_html( 'Lesotho', 'flexify-dashboard-for-woocommerce' ),
				'LR' => esc_html( 'Liberia', 'flexify-dashboard-for-woocommerce' ),
				'LY' => esc_html( 'Libya', 'flexify-dashboard-for-woocommerce' ),
				'LI' => esc_html( 'Liechtenstein', 'flexify-dashboard-for-woocommerce' ),
				'LT' => esc_html( 'Lithuania', 'flexify-dashboard-for-woocommerce' ),
				'LU' => esc_html( 'Luxembourg', 'flexify-dashboard-for-woocommerce' ),
				'MO' => esc_html( 'Macao', 'flexify-dashboard-for-woocommerce' ),
				'MG' => esc_html( 'Madagascar', 'flexify-dashboard-for-woocommerce' ),
				'MW' => esc_html( 'Malawi', 'flexify-dashboard-for-woocommerce' ),
				'MY' => esc_html( 'Malaysia', 'flexify-dashboard-for-woocommerce' ),
				'MV' => esc_html( 'Maldives', 'flexify-dashboard-for-woocommerce' ),
				'ML' => esc_html( 'Mali', 'flexify-dashboard-for-woocommerce' ),
				'MT' => esc_html( 'Malta', 'flexify-dashboard-for-woocommerce' ),
				'MH' => esc_html( 'Marshall Islands', 'flexify-dashboard-for-woocommerce' ),
				'MQ' => esc_html( 'Martinique', 'flexify-dashboard-for-woocommerce' ),
				'MR' => esc_html( 'Mauritania', 'flexify-dashboard-for-woocommerce' ),
				'MU' => esc_html( 'Mauritius', 'flexify-dashboard-for-woocommerce' ),
				'YT' => esc_html( 'Mayotte', 'flexify-dashboard-for-woocommerce' ),
				'MX' => esc_html( 'Mexico', 'flexify-dashboard-for-woocommerce' ),
				'FM' => esc_html( 'Micronesia', 'flexify-dashboard-for-woocommerce' ),
				'MD' => esc_html( 'Moldova', 'flexify-dashboard-for-woocommerce' ),
				'MC' => esc_html( 'Monaco', 'flexify-dashboard-for-woocommerce' ),
				'MN' => esc_html( 'Mongolia', 'flexify-dashboard-for-woocommerce' ),
				'ME' => esc_html( 'Montenegro', 'flexify-dashboard-for-woocommerce' ),
				'MS' => esc_html( 'Montserrat', 'flexify-dashboard-for-woocommerce' ),
				'MA' => esc_html( 'Morocco', 'flexify-dashboard-for-woocommerce' ),
				'MZ' => esc_html( 'Mozambique', 'flexify-dashboard-for-woocommerce' ),
				'MM' => esc_html( 'Myanmar', 'flexify-dashboard-for-woocommerce' ),
				'NA' => esc_html( 'Namibia', 'flexify-dashboard-for-woocommerce' ),
				'NR' => esc_html( 'Nauru', 'flexify-dashboard-for-woocommerce' ),
				'NP' => esc_html( 'Nepal', 'flexify-dashboard-for-woocommerce' ),
				'NL' => esc_html( 'Netherlands', 'flexify-dashboard-for-woocommerce' ),
				'NC' => esc_html( 'New Caledonia', 'flexify-dashboard-for-woocommerce' ),
				'NZ' => esc_html( 'New Zealand', 'flexify-dashboard-for-woocommerce' ),
				'NI' => esc_html( 'Nicaragua', 'flexify-dashboard-for-woocommerce' ),
				'NE' => esc_html( 'Niger', 'flexify-dashboard-for-woocommerce' ),
				'NG' => esc_html( 'Nigeria', 'flexify-dashboard-for-woocommerce' ),
				'NU' => esc_html( 'Niue', 'flexify-dashboard-for-woocommerce' ),
				'NF' => esc_html( 'Norfolk Island', 'flexify-dashboard-for-woocommerce' ),
				'MP' => esc_html( 'Northern Mariana Islands', 'flexify-dashboard-for-woocommerce' ),
				'NO' => esc_html( 'Norway', 'flexify-dashboard-for-woocommerce' ),
				'OM' => esc_html( 'Oman', 'flexify-dashboard-for-woocommerce' ),
				'PK' => esc_html( 'Pakistan', 'flexify-dashboard-for-woocommerce' ),
				'PW' => esc_html( 'Palau', 'flexify-dashboard-for-woocommerce' ),
				'PS' => esc_html( 'Palestine, State of Israel', 'flexify-dashboard-for-woocommerce' ),
				'PA' => esc_html( 'Panama', 'flexify-dashboard-for-woocommerce' ),
				'PG' => esc_html( 'Papua New Guinea', 'flexify-dashboard-for-woocommerce' ),
				'PY' => esc_html( 'Paraguay', 'flexify-dashboard-for-woocommerce' ),
				'PE' => esc_html( 'Peru', 'flexify-dashboard-for-woocommerce' ),
				'PH' => esc_html( 'Philippines', 'flexify-dashboard-for-woocommerce' ),
				'PN' => esc_html( 'Pitcairn', 'flexify-dashboard-for-woocommerce' ),
				'PL' => esc_html( 'Poland', 'flexify-dashboard-for-woocommerce' ),
				'PT' => esc_html( 'Portugal', 'flexify-dashboard-for-woocommerce' ),
				'PR' => esc_html( 'Puerto Rico', 'flexify-dashboard-for-woocommerce' ),
				'QA' => esc_html( 'Qatar', 'flexify-dashboard-for-woocommerce' ),
				'MK' => esc_html( 'Republic of North Macedonia', 'flexify-dashboard-for-woocommerce' ),
				'RO' => esc_html( 'Romania', 'flexify-dashboard-for-woocommerce' ),
				'RU' => esc_html( 'Russian Federation', 'flexify-dashboard-for-woocommerce' ),
				'RW' => esc_html( 'Rwanda', 'flexify-dashboard-for-woocommerce' ),
				'RE' => esc_html( 'Réunion', 'flexify-dashboard-for-woocommerce' ),
				'BL' => esc_html( 'Saint Barthélemy', 'flexify-dashboard-for-woocommerce' ),
				'SH' => esc_html( 'Saint Helena, Ascension and Tristan da Cunha', 'flexify-dashboard-for-woocommerce' ),
				'KN' => esc_html( 'Saint Kitts and Nevis', 'flexify-dashboard-for-woocommerce' ),
				'LC' => esc_html( 'Saint Lucia', 'flexify-dashboard-for-woocommerce' ),
				'MF' => esc_html( 'Saint Martin', 'flexify-dashboard-for-woocommerce' ),
				'PM' => esc_html( 'Saint Pierre and Miquelon', 'flexify-dashboard-for-woocommerce' ),
				'VC' => esc_html( 'Saint Vincent and the Grenadines', 'flexify-dashboard-for-woocommerce' ),
				'WS' => esc_html( 'Samoa', 'flexify-dashboard-for-woocommerce' ),
				'SM' => esc_html( 'San Marino', 'flexify-dashboard-for-woocommerce' ),
				'ST' => esc_html( 'Sao Tome and Principe', 'flexify-dashboard-for-woocommerce' ),
				'SA' => esc_html( 'Saudi Arabia', 'flexify-dashboard-for-woocommerce' ),
				'SN' => esc_html( 'Senegal', 'flexify-dashboard-for-woocommerce' ),
				'RS' => esc_html( 'Serbia', 'flexify-dashboard-for-woocommerce' ),
				'SC' => esc_html( 'Seychelles', 'flexify-dashboard-for-woocommerce' ),
				'SL' => esc_html( 'Sierra Leone', 'flexify-dashboard-for-woocommerce' ),
				'SG' => esc_html( 'Singapore', 'flexify-dashboard-for-woocommerce' ),
				'SX' => esc_html( 'Sint Maarten', 'flexify-dashboard-for-woocommerce' ),
				'SK' => esc_html( 'Slovakia', 'flexify-dashboard-for-woocommerce' ),
				'SI' => esc_html( 'Slovenia', 'flexify-dashboard-for-woocommerce' ),
				'SB' => esc_html( 'Solomon Islands', 'flexify-dashboard-for-woocommerce' ),
				'SO' => esc_html( 'Somalia', 'flexify-dashboard-for-woocommerce' ),
				'ZA' => esc_html( 'South Africa', 'flexify-dashboard-for-woocommerce' ),
				'GS' => esc_html( 'South Georgia and the South Sandwich Islands', 'flexify-dashboard-for-woocommerce' ),
				'SS' => esc_html( 'South Sudan', 'flexify-dashboard-for-woocommerce' ),
				'ES' => esc_html( 'Spain', 'flexify-dashboard-for-woocommerce' ),
				'LK' => esc_html( 'Sri Lanka', 'flexify-dashboard-for-woocommerce' ),
				'SD' => esc_html( 'Sudan', 'flexify-dashboard-for-woocommerce' ),
				'SR' => esc_html( 'Suriname', 'flexify-dashboard-for-woocommerce' ),
				'SJ' => esc_html( 'Svalbard and Jan Mayen', 'flexify-dashboard-for-woocommerce' ),
				'SE' => esc_html( 'Sweden', 'flexify-dashboard-for-woocommerce' ),
				'CH' => esc_html( 'Switzerland', 'flexify-dashboard-for-woocommerce' ),
				'SY' => esc_html( 'Syrian Arab Republic', 'flexify-dashboard-for-woocommerce' ),
				'TW' => esc_html( 'Taiwan', 'flexify-dashboard-for-woocommerce' ),
				'TJ' => esc_html( 'Tajikistan', 'flexify-dashboard-for-woocommerce' ),
				'TZ' => esc_html( 'Tanzania, United Republic of Tanganyika', 'flexify-dashboard-for-woocommerce' ),
				'TH' => esc_html( 'Thailand', 'flexify-dashboard-for-woocommerce' ),
				'TL' => esc_html( 'Timor-Leste', 'flexify-dashboard-for-woocommerce' ),
				'TG' => esc_html( 'Togo', 'flexify-dashboard-for-woocommerce' ),
				'TK' => esc_html( 'Tokelau', 'flexify-dashboard-for-woocommerce' ),
				'TO' => esc_html( 'Tonga', 'flexify-dashboard-for-woocommerce' ),
				'TT' => esc_html( 'Trinidad and Tobago', 'flexify-dashboard-for-woocommerce' ),
				'TN' => esc_html( 'Tunisia', 'flexify-dashboard-for-woocommerce' ),
				'TR' => esc_html( 'Turkey', 'flexify-dashboard-for-woocommerce' ),
				'TM' => esc_html( 'Turkmenistan', 'flexify-dashboard-for-woocommerce' ),
				'TC' => esc_html( 'Turks and Caicos Islands', 'flexify-dashboard-for-woocommerce' ),
				'TV' => esc_html( 'Tuvalu', 'flexify-dashboard-for-woocommerce' ),
				'UG' => esc_html( 'Uganda', 'flexify-dashboard-for-woocommerce' ),
				'UA' => esc_html( 'Ukraine', 'flexify-dashboard-for-woocommerce' ),
				'AE' => esc_html( 'United Arab Emirates', 'flexify-dashboard-for-woocommerce' ),
				'GB' => esc_html( 'United Kingdom of Great Britain and Northern Ireland', 'flexify-dashboard-for-woocommerce' ),
				'UM' => esc_html( 'United States Minor Outlying Islands', 'flexify-dashboard-for-woocommerce' ),
				'US' => esc_html( 'United States of America', 'flexify-dashboard-for-woocommerce' ),
				'UY' => esc_html( 'Uruguay', 'flexify-dashboard-for-woocommerce' ),
				'UZ' => esc_html( 'Uzbekistan', 'flexify-dashboard-for-woocommerce' ),
				'VU' => esc_html( 'Vanuatu', 'flexify-dashboard-for-woocommerce' ),
				'VE' => esc_html( 'Venezuela', 'flexify-dashboard-for-woocommerce' ),
				'VN' => esc_html( 'Viet Nam', 'flexify-dashboard-for-woocommerce' ),
				'VG' => esc_html( 'Virgin Islands (British)', 'flexify-dashboard-for-woocommerce' ),
				'VI' => esc_html( 'Virgin Islands (U.S.)', 'flexify-dashboard-for-woocommerce' ),
				'WF' => esc_html( 'Wallis and Futuna', 'flexify-dashboard-for-woocommerce' ),
				'EH' => esc_html( 'Western Sahara', 'flexify-dashboard-for-woocommerce' ),
				'YE' => esc_html( 'Yemen', 'flexify-dashboard-for-woocommerce' ),
				'ZM' => esc_html( 'Zambia', 'flexify-dashboard-for-woocommerce' ),
				'ZW' => esc_html( 'Zimbabwe', 'flexify-dashboard-for-woocommerce' ),
				'AX' => esc_html( 'Åland Islands', 'flexify-dashboard-for-woocommerce' ),
			);
		}

	}
}
