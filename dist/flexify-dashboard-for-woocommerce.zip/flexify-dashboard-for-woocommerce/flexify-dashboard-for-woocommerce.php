<?php

/**
 * Plugin Name: 			Flexify Dashboard para WooCommerce
 * Description: 			Extensão que traz um design moderno e amigável ao painel do WordPress, com recursos essenciais para análise de lojas em WooCommerce.
 * Plugin URI: 				https://meumouse.com/plugins/flexify-dashboard-para-woocommerce/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.2.6
 * WC requires at least: 	7.1.0
 * WC tested up to: 		8.7.0
 * Requires PHP: 			7.4
 * Tested up to:      		6.5
 * Text Domain: 			flexify-dashboard-for-woocommerce
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Flexify_Dashboard' ) ) {
  
/**
 * Main Flexify_Dashboard Class
 *
 * @class Flexify_Dashboard
 * @since 1.0.0
 * @version 1.0.0
 * @package MeuMouse.com
 */
class Flexify_Dashboard {

		/**
		 * Flexify_Dashboard The single instance of Flexify_Dashboard.
		 *
		 * @since 1.0.0
		 * @var object
		 */
		private static $instance = null;

		/**
		 * The slug
		 *
		 * @since 1.0.0
		 * @var string
		 */
		public static $slug = 'flexify-dashboard-for-woocommerce';

		/**
		 * Plugin version number
		 *
		 * @since 1.0.0
		 * @var string
		 */
		public static $version = '1.2.6';

		/**
		 * Constructor function
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->setup_constants();

			add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
			add_action( 'plugins_loaded', array( $this, 'flexify_dashboard_load_checker' ), 5 );
		}
		

		/**
		 * Check requeriments on load plugin
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function flexify_dashboard_load_checker() {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '7.1', '>' ) ) {
				add_action( 'before_woocommerce_init', array( $this, 'setup_hpos_compatibility' ) );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 10 );
				add_filter( 'plugin_action_links_' . FLEXIFY_DASHBOARD_BASENAME, array( $this, 'flexify_dashboard_plugin_links' ), 10, 4 );
				add_filter( 'plugin_row_meta', array( $this, 'flexify_dashboard_row_meta_links' ), 10, 4 );
			} else {
				deactivate_plugins( 'flexify-dashboard-for-woocommerce/flexify-dashboard-for-woocommerce.php' );
				add_action( 'admin_notices', array( $this, 'flexify_dashboard_deactivate_notice' ) );
				add_action( 'admin_notices', array( $this, 'flexify_dashboard_version_notice' ) );
			}

			// Display notice if PHP version is bottom 7.4
			if ( version_compare( phpversion(), '7.4', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'flexify_dashboard_php_version_notice' ) );
				return;
			}
		}


		/**
		 * Setup WooCommerce High-Performance Order Storage (HPOS) compatibility
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_hpos_compatibility() {
			if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '7.1', '<' ) ) {
				return;
			}

			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
					'custom_order_tables', FLEXIFY_DASHBOARD_FILE, true
				);
			}
		}


		/**
		 * Main Flexify_Dashboard Instance
		 *
		 * Ensures only one instance of Flexify_Dashboard is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @see Flexify_Dashboard()
		 * @return Main Flexify_Dashboard instance
		 */
		public static function run() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}


		/**
		 * Define constant if not already set.
		 *
		 * @param string $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {
			$this->define( 'FLEXIFY_DASHBOARD_BASENAME', plugin_basename( __FILE__ ) );
			$this->define( 'FLEXIFY_DASHBOARD_DIR', plugin_dir_path( __FILE__ ) );
			$this->define( 'FLEXIFY_DASHBOARD_INC_DIR', FLEXIFY_DASHBOARD_DIR . '/includes/' );
			$this->define( 'FLEXIFY_DASHBOARD_MODULES_DIR', FLEXIFY_DASHBOARD_DIR . '/modules/' );
			$this->define( 'FLEXIFY_DASHBOARD_URL', plugin_dir_url( __FILE__ ) );
			$this->define( 'FLEXIFY_DASHBOARD_ASSETS_URL', FLEXIFY_DASHBOARD_URL . 'assets/' );
			$this->define( 'FLEXIFY_DASHBOARD_MODULES_ASSETS_URL', FLEXIFY_DASHBOARD_URL . '/modules/assets/' );
			$this->define( 'FLEXIFY_DASHBOARD_ANALYTICS_ENDPOINT_URL', 'https://api.meumouse.com/wp-json/flexify-dashboard/v1/' );
			$this->define( 'FLEXIFY_DASHBOARD_FILE', __FILE__ );
			$this->define( 'FLEXIFY_DASHBOARD_ABSPATH', dirname( FLEXIFY_DASHBOARD_FILE ) . '/' );
			$this->define( 'FLEXIFY_DASHBOARD_SLUG', self::$slug );
			$this->define( 'FLEXIFY_DASHBOARD_VERSION', self::$version );
			$this->define( 'FLEXIFY_DASHBOARD_ADMIN_EMAIL', get_option('admin_email') );
			$this->define( 'FLEXIFY_DASHBOARD_DOCS_LINK', 'https://meumouse.com/docs/flexify-dashboard-para-woocommerce/' );
		}


		/**
		 * Include required files
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_includes() {
			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'class-flexify-dashboard-init.php';

			/**
			 * Plugin functions
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'flexify-dashboard-functions.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'admin/class-flexify-dashboard-admin-options.php';

			/**
			 * Core class
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'classes/class-flexify-dashboard-core.php';

			/**
			 * Google Analytics integration
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_MODULES_DIR . 'analytics/class-flexify-dashboard-analytics-manager.php';

			/**
			 * Google reCaptcha integration
			 * 
			 * @since 1.2.0
			 * @version 1.2.5
			 */
			if ( Flexify_Dashboard_Init::get_setting('enable_recaptcha_admin_login') === 'yes' && ! defined('FLEXIFY_DASHBOARD_DISABLE_RECAPTCHA') ) {
				include_once FLEXIFY_DASHBOARD_MODULES_DIR . 'recaptcha/class-flexify-dashboard-recaptcha-module.php';
			}

			/**
			 * Dependencies and assets
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'classes/class-flexify-dashboard-assets.php';

			/**
			 * Screen widgets
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'classes/class-flexify-dashboard-widgets.php';

			/**
			 * Connect on API
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'classes/class-flexify-dashboard-api.php';

			/**
			 * Update checker
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_DASHBOARD_INC_DIR . 'classes/class-flexify-dashboard-updater.php';
		}


		/**
		 * PHP version notice
		 * 
		 * @since 1.0.0
		 * @version 1.2.5
		 * @return void
		 */
		public function flexify_dashboard_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Flexify Dashboard para WooCommerce</strong> requer a versão do PHP 7.4 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'flexify-dashboard-for-woocommerce' ) . '</p>
				</div>';
		}


		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @version 1.2.5
		 * @return array
		 */
		public function flexify_dashboard_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=flexify-dashboard-for-woocommerce' ) . '">'. __( 'Configurar', 'flexify-dashboard-for-woocommerce' ) .'</a>',
			);

			return array_merge( $plugins_links, $action_links );
		}


		/**
		 * Add meta links on plugin
		 * 
		 * @since 1.2.5
		 * @param string $plugin_meta | An array of the plugin’s metadata, including the version, author, author URI, and plugin URI
		 * @param string $plugin_file | Path to the plugin file relative to the plugins directory
		 * @param array $plugin_data | An array of plugin data
		 * @param string $status | Status filter currently applied to the plugin list
		 * @return string
		 */
		public function flexify_dashboard_row_meta_links( $plugin_meta, $plugin_file, $plugin_data, $status ) {
			if ( strpos( $plugin_file, FLEXIFY_DASHBOARD_BASENAME ) !== false ) {
				$new_links = array(
						'docs' => '<a href="'. FLEXIFY_DASHBOARD_DOCS_LINK .'" target="_blank">'. __( 'Documentação', 'flexify-dashboard-for-woocommerce' ) .'</a>',
						);
				
				$plugin_meta = array_merge( $plugin_meta, $new_links );
			}
		
			return $plugin_meta;
		}


		/**
		 * Load the plugin text domain for translation
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'flexify-dashboard-for-woocommerce', false, dirname( FLEXIFY_DASHBOARD_BASENAME ) . '/languages/' );
		}


		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-dashboard-for-woocommerce' ), '1.0.0' );
		}


		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-dashboard-for-woocommerce' ), '1.0.0' );
		}
	}
}

/**
 * Initialise the plugin
 */
Flexify_Dashboard::run();