/*-
 * Author: Alin Marcu 
 * Author URI: https://deconf.com 
 * Copyright 2013 Alin Marcu 
 * License: GPLv2 or later 
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

"use strict";

var flexify_dashboard_analyticsRedirectLink;
var flexify_dashboard_analyticsRedirectCalled = false;
var flexify_dashboard_analyticsDefaultPrevented = false;

function flexify_dashboard_analyticsRedirect () {
	if ( flexify_dashboard_analyticsRedirectCalled ) {
		return;
	}
	flexify_dashboard_analyticsRedirectCalled = true;
	if ( flexify_dashboard_analyticsDefaultPrevented == false ) {
		document.location.href = flexify_dashboard_analyticsRedirectLink;
	} else {
		flexify_dashboard_analyticsDefaultPrevented = false;
	}
}

function flexify_dashboard_analytics_send_event ( category, action, label, withCallBack ) {

	console.log( "This is the: " + flexify_dashboard_analyticsUAEventsData.options[ 'global_site_tag' ]);

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'global_site_tag' ] ) {
		if ( withCallBack ) {
			if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_bouncerate' ] ) {
				gtag( 'event', action, {
					'event_category': category, 
					'event_label': label,
					'non_interaction' : 1,
					'event_callback' : flexify_dashboard_analyticsRedirect
				} );
			} else {
				gtag( 'event', action, {
					'event_category': category, 
					'event_label': label,
					'event_callback' : flexify_dashboard_analyticsRedirect
				} );
			}
		} else {
			if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_bouncerate' ] ) {
				gtag( 'event', action, {
					'event_category': category, 
					'event_label': label,
					'non_interaction' : 1,
				} );
			} else {
				gtag( 'event', action, {
					'event_category': category, 
					'event_label': label
				} );
			}
		}
	}	
}

jQuery( window ).on( 'load', function () {

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_tracking' ] ) {
		// Track Downloads
		jQuery( 'a' ).filter( function () {
            if (typeof this.href === 'string') {
                var reg = new RegExp( '.*\\.(' + flexify_dashboard_analyticsUAEventsData.options[ 'event_downloads' ] + ')(\\?.*)?$' );
                return this.href.match( reg );
            }
		} ).click( function ( e ) {
			var category = this.getAttribute( 'data-vars-ga-category' ) || 'download';
			var action = this.getAttribute( 'data-vars-ga-action' ) || 'click';
			var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
			flexify_dashboard_analytics_send_event ( category, action, label, false );
		} );

		// Track Mailto
		jQuery( 'a[href^="mailto"]' ).click( function ( e ) {
			var category = this.getAttribute( 'data-vars-ga-category' ) || 'email';
			var action = this.getAttribute( 'data-vars-ga-action' ) || 'send';
			var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
			flexify_dashboard_analytics_send_event ( category, action, label, false );
		} );

		// Track telephone calls
		jQuery( 'a[href^="tel"]' ).click( function ( e ) {
			var category = this.getAttribute( 'data-vars-ga-category' ) || 'telephone';
			var action = this.getAttribute( 'data-vars-ga-action' ) || 'call';
			var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
			flexify_dashboard_analytics_send_event ( category, action, label, false );
		} );

		if ( flexify_dashboard_analyticsUAEventsData.options[ 'root_domain' ] ) {

			// Track Outbound Links
			jQuery( 'a[href^="http"]' ).filter( function () {
	            if (typeof this.href === 'string') {
	                var reg = new RegExp( '.*\\.(' + flexify_dashboard_analyticsUAEventsData.options[ 'event_downloads' ] + ')(\\?.*)?$' );
	            }				
				if ( reg && !this.href.match( reg ) ) {
					if ( this.href.indexOf( flexify_dashboard_analyticsUAEventsData.options[ 'root_domain' ] ) == -1 && this.href.indexOf( '://' ) > -1 )
						return this.href;
				}
			} ).click( function ( e ) {
				flexify_dashboard_analyticsRedirectCalled = false;
				flexify_dashboard_analyticsRedirectLink = this.href;
				var category = this.getAttribute( 'data-vars-ga-category' ) || 'outbound';
				var action = this.getAttribute( 'data-vars-ga-action' ) || 'click';
				var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
				if ( this.target != '_blank' && flexify_dashboard_analyticsUAEventsData.options[ 'event_precision' ] ) {
					if ( e.isDefaultPrevented() ) {
						flexify_dashboard_analyticsDefaultPrevented = true;
						flexify_dashboard_analyticsRedirectCalled = false;						
					}
				} else {
					flexify_dashboard_analyticsRedirectCalled = true;
					flexify_dashboard_analyticsDefaultPrevented = false;
				}
				if ( this.target != '_blank' && flexify_dashboard_analyticsUAEventsData.options[ 'event_precision' ] ) {
					flexify_dashboard_analytics_send_event( category, action, label, true );	
					setTimeout( flexify_dashboard_analyticsRedirect, flexify_dashboard_analyticsUAEventsData.options[ 'event_timeout' ] );
					return false;
				} else {
					flexify_dashboard_analytics_send_event( category, action, label, false );	
				}
			} );
		}
	}

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_affiliates' ] && flexify_dashboard_analyticsUAEventsData.options[ 'aff_tracking' ] ) {

		// Track Affiliates
		jQuery( 'a' ).filter( function () {
			if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_affiliates' ] != '' ) {
				if (typeof this.href === 'string') {
					var reg = new RegExp( '(' + flexify_dashboard_analyticsUAEventsData.options[ 'event_affiliates' ].replace( /\//g, '\/' ) + ')' );
					return this.href.match( reg );
				}	
			}
		} ).click( function ( e ) {
			flexify_dashboard_analyticsRedirectCalled = false;
			flexify_dashboard_analyticsRedirectLink = this.href;
			var category = this.getAttribute( 'data-vars-ga-category' ) || 'affiliates';
			var action = this.getAttribute( 'data-vars-ga-action' ) || 'click';
			var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
			if ( this.target != '_blank' && flexify_dashboard_analyticsUAEventsData.options[ 'event_precision' ] ) {
				if ( e.isDefaultPrevented() ) {
					flexify_dashboard_analyticsDefaultPrevented = true;
					flexify_dashboard_analyticsRedirectCalled = false;
				}
			} else {
				flexify_dashboard_analyticsRedirectCalled = true;
				flexify_dashboard_analyticsDefaultPrevented = false;
			}			
			if ( this.target != '_blank' && flexify_dashboard_analyticsUAEventsData.options[ 'event_precision' ] ) {
				flexify_dashboard_analytics_send_event( category, action, label, true );
				setTimeout( flexify_dashboard_analyticsRedirect, flexify_dashboard_analyticsUAEventsData.options[ 'event_timeout' ] );
				return false;
			} else {
				flexify_dashboard_analytics_send_event( category, action, label, false );
			}
		} );
	}

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'root_domain' ] && flexify_dashboard_analyticsUAEventsData.options[ 'hash_tracking' ] ) {

		// Track Hashmarks
		jQuery( 'a' ).filter( function () {
			if ( this.href.indexOf( flexify_dashboard_analyticsUAEventsData.options[ 'root_domain' ] ) != -1 || this.href.indexOf( '://' ) == -1 )
				return this.hash;
		} ).click( function ( e ) {
			var category = this.getAttribute( 'data-vars-ga-category' ) || 'hashmark';
			var action = this.getAttribute( 'data-vars-ga-action' ) || 'click';
			var label = this.getAttribute( 'data-vars-ga-label' ) || this.href;
			flexify_dashboard_analytics_send_event ( category, action, label, false );
		} );
	}

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'event_formsubmit' ] ) {

		// Track Form Submit
		jQuery( 'input[type="submit"], button[type="submit"]' ).click( function ( e ) {
			var flexify_dashboard_analyticsSubmitObject = this;
			var category = flexify_dashboard_analyticsSubmitObject.getAttribute( 'data-vars-ga-category' ) || 'form';
			var action = flexify_dashboard_analyticsSubmitObject.getAttribute( 'data-vars-ga-action' ) || 'submit';
			var label = flexify_dashboard_analyticsSubmitObject.getAttribute( 'data-vars-ga-label' ) || flexify_dashboard_analyticsSubmitObject.name || flexify_dashboard_analyticsSubmitObject.value;
			flexify_dashboard_analytics_send_event ( category, action, label, false );
		} );
	}

	if ( flexify_dashboard_analyticsUAEventsData.options[ 'ga_pagescrolldepth_tracking' ] ) {
		// Track Page Scroll Depth
		jQuery.scrollDepth( {
			percentage : true,
			userTiming : false,
			pixelDepth : false,
			gtmOverride : true,
			nonInteraction : true,
		} );
	}

} );
