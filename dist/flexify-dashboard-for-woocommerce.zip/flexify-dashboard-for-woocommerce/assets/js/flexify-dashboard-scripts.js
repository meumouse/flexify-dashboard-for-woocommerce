/**
 * Display screen options on navbar
 * 
 * @since 1.0.0
 */
jQuery(document).ready( function($) {
    const trigger = $('#flexify-dashboard-screen-widgets > .screen-options');
    const container = $('#flexify-dashboard-screen-widgets > .screen-options-container');

    // display screen elements popup
    trigger.on('click', function(e) {
        e.preventDefault();
        container.toggleClass('show');
        e.stopPropagation();
    });

    // hide on click outside container
    $(document).on('click', function(e) {
        if ( !container.is(e.target) && container.has(e.target).length === 0 ) {
            container.removeClass('show');
        }
    });

    // enable reorder widgets
    $(document).on('click', '#reorder-widgets', function() {
        $('.postbox-header').toggleClass('d-flex');
        $('.empty-container').toggleClass('reorder');
    });
});