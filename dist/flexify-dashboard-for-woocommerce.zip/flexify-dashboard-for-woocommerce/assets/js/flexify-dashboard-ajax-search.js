/**
 * Navbar search in AJAX
 * 
 * @since 1.0.0
 */
jQuery(document).ready(function($) {
    var timeout;

    $('input[name="flexify_dashboard_search"]').on('input', function() {
        clearTimeout(timeout);
        
        var searchTerm = $(this).val();

        if (searchTerm.length >= 3) {
            $('#search-loader').removeClass('d-none');

            timeout = setTimeout(function() {
                // call ajax
                getSearchResults(searchTerm);
            }, 500);
        } else {
            $('.flexify-dashboard-search-results-container').removeClass('show');
            $('#flexify-dashboard-search-results').empty();
            $('#search-loader').addClass('d-none');
        }
    });

    // Adicione um manipulador de eventos para quando o campo de pesquisa obtiver foco
    $('input[name="flexify_dashboard_search"]').on('focus', function() {
        var searchTerm = $(this).val();

        // Se o termo de pesquisa tiver pelo menos 3 caracteres, mostre os resultados
        if (searchTerm.length >= 3) {
            $('.flexify-dashboard-search-results-container').addClass('show');
        }
    });

    // Adicione um manipulador de eventos para o documento inteiro para lidar com cliques fora do container
    $(document).on('click', function(e) {
        var container = $('.flexify-dashboard-search-results-container');

        // Verifique se o clique não ocorreu dentro do container ou do input de pesquisa
        if (!container.is(e.target) && container.has(e.target).length === 0 && !$('input[name="flexify_dashboard_search"]').is(e.target)) {
            container.removeClass('show');
        }
    });

    function getSearchResults(searchTerm) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'flexify_dashboard_search',
                search_term: searchTerm,
            },
            success: function(response) {
                $('.flexify-dashboard-search-results-container').addClass('show');
                $('#flexify-dashboard-search-results').html(response);
                $('#search-loader').addClass('d-none');
            }
        });
    }
});
