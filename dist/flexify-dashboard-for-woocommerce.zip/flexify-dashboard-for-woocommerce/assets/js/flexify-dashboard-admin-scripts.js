(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let flexify_dashboard_tab_index = localStorage.getItem('flexify_dashboard_tab_index');

		if (flexify_dashboard_tab_index === null) {
			// If it is null, activate the general tab
			$('.flexify-dashboard-wrapper a.nav-tab[href="#general"]').click();
		} else {
			$('.flexify-dashboard-wrapper a.nav-tab').eq(flexify_dashboard_tab_index).click();
		}
	});
	  
	$(document).on('click', '.flexify-dashboard-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('flexify_dashboard_tab_index', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.flexify-dashboard-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.flexify-dashboard-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.flexify-dashboard-form').find(attrHref).addClass('active');
		
		return false;
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="flexify-dashboard"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;
	
		settingsForm.on('change', function() {
			$('.update-notice-flexify-dashboard').fadeOut('fast', function() {
				$(this).removeClass('show').css('display', '');
			});
			
			if ( settingsForm.serialize() != originalValues ) {
				ajax_save_options(); // send option serialized on change
			}
		});
	
		function ajax_save_options() {
			$.ajax({
				url: flexify_dashboard_admin_params.ajax_url,
				type: 'POST',
				data: {
					action: 'flexify_dashboard_ajax_save_options',
					form_data: settingsForm.serialize(),
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response); // Parse the JSON response
					//	console.log(responseData.options);

						if ( responseData.status === 'success' ) {
							originalValues = settingsForm.serialize();
							$('.update-notice-flexify-dashboard').addClass('show');
							
							if ( notificationDelay ) {
								clearTimeout(notificationDelay);
							}
				
							notificationDelay = setTimeout( function() {
								$('.update-notice-flexify-dashboard').fadeOut('fast', function() {
									$(this).removeClass('show').css('display', '');
								});
							}, 3000);
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}
	});


    /**
	 * Display loader and hide span on click
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.button-loading').on('click', function() {
			let $btn = $(this);
			let expireDate = $btn.text();
			let btnWidth = $btn.width();
			let btnHeight = $btn.height();

			// keep original width and height
			$btn.width(btnWidth);
			$btn.height(btnHeight);

			// Add spinner inside button
			$btn.html('<span class="spinner-border spinner-border-sm"></span>');
		});

		// Prevent keypress enter
		$('.form-control').keypress( function(event) {
			if (event.keyCode === 13) {
				event.preventDefault();
			}
		});
	});


	/**
	 * Change container visibility
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		/**
		 * Function to change container visibility
		 * @param {string} method - activation element selector
		 * @param {string} container - container selector
		 */
		function toggle_container_visibility(method, container) {
			let checked = $(method).prop('checked');

			$(container).toggleClass('d-none', !checked);
		}
	
		/**
		 * Display inputs for integration with Google Analytics
		 * 
		 * @since 1.0.0
		 */
		toggle_container_visibility('#enable_ga_integration', '.ga-required');
		$('#enable_ga_integration').click( function() {
			toggle_container_visibility('#enable_ga_integration', '.ga-required');
		});

		/**
		 * Display inputs for integration with Google reCaptcha
		 * 
		 * @since 1.0.0
		 */
		toggle_container_visibility('#enable_recaptcha_admin_login', '.recaptcha-required');
		$('#enable_recaptcha_admin_login').click( function() {
			toggle_container_visibility('#enable_recaptcha_admin_login', '.recaptcha-required');
		});
	});


	/**
	 * Open WordPress midia library popup on click
	 * 
	 * @since 1.0.0
	 * @version 1.2.5
	 */
	jQuery(document).ready(function($) {
		var file_frame;
	
		/**
		 * Handler WordPress media upload
		 * 
		 * @since 1.2.5
		 * @param {string} title 
		 * @param {string} input 
		 * @returns object
		 */
		function open_media_uploader(title, input) {
			// If the media frame already exists, reopen it
			if (file_frame) {
				file_frame.open();
				return;
			}
	
			// Create media frame
			file_frame = wp.media.frames.file_frame = wp.media({
				title: title,
				button: {
					text: flexify_dashboard_admin_params.use_this_image,
				},
				multiple: false
			});
	
			// When an image is selected, execute the callback function
			file_frame.on('select', function() {
				var attachment = file_frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.url;
	
				// Update the input value with the URL of the selected image
				$('input[name="' + input + '"]').val(imageUrl).trigger('change'); // Force change
			});
	
			file_frame.open();
		}
	
		$('#flexify_dashboard_logo').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.sidebar_logo_title, 'dashboard_logo');
		});
	
		$('#flexify_dashboard_admin_login_image').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.admin_login_title, 'admin_login_image');
		});

		$('#search_admin_login_logo').on('click', function(e) {
			e.preventDefault();
			open_media_uploader(flexify_dashboard_admin_params.admin_login_logo_title, 'admin_login_logo');
		});
	});
	


	/**
	 * Check visibility toast
	 * 
	 * @since 1.0.0
	 */
	jQuery(document).ready( function() {
		if ( $('.toast.show').length > 0 ) {
			setTimeout( function() {
				$('.toast.show').fadeOut('fast', function() {
					$(this).removeClass('show');
				});
			}, 3000);
		}
	});
	

})(jQuery);