/**
 * Save theme mode on change
 * 
 * @since 1.0.0
 */
jQuery(document).ready( function($) {
    $('#theme-mode').on('change', function() {
        var get_state = $(this).prop('checked') ? 'yes' : 'no';

        // add class to body
        $('body').toggleClass('dark-mode', $(this).prop('checked'));

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'save_theme_mode_state',
                theme_mode_state: get_state,
            },
            success: function(response) {
                try {
                    var responseData = JSON.parse(response); // Parse the JSON response

                    if ( responseData.status === 'success' ) {
                        console.log(response);
                    }
                } catch (error) {
                    console.log(error);
                }
            }
        });
    });
});